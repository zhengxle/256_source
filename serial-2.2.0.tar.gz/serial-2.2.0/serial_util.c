/*
 * test program for the serial system.
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: serial_util.c,v 1.35 2000/03/09 03:49:07 gray Exp $
 */

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "argv.h"
#include "serial.h"
#include "version.h"

static	char	*rcs_id =
  "$Id: serial_util.c,v 1.35 2000/03/09 03:49:07 gray Exp $";

/* default file descriptors */
#define STDIN_FD	0
#define STDOUT_FD	1
#define STDERR_FD	2

/* local variables */
static	serial_t	*serial_p	= NULL;		/* serial struct */

/* argument variables */
static	char		*command	= NULL;		/* command to run */
static	char		*device		= NULL;		/* device to open */
static	char		binary_b	= 0;		/* binary format flag*/
static	char		error_out_b	= 0;		/* errors to stdout */
static	char		*label		= NULL;		/* label to run */
static	char		locked_b	= 0;		/* write as locked */
static	int		noerror_code	= 0;		/* code thats no-err */
static	char		pass_err_b	= 0;		/* pass as error */
static	char		*write_path	= NULL;		/* path to write to */
static	char		*script		= NULL;		/* script file to do */

static	argv_array_t	arg_list;			/* argument list */
static	argv_array_t	debug_list;			/* debug log file(s) */
static	argv_array_t	in_put_list;			/* input log file(s) */
static	argv_array_t	out_put_list;			/* out_put log files */

static	argv_t	argv_list[] = {
  { 'c',	"command",	ARGV_CHAR_P,		&command,
      "command args",		"command with args to fork" },
  { ARGV_OR },
  { 'd',	"device",	ARGV_CHAR_P,		&device,
      "device-path",		"device path to open" },
  { 'b',	"binary",	ARGV_BOOL,		&binary_b,
      NULL,			"write in binary file format" },
  { ARGV_OR },
  { 'L',	"locked",	ARGV_BOOL,		&locked_b,
      NULL,			"write script with locked status" },
  { 'D',	"debug",	ARGV_CHAR_P | ARGV_FLAG_ARRAY, &debug_list,
      "log-path",		"debug log(s) (- for stderr)" },
  { 'e',	"error-out",	ARGV_BOOL,		&error_out_b,
      NULL,			"route all errors to stdout" },
  { 'i',	"in_put",	ARGV_CHAR_P | ARGV_FLAG_ARRAY, &in_put_list,
      "log-path",		"in_put log(s) (- for stderr)" },
  { 'l',	"label",	ARGV_CHAR_P,		&label,
      "label",			"label in script to start at" },
  { 'n',	"noerror-code",	ARGV_INT,		&noerror_code,
      "code",			"code that is no-error (0)" },
  { 'o',	"out_put",	ARGV_CHAR_P | ARGV_FLAG_ARRAY, &out_put_list,
      "log-path",		"out_put log(s) (- for stderr)" },
  { 'p',	"pass-err",	ARGV_BOOL,		&pass_err_b,
      NULL,			"show pass message as error" },
  { 'w',	"write-path",	ARGV_CHAR_P,		&write_path,
      "path",			"path to out_put script to" },
  { ARGV_MAND,	NULL,		ARGV_CHAR_P,		&script,
      "path",			"script to run else stdin" },
  { ARGV_MAYBE,	NULL,		ARGV_CHAR_P | ARGV_FLAG_ARRAY, &arg_list,
      "char=string",		"char=string argument(s)" },
  { ARGV_LAST }
};

/*
 * Open a logfile to PATH while handling '-'.
 */
static	FILE	**open_log(const argv_array_t *arg_p, const int which)
{
  int	arg_c, ret;
  FILE	**grid;
  char	*path;
  
  if (arg_p->aa_entry_n == 0) {
    return NULL;
  }
  
  grid = (FILE **)malloc(sizeof(FILE *) * arg_p->aa_entry_n);
  
  for (arg_c = 0; arg_c < arg_p->aa_entry_n; arg_c++) {
    path = ARGV_ARRAY_ENTRY(*arg_p, char *, arg_c);
    
    if (strcmp(path, "-") == 0) {
      grid[arg_c] = (error_out_b ? stdout : stderr);
    }
    else {
      grid[arg_c] = fopen(path, "w");
      if (grid[arg_c] == NULL) {
	perror(path);
	exit(1);
      }
    }
    
    ret = serial_log_add(serial_p, which, grid[arg_c]);
    if (ret != SERIAL_ERROR_NONE) {
      (void)fprintf((error_out_b ? stdout : stderr),
		    "%s: serial log-add for '%s' returned error: %s\n",
		    argv_program, path, serial_strerror(ret));
      exit(1);
    }
  }
  
  return grid;
}

/*
 * Close a list of logfiles.
 */
static	void	close_log(const argv_array_t *arg_p, FILE **grid)
{
  int	arg_c;
  
  if (arg_p->aa_entry_n == 0) {
    return;
  }
  
  for (arg_c = 0; arg_c < arg_p->aa_entry_n; arg_c++) {
    (void)fclose(grid[arg_c]);
  }
  
  free(grid);
}

/*
 * Turn off everything.
 */
static	void	shutdown(const int sig)
{
  int	ret;
  
  (void)printf("%s: caight signal %d.  shutting down\n", argv_program, sig);
  
  if (serial_p != NULL) {
    ret = serial_end(serial_p);
    if (ret != SERIAL_ERROR_NONE) {
      (void)fprintf((error_out_b ? stdout : stderr),
		    "%s: serial-end failed: %s\n",
		    argv_program, serial_strerror(ret));
    }
  }
  exit(1);
}

/*
 * Process the ?=string args into the serial_arg structure.
 */
static	serial_arg_t	*get_serial_args(void)
{
  serial_arg_t	*serial_args, *ser_p;
  char		*arg_p;
  int		ser_c;
  
  if (arg_list.aa_entry_n == 0) {
    return NULL;
  }
  
  serial_args = (serial_arg_t *)malloc(sizeof(serial_arg_t) *
				       (arg_list.aa_entry_n + 1));
  for (ser_c = 0, ser_p = serial_args; ser_c < arg_list.aa_entry_n;
       ser_c++, ser_p++) {
    arg_p = ARGV_ARRAY_ENTRY(arg_list, char *, ser_c);
    
    if (strlen(arg_p) < 2 || arg_p[1] != '=') {
      (void)fprintf((error_out_b ? stdout : stderr),
		    "%s: serial arguments should be in the form of ?=*\n",
		    argv_program);
      argv_usage(argv_list, ARGV_USAGE_DEFAULT);
      exit(1);
    }
    
    ser_p->sa_token = *arg_p;
    ser_p->sa_value = arg_p + 2;
  }
  
  /* termination one */
  ser_p->sa_token = '\0';
  ser_p->sa_value = NULL;
  
  return serial_args;
}

/*
 * Fork off command and pass back IN_FD and OUT_FD.  Returns
 * [NO]ERROR.
 */
static	void	setup_command(int *in_fd, int *out_fd)
{
  char	*args[100], **arg_p;
  char	comm_buf[1024], *comm_p;
  int	pipe1[2], pipe2[2];
  
  (void)strcpy(comm_buf, command);
  comm_p = comm_buf;
  
  /* compose the argument list */
  arg_p = args;
  while (*comm_p) {
    while (*comm_p == ' ') {
      comm_p++;
    }
    if (*comm_p == '\0') {
      break;
    }
    *arg_p++ = comm_p;
    while (*comm_p != '\0' && *comm_p != ' ') {
      comm_p++;
    }
    if (*comm_p != '\0') {
      *comm_p++ = '\0';
    }
  }
  *arg_p = NULL;
  
  /* setup the pipes */
  if (pipe(pipe1) != 0) {
    perror("pipe");
    exit(1);
  }
  if (pipe(pipe2) != 0) {
    perror("pipe");
    exit(1);
  }
  
  /* execute command */
  if (fork() == 0) {
    (void)dup2(pipe1[0], STDIN_FD);
    (void)close(pipe1[1]);
    (void)close(pipe2[0]);
    (void)dup2(pipe2[1], STDOUT_FD);
    
    (void)execv(args[0], args);
    perror(args[0]);
    exit(1);
  }
  
  /* parent: pass back the pipe args */
  (void)close(pipe1[0]);
  *out_fd = pipe1[1];
  *in_fd = pipe2[0];
  (void)close(pipe2[1]);
  
  (void)fcntl(pipe1[1], F_SETFL, O_NDELAY);
  (void)fcntl(pipe2[0], F_SETFL, O_NDELAY);
}

int	main(int argc, char **argv)
{
  int		ans = noerror_code, ret, in_fd, out_fd, type;
  FILE		**dbg_p = NULL, **in_p = NULL, **out_p = NULL;
  char		*pass;
  serial_arg_t	*serial_args = NULL;
  
  argv_help_string = "Serial utility to run scripts on serial lines.";
  argv_version_string = serial_version;
  argv_process(argv_list, argc, argv);
  
  serial_args = get_serial_args();
  
  /* necessary if we run in the background */
  (void)signal(SIGTTOU, SIG_IGN);
  
  if (command) {
    setup_command(&in_fd, &out_fd);
    device = command;
  }
  else if (device == NULL) {
    in_fd = STDIN_FD;
    out_fd = STDOUT_FD;
    device = "stdin/stdout";
  }
  else {
    in_fd = open(device, O_RDONLY | O_NDELAY, 0);
    if (in_fd < 0) {
      perror(device);
      exit(1);
    }
    out_fd = open(device, O_WRONLY | O_NDELAY, 0);
    if (out_fd < 0) {
      perror(device);
      exit(1);
    }
  }
  
  serial_p = serial_start(in_fd, out_fd, device, &ret);
  if (serial_p == NULL) {
    (void)fprintf((error_out_b ? stdout : stderr),
		  "%s: serial start on '%s' returned error: %s\n",
		  argv_program, device, serial_strerror(ret));
    exit(1);
  }
  
  /* make sure we close the port */
  (void)signal(SIGINT, shutdown);
  (void)signal(SIGHUP, shutdown);
  (void)signal(SIGTERM, shutdown);
  
  /* NOTE: we may generate errors on the load below */
  dbg_p = open_log(&debug_list, SERIAL_LOG_DEBUG);
  in_p = open_log(&in_put_list, SERIAL_LOG_INPUT);
  out_p = open_log(&out_put_list, SERIAL_LOG_OUTPUT);
  
  {
    FILE	*infile;
    
    infile = fopen(script, "r");
    if (infile == NULL) {
      perror(script);
      exit(1);
    }
    
    /* open the script */
    ret = serial_load(serial_p, infile, serial_args);
    (void)fclose(infile);
  }
  
  if (ret != SERIAL_ERROR_NONE) {
    (void)fprintf(stderr, "%s: could not load script from %s: %s\n",
		  argv_program, script, serial_strerror(ret));
    exit(1);
  }
  
  /* write out the script? */
  if (write_path != NULL) {
    FILE	*outfile;
    
    outfile = fopen(write_path, "w");
    if (outfile == NULL) {
      perror(write_path);
      exit(1);
    }
    if (binary_b) {
      type = SERIAL_WRITE_BINARY;
    }
    else if (locked_b) {
      type = SERIAL_WRITE_LOCKED;
    }
    else {
      type = SERIAL_WRITE_NORMAL;
    }
    ret = serial_write(serial_p, outfile, type);
    if (ret != SERIAL_ERROR_NONE) {
      (void)fprintf(stderr,
		    "%s: could not write script from '%s' to '%s': %s\n",
		    argv_program, script, write_path, serial_strerror(ret));
    }
    (void)fclose(outfile);
  }
  
  /* still run the script? */
  if (write_path == NULL || label != NULL) {
    ret = serial_script(serial_p, label, &ans, &pass);
    if (ret != SERIAL_ERROR_NONE) {
      (void)fprintf((error_out_b ? stdout : stderr),
		    "%s: script '%s' on device '%s' failed: %s\n",
		    argv_program, script, device, serial_strerror(ret));
      exit(1);
    }
  }
  
  ret = serial_end(serial_p);
  if (ret != SERIAL_ERROR_NONE) {
    (void)fprintf((error_out_b ? stdout : stderr),
		  "%s: serial-end failed: %s\n",
		  argv_program, serial_strerror(ret));
  }
  
  serial_p = NULL;
  
  (void)signal(SIGINT, SIG_DFL);
  (void)signal(SIGHUP, SIG_DFL);
  (void)signal(SIGTERM, SIG_DFL);
  
  if (ans != noerror_code) {
    (void)fprintf((error_out_b ? stdout : stderr),
		  "%s: script '%s' on '%s' did not return code %d.\n",
		  argv_program, device, script, noerror_code);
    if (pass_err_b) {
      (void)fprintf((error_out_b ? stdout : stderr), "%s: pass = '%s'.\n",
		    argv_program, pass);
    }
  }
  
  if (in_fd != STDIN_FD) {
    (void)close(in_fd);
  }
  if (out_fd != STDOUT_FD) {
    (void)close(out_fd);
  }
  
  close_log(&debug_list, dbg_p);
  close_log(&in_put_list, in_p);
  close_log(&out_put_list, out_p);
  
  if (serial_args != NULL) {
    free(serial_args);
  }
  
  argv_cleanup(argv_list);
  
  if (ans == noerror_code) {
    exit(0);
  }
  else {
    exit(1);
  }
}
