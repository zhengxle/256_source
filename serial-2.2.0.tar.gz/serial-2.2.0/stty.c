/*
 * handle stty command.
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: stty.c,v 1.17 2000/03/09 03:49:07 gray Exp $
 */

#include <stdlib.h>
#include <string.h>
#include <termios.h>

#include "serial.h"
#include "stty.h"
#include "stty_loc.h"

static	char	*rcs_id =
  "$Id: stty.c,v 1.17 2000/03/09 03:49:07 gray Exp $";

#define TOKENIZE_CHARS		" \t,"

/*
 * Return a character representation of string TOK_P.
 */
static	char	tok_to_ch(const char *tok_p)
{
  char	ch;
  
  /* handle ' and " */
  if ((*tok_p == '\'' || *tok_p == '\"') && strlen(tok_p) >= 3) {
    tok_p++;
  }
  
  /* is it a non ^ character */
  if (*tok_p != '^') {
    return *(char *)tok_p;
  }
  
  tok_p++;
  switch (*tok_p) {
    /* delete character */
  case '?':
    ch = '\177';
    break;
    
    /* undefined */
  case '-':
    ch = '\0';
    break;
    
    /* ^ */
  case '^':
    ch = '^';
    break;
    
  default:
    /* ^A->\001,^B->\002 nifty!! */
    ch = *tok_p & 037;
    break;
  }
  
  return ch;
}

/*
 * Map from stty COMMAND into changes made to FD and TERM_P.  If EXCL
 * then clear all flags before setting this command.  Returns serial
 * error codes.
 */
int	_stty_do(const int fd, const char *command, const char excl,
		 struct termios *term_p)
{
  stty_map_t		*map_p;
  char			*comm_p, *tok_p = NULL;
  unsigned long		*long_p = NULL;
  struct termios	tmp;
  
  comm_p = strdup(command);
  tmp = *term_p;
  
  /* zero all the flags for exclusive setting */
  if (excl) {
    int		ccc;
    
    tmp.c_iflag = 0;
    tmp.c_oflag = 0;
    /*
     * note, do not change the baud to be consistant accross all
     * system types.
     */
#ifdef CBAUD
    tmp.c_cflag &= CBAUD;
#else
    tmp.c_cflag = 0;
#endif
    tmp.c_lflag = 0;
    
    for (ccc = 0; ccc < NCCS; ccc++) {
      tmp.c_cc[ccc] = 0;
    }
  }
  
  for (;;) {
    if (tok_p == NULL) {
      tok_p = strtok(comm_p, TOKENIZE_CHARS);
    }
    else {
      tok_p = strtok(NULL, TOKENIZE_CHARS);
    }
    
    if (tok_p == NULL) {
      break;
    }
    
    /* find it in the map list */
    for (map_p = stty_maps; map_p->sm_label != NULL; map_p++) {
      if (strcmp(map_p->sm_label, tok_p) == 0) {
	break;
      }
    }
    
    /* did we find it? */
    if (map_p->sm_label == NULL) {
      free(comm_p);
      return SERIAL_ERROR_STTY;
    }
    
    /* find the flag we are using */
    switch (map_p->sm_flag) {
      
    case FLAG_C:
      long_p = &tmp.c_cflag;
      break;
      
    case FLAG_I:
      long_p = &tmp.c_iflag;
      break;
      
    case FLAG_O:
      long_p = &tmp.c_oflag;
      break;
      
    case FLAG_L:
      long_p = &tmp.c_lflag;
      break;
      
    case FLAG_NONE:
      break;
      
    default:
      free(comm_p);
      return SERIAL_ERROR_STTY;
      break;
    }
    
    /* get the action */
    switch (map_p->sm_action) {
      
    case ACTION_CLEAR:
      *long_p = *long_p & ~map_p->sm_value;
      break;
      
    case ACTION_SET:
      *long_p = *long_p | map_p->sm_value;
      break;
      
    case ACTION_BAUD:
      (void)cfsetispeed(&tmp, map_p->sm_value);
      (void)cfsetospeed(&tmp, map_p->sm_value);
#ifdef sun
      /* HACK: for sun cbaud bug in at least SunOS 4.1 */
      tmp.c_cflag &= ~CBAUD;
      tmp.c_cflag |= map_p->sm_value;
#endif
      break;
      
    case ACTION_CHAR:
      {
	char	ch;
	
	tok_p = (char *)strtok(NULL, TOKENIZE_CHARS);
	if (tok_p == NULL) {
	  free(comm_p);
	  return SERIAL_ERROR_STTY;
	}
	ch = tok_to_ch(tok_p);
	tmp.c_cc[map_p->sm_value] = ch;
      }
      break;
      
    case ACTION_VALUE:
      tok_p = (char *)strtok(NULL, TOKENIZE_CHARS);
      if (tok_p == NULL) {
	free(comm_p);
	return SERIAL_ERROR_STTY;
      }
      tmp.c_cc[map_p->sm_value] = atoi(tok_p);
      break;
      
    default:
      free(comm_p);
      return SERIAL_ERROR_STTY;
      break;
    }
  }
  
  free(comm_p);
  
  if (tcsetattr(fd, TCSANOW, &tmp) == 0) {
    *term_p = tmp;
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_MODES;
  }
}

/*
 * Flush some input and/or ouput from FD.  Returns serial error codes.
 */
int	_stty_flush(const int fd)
{
  if (tcflush(fd, TCIOFLUSH) == 0) {
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_FLUSH;
  }
}
