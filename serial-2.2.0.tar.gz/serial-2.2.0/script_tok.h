/*
 * script tokens
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: script_tok.h,v 1.15 2000/03/09 03:49:06 gray Exp $
 */

#ifndef __SCRIPT_TOK_H__
#define __SCRIPT_TOK_H__

/* send/receive */
#define TOK_UNKNOWN		(-1)		/* unknown token */
#define TOK_NONE		1		/* no token (for args) */
#define TOK_RESERVED		2		/* no token (for args) */

#define TOK_SEND		3		/* write chars to port */
#define TOK_RECEIVE		4		/* read chars from port */
#define TOK_WAIT		5		/* wait for input */
#define TOK_EXPECT_REG		6		/* expect a regex in input */
#define TOK_EXPECT_SUB		7		/* expect a sub-string */
#define TOK_CHECK_REG		8		/* check buffers for regex */
#define TOK_CHECK_SUB		9		/* check for sub-string */

/* flush commands */
#define TOK_FLUSH_DO		10		/* flush search buffers now */
#define TOK_FLUSH_MATCH		11		/* flush when we match */
#define TOK_FLUSH_SEARCH	12		/* flush when we search */
#define TOK_FLUSH_NONE		13		/* never flush */
#define TOK_OVERWRITE_MATCH	14		/* overwrite match in bufs */

/* variables */
#define TOK_USE			15		/* use this variable */
#define TOK_SET			16		/* set the variable */
#define TOK_STR_SET		17		/* set variable from string */
#define TOK_ADD			18		/* add a number to var */
#define TOK_TEST_EQ		19		/* test if it == */
#define TOK_TEST_NE		20		/* != value */
#define TOK_TEST_LT		21		/* < */
#define TOK_TEST_LE		22		/* <= */
#define TOK_TEST_GT		23		/* > */
#define TOK_TEST_GE		24		/* >= */

/* mode and lock */
#define TOK_STTY		25		/* set some stty flags */
#define TOK_STTYE		26		/* reset stty flags then set */
#define TOK_CLEAR_IO		27		/* clear input/output bufs */
#define TOK_LOCK		28		/* lock the port */
#define TOK_UNLOCK		29		/* unlock the port */

/* input form */
#define TOK_INTERACTIVE		30		/* prompt mode for user */
#define TOK_PASSWORD		31		/* do not echo input */
#define TOK_STRAIGHT		32		/* non-interactive mode */

/* test/jump */
#define TOK_IS_OKAY		33		/* was the last command okay */
#define TOK_IS_NOT_OKAY		34		/* was it not okay? */
#define TOK_GOTO		35		/* jump to a lable */

/* utilities */
#define TOK_RETURN		36		/* return a value to caller */
#define TOK_DELAY		37		/* delay for microseconds */
#define TOK_TIMEOUT		38		/* set wait-for-input value */
#define TOK_MAX_CHARS		39		/* max characters to read in */
#define TOK_PASS		40		/* do not echo input */
#define TOK_MATCH		41		/* set the matched pattern */

/* log i/o commands */
#define TOK_MESSAGE		42		/* send message to logs */
#define TOK_TIME_STAMP		43		/* log time-stamp to logs */
#define TOK_OPEN_INPUT		44		/* open input log files */
#define TOK_CLOSE_INPUT		45		/* close input logs */
#define TOK_OPEN_OUTPUT		46		/* open output log files */
#define TOK_CLOSE_OUTPUT	47		/* close output logs */
#define TOK_OPEN_DEBUG		48		/* open debug log files */
#define TOK_CLOSE_DEBUG		49		/* close debug logs */

/* special defines: */
#define TOK_STRING		50		/* a string token */
#define TOK_INT			51		/* integer token */
#define TOK_LABEL		52		/* label token */

/* number of tokens in the file */
#define TOK_MAXIMUM		53		/* label token */

/* token string to value map */
typedef struct {
  char		*to_string;			/* token string */
  int		to_id;				/* value */
  int		to_argument;			/* argument */
} token_t;

/* reserved words list */
static	token_t	reserved_tokens[] = {
  
  /* special */
  { "--LABEL--" /* UNKNOWN */,	TOK_LABEL, TOK_NONE }, /* label to jump to */
  
  /* send/receive */
  { "send",		TOK_SEND,	TOK_STRING }, /* write chars to port */
  { "receive",		TOK_RECEIVE,	TOK_NONE }, /* read chars from port */
  { "wait",		TOK_WAIT,	TOK_NONE }, /* wait for input */
  
  /* expecting input */
  { "expect_reg",	TOK_EXPECT_REG,	TOK_STRING }, /* expect regex input */
  { "expect_sub",	TOK_EXPECT_SUB,	TOK_STRING }, /* expect a sub-str */
  { "check_reg",	TOK_CHECK_REG,	TOK_STRING }, /* check bufs for regex*/
  { "check_sub",	TOK_CHECK_SUB,	TOK_STRING }, /* check for sub-str */
  
  /* when to flush search buffers */
  { "flush_do",		TOK_FLUSH_DO,	TOK_NONE }, /* flush search bufs now */
  { "flush_match",	TOK_FLUSH_MATCH, TOK_NONE }, /* flush when we match */
  { "flush_search",	TOK_FLUSH_SEARCH, TOK_NONE }, /* flush when search */
  { "flush_none",	TOK_FLUSH_NONE,	TOK_NONE }, /* never flush */
  { "overwrite_match",	TOK_OVERWRITE_MATCH, TOK_NONE }, /* overwrite bufs */
  
  /* mode and lock */
  { "stty",		TOK_STTY,	TOK_STRING }, /* set some stty flags */
  { "sttye",		TOK_STTYE,	TOK_STRING }, /* reset/set stty flags*/
  { "clear_io",		TOK_CLEAR_IO,	TOK_NONE }, /* clear i/o bufs */
  { "lock",		TOK_LOCK,	TOK_NONE }, /* lock the port */
  { "unlock",		TOK_UNLOCK,	TOK_NONE }, /* unlock the port */
  
  /* input form */
  { "interactive",	TOK_INTERACTIVE, TOK_NONE }, /* prompt mode for user */
  { "password",		TOK_PASSWORD,	TOK_NONE }, /* prompt but no echo */
  { "straight",		TOK_STRAIGHT,	TOK_NONE }, /* non-interactive mode */
  
  /* test/jump */
  { "is_okay",		TOK_IS_OKAY,	TOK_LABEL }, /* last command ok?*/
  { "is_not_okay",	TOK_IS_NOT_OKAY, TOK_LABEL }, /* not okay? */
  { "goto",		TOK_GOTO,	TOK_LABEL }, /* jump to lable */
  
  /* utilities */
  { "return",		TOK_RETURN,	TOK_INT }, /* return value to caller */
  { "delay",		TOK_DELAY,	TOK_INT }, /* delay for microseconds */
  { "timeout",		TOK_TIMEOUT,	TOK_INT }, /* set wait-for-input val */
  { "max_chars",	TOK_MAX_CHARS,	TOK_INT }, /* max chars to read in */
  
  { "pass",		TOK_PASS,	TOK_STRING }, /* set pass-back str */
  { "match",		TOK_MATCH,	TOK_STRING }, /* set matched pattern */
  
  /* variables */
  { "use",		TOK_USE,	TOK_INT }, /* use this variable */
  { "set",		TOK_SET,	TOK_INT }, /* set the variable */
  { "str_set",		TOK_STR_SET,	TOK_STRING }, /* set var from string */
  { "add",		TOK_ADD,	TOK_INT }, /* add a number to var */
  { "test_eq",		TOK_TEST_EQ,	TOK_INT }, /* test if it == */
  { "test_ne",		TOK_TEST_NE,	TOK_INT }, /* != value */
  { "test_lt",		TOK_TEST_LT,	TOK_INT }, /* < */
  { "test_le",		TOK_TEST_LE,	TOK_INT }, /* <= */
  { "test_gt",		TOK_TEST_GT,	TOK_INT }, /* > */
  { "test_ge",		TOK_TEST_GE,	TOK_INT }, /* >= */
  
  /* log i/o */
  { "message",		TOK_MESSAGE,	TOK_STRING }, /* send mess to logs */
  { "time_stamp",	TOK_TIME_STAMP,	TOK_NONE }, /* send ctime to logs */
  { "log_open_input",	TOK_OPEN_INPUT, TOK_NONE }, /* open input log files */
  { "log_close_input",	TOK_CLOSE_INPUT, TOK_NONE }, /* close input logs */
  { "log_open_output",	TOK_OPEN_OUTPUT, TOK_NONE }, /* open output log file */
  { "log_close_output",	TOK_CLOSE_OUTPUT, TOK_NONE }, /* close output logs */
  { "log_open_debug",	TOK_OPEN_DEBUG, TOK_NONE }, /* open debug log files */
  { "log_close_debug",	TOK_CLOSE_DEBUG, TOK_NONE }, /* close debug logs */
  
  { NULL }
};

#endif /* ! __SCRIPT_TOK_H__ */
