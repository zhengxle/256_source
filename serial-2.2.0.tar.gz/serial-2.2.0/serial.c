/*
 * serial routines
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: serial.c,v 1.35 2000/03/09 03:49:06 gray Exp $
 */

#define SERIAL_MAIN

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/time.h>

#include "script.h"
#include "serial.h"
#include "serial_loc.h"
#include "stty.h"
#include "uucp_lock.h"

static	char	*rcs_id =
  "$Id: serial.c,v 1.35 2000/03/09 03:49:06 gray Exp $";

/****************************** local routines *******************************/

/*
 * Free up a serial structure SERIAL_P.
 */
static	int	serial_free(serial_t *serial_p)
{
  if (BIT_IS_SET(serial_p->se_flags, PORT_LOCKED)) {
    (void)_script_unlock(serial_p);
  }
  
  /*
   * NOTE: no closing of log files here since they were not opened here
   */
  
  if (serial_p->se_buf != NULL) {
    free(serial_p->se_buf);
  }
  if (serial_p->se_log_input != NULL) {
    free(serial_p->se_log_input);
  }
  if (serial_p->se_log_output != NULL) {
    free(serial_p->se_log_output);
  }
  if (serial_p->se_log_debug != NULL) {
    free(serial_p->se_log_debug);
  }
  
  if (serial_p->se_lines != NULL) {
    _script_free_lines(serial_p);
  }
  if (serial_p->se_labels != NULL) {
    _script_free_labels(serial_p);
  }
  
  free(serial_p);
  return SERIAL_ERROR_NONE;
}

/***************************** exported routines *****************************/

/*
 * Start the transactions with a serial port opened for input with
 * IN_FD and output with OUT_FD, attached to PATH (which can be null).
 * Returns pointer to new struct or NULL on error.  Passes back serial
 * error codes in ERROR_P.
 */
serial_t	*serial_start(const int in_fd, const int out_fd,
			      const char *path, int *error_p)
{
  serial_t	*serial_p;
  
  serial_p = (serial_t *)malloc(sizeof(serial_t));
  if (serial_p == NULL) {
    if (error_p != NULL) {
      *error_p = SERIAL_ERROR_ALLOC;
    }
    return NULL;
  }
  
  serial_p->se_flags = DEFAULT_FLAGS;
  serial_p->se_in_fd = in_fd;
  serial_p->se_out_fd = out_fd;
  serial_p->se_path = (char *)path;
  serial_p->se_timeout.tv_sec = -1;
  serial_p->se_max_chars = -1;
  serial_p->se_log_input = (FILE **)calloc(MAX_FILES, sizeof(FILE *));
  serial_p->se_log_output = (FILE **)calloc(MAX_FILES, sizeof(FILE *));
  serial_p->se_log_debug = (FILE **)calloc(MAX_FILES, sizeof(FILE *));
  serial_p->se_buf = (char *)malloc(BUFFER_SIZE);
  serial_p->se_end_p = serial_p->se_buf;
  serial_p->se_line_c = 0;
  serial_p->se_lines = NULL;
  serial_p->se_label_c = 0;
  serial_p->se_labels = NULL;
  
  /* check the allocs all together */
  if (serial_p->se_log_input == NULL || serial_p->se_log_output == NULL
      || serial_p->se_log_debug == NULL || serial_p->se_buf == NULL) {
    (void)serial_free(serial_p);
    if (error_p != NULL) {
      *error_p = SERIAL_ERROR_ALLOC;
    }
    return NULL;
  }
  
  /* get the current terminal modes */
  (void)tcgetattr(in_fd, &serial_p->se_term);
  
  return serial_p;
}

/*
 * End transactions with a serial device in SERIAL_P.  Returns serial
 * error codes.
 */
int	serial_end(serial_t *serial_p)
{
  return serial_free(serial_p);
}

/*
 * Set with stty-style COMMAND for serial line opened with IN_FD. if
 * EXCL then clear all other flags before setting this command.
 * Returns serial error codes.
 */
int	serial_stty(serial_t *serial_p, const char *command, const char excl)
{
  int	ret;
  
  ret = _stty_do(serial_p->se_in_fd, command, excl,
		 &serial_p->se_term);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  ret = _stty_do(serial_p->se_out_fd, command, excl,
		 &serial_p->se_term);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Load a script from INFILE into SERIAL_P buffer in preparation for a
 * serial_run.  ARGS are used to insert strings into the
 * script. Returns serial error codes.
 */
int	serial_load(serial_t *serial_p, FILE *infile,
		    const serial_arg_t *args)
{
  int	ret;
  
  ret = _script_load(serial_p, infile, args);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Write a script from SERIAL_P to OUTFILE possibly in BINARY format
 * and possible LOCKED so it cannot be re-written.  Returns serial
 * error codes.
 */
int	serial_write(serial_t *serial_p, FILE *outfile, const int type)
{
  int	ret;
  
  if (BIT_IS_SET(serial_p->se_flags, SCRIPT_LOCKED)) {
    return SERIAL_ERROR_LOCKED;
  }
  
  ret = _script_write(serial_p, outfile, type);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Run a script on IN_FD from file opened to FILE_P starting at LABEL
 * (if NULL then the top) this passes back an error CODE_P and static
 * string message in STR_P (if either not NULL).  Returns serial error
 * codes.
 */
int	serial_script(serial_t *serial_p, const char *label,
		      int *code_p, char **str_p)
{
  int	ret;
  
  ret = _script_run(serial_p, label, code_p, str_p);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Lock via uucp protocols the path associated with SERIAL_P.  Returns
 * serial error codes.
 */
int	serial_lock(serial_t *serial_p)
{
  int	ret;
  
  ret = _script_lock(serial_p);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Unlock via uucp protocols the path associated with SERIAL_P.
 * Returns serial error codes.
 */
int	serial_unlock(serial_t *serial_p)
{
  int	ret;
  
  ret = _script_unlock(serial_p);
  if (ret != SERIAL_ERROR_NONE) {
    return ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Lock via uucp protocols the PORT.  PORT should contain no special
 * characters, and not overlap with the name of any device that may be
 * locked in the uucp lock area.  Returns serial error codes.
 */
int	serial_lock_port(const char *port)
{
  int	ret;
  
  ret = uucp_lock(port);
  if (ret == 1) {
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_LOCK;
  }
}

/*
 * Unlock via uucp protocols the PORT.  PORT should contain no special
 * characters, and not overlap with the name of any device that may be
 * locked in the uucp lock area.  Returns serial error codes.
 */
int	serial_unlock_port(const char *port)
{
  int	ret;
  
  ret = uucp_unlock(port);
  if (ret == 1) {
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_UNLOCK;
  }
}

/*
 * Set the timeout value for SERIAL_P.  Set tv_sec to -1 to disable
 * the timeout.  Returns serial error codes.
 */
int	serial_timeout(serial_t *serial_p, struct timeval *timeout_p)
{
  serial_p->se_timeout = *timeout_p;
  
  if (serial_p->se_timeout.tv_sec < 0) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Timeout disabled\n");
  }
  else {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Timeout: %ld sec, %ld usec\n",
		      serial_p->se_timeout.tv_sec,
		      serial_p->se_timeout.tv_usec);
  }
  return SERIAL_ERROR_NONE;
}

/**************************** log file functions *****************************/

/*
 * Add a file-pointer FILE_P of WHICH type (see serial.h) to the serial
 * connection in SERIAL_P.  Returns serial error codes.
 */
int	serial_log_add(const serial_t *serial_p, const int which, FILE *file_p)
{
  int		file_c;
  FILE		**grid = NULL;
  
  switch (which) {
    
  case SERIAL_LOG_INPUT:
    grid = serial_p->se_log_input;
    break;
    
  case SERIAL_LOG_OUTPUT:
    grid = serial_p->se_log_output;
    break;
    
  case SERIAL_LOG_DEBUG:
    grid = serial_p->se_log_debug;
    break;
    
  default:
    return SERIAL_ERROR_ARG;
    break;
  }
  
  /* find an open slot if any */
  for (file_c = 0; file_c < MAX_FILES; file_c++) {
    if (grid[file_c] == NULL) {
      break;
    }
  }
  
  if (file_c >= MAX_FILES) {
    return SERIAL_ERROR_LOGSLOT;
  }
  
  grid[file_c] = file_p;
  
  return SERIAL_ERROR_NONE;
}

/*
 * Remove a file-pointer FILE_P of WHICH type (see serial.h) from the
 * serial connection in SERIAL_P.  Returns serial error codes.
 */
int	serial_log_remove(const serial_t *serial_p, const int which,
			  FILE *file_p)
{
  int		file_c;
  FILE		**grid = NULL;
  int		found_b = 0;
  
  switch (which) {
    
  case SERIAL_LOG_INPUT:
    grid = serial_p->se_log_input;
    break;
    
  case SERIAL_LOG_OUTPUT:
    grid = serial_p->se_log_output;
    break;
    
  case SERIAL_LOG_DEBUG:
    grid = serial_p->se_log_debug;
    break;
    
  default:
    return SERIAL_ERROR_ARG;
    break;
  }
  
  for (file_c = 0; file_c < MAX_FILES; file_c++) {
    if (grid[file_c] == file_p) {
      grid[file_c] = NULL;
      found_b = 1;
      /* don't break in case its in there twice (for some reason) */
    }
  }
  
  if (found_b) {
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_REMOVE;
  }
}

/*
 * Log a printf like message to SERIAL_P's log entries of WHICH type
 * (see serial.h) using FORMAT and ...  Returns serial error codes.
 *
 * NOTE: this depends on the log_open/close status from the script._
 */
int	serial_log_printf(const serial_t *serial_p, const int which,
			  const char *format, ...)
{
  va_list	args;
  int		file_c;
  FILE		**grid = NULL;
  
  switch (which) {
    
  case SERIAL_LOG_INPUT:
    if (BIT_IS_SET(serial_p->se_flags, INPUT_ENABLED)) {
      grid = serial_p->se_log_input;
    }
    break;
    
  case SERIAL_LOG_OUTPUT:
    if (BIT_IS_SET(serial_p->se_flags, OUTPUT_ENABLED)) {
      grid = serial_p->se_log_output;
    }
    break;
    
  case SERIAL_LOG_DEBUG:
    if (BIT_IS_SET(serial_p->se_flags, DEBUG_ENABLED)) {
      grid = serial_p->se_log_debug;
    }
    break;
  }
  
  if (grid == NULL) {
    return SERIAL_ERROR_ARG;
  }
  
  va_start(args, format);
  
  for (file_c = 0; file_c < MAX_FILES; file_c++) {
    if (grid[file_c] != NULL) {
      (void)vfprintf(grid[file_c], format, args);
      /* flush only the debug stream */
      if (which == SERIAL_LOG_DEBUG) {
	(void)fflush(grid[file_c]);
      }
    }
  }
  
  va_end(args);
  
  return SERIAL_ERROR_NONE;
}

/*
 * Log a printf like message to SERIAL_P's log entries of WHICH type
 * (see serial.h) using FORMAT and ...  Returns serial error codes.
 *
 * NOTE: this depends on the log_open/close status from the script._
 */
int	serial_log_fwrite(const serial_t *serial_p, const int which,
			  const char *buf, const int size, const int count)
{
  int		file_c;
  FILE		**grid = NULL;
  
  switch (which) {
    
  case SERIAL_LOG_INPUT:
    if (BIT_IS_SET(serial_p->se_flags, INPUT_ENABLED)) {
      grid = serial_p->se_log_input;
    }
    break;
    
  case SERIAL_LOG_OUTPUT:
    if (BIT_IS_SET(serial_p->se_flags, OUTPUT_ENABLED)) {
      grid = serial_p->se_log_output;
    }
    break;
    
  case SERIAL_LOG_DEBUG:
    if (BIT_IS_SET(serial_p->se_flags, DEBUG_ENABLED)) {
      grid = serial_p->se_log_debug;
    }
    break;
  }
  
  if (grid == NULL) {
    return SERIAL_ERROR_ARG;
  }
  
  for (file_c = 0; file_c < MAX_FILES; file_c++) {
    if (grid[file_c] != NULL) {
      (void)fwrite(buf, size, count, grid[file_c]);
    }
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Return the string equivalent of serial ERROR.
 */
char	*serial_strerror(const int error)
{
  error_str_t	*err_p;
  
  for (err_p = errors; err_p->es_error != 0; err_p++) {
    if (err_p->es_error == error) {
      return err_p->es_string;
    }
  }
  
  return INVALID_ERROR;
}
