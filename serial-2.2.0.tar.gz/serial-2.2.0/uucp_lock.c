/*
 * standard uucp locking routines
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: uucp_lock.c,v 1.14 2000/03/09 03:49:09 gray Exp $
 */

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/param.h>

#include "uucp_lock.h"

#if INCLUDE_RCS_IDS
static	char	*rcs_id =
  "$Id: uucp_lock.c,v 1.14 2000/03/09 03:49:09 gray Exp $";
#endif

#define LOCK_FILE_MODE		0644
#define LOCK_UMASK		0022

/*
 * Return a lock-file path in DIR for FILE.
 */
static	char	*make_lock(const char *dir, const char *file)
{
  static char	path[1024];
  const char	*path_p;
  
  /* pull out the file name only */
  path_p = strrchr(file, '/');
  if (path_p == NULL) {
    path_p = file;
  }
  else {
    path_p++;
  }
  
  (void)sprintf(path, "%s/LCK..%s", dir, path_p);
  return path;
}

/*
 * Lock PORT (either /dev/file or just file).  PORT is a file name
 * which should be created in the lock directory.  Returns 1 on
 * success else 0.
 *
 * NOTE: lots of race conditions here.
 */
int	uucp_lock(const char *port)
{
  const char	*path;
  int		pid, fd, ret, mask;
  char		tempfile[1024], buf[128], final = 0;
  
  path = make_lock(UUCP_LOCK_DIR, port);
  pid = getpid();
  
  (void)sprintf(tempfile, "%s.t", path);
  
  mask = umask(LOCK_UMASK);
  
  fd = open(tempfile, O_WRONLY | O_CREAT | O_EXCL, LOCK_FILE_MODE);
  if (fd < 0) {
    (void)umask(mask);
    return 0;
  }
  
  (void)sprintf(buf, "%10d\n", pid);
  ret = write(fd, buf, strlen(buf));
  (void)close(fd);
  
  /* write problems? */
  if (ret < (int)strlen(buf)) {
    (void)unlink(tempfile);
    (void)umask(mask);
    return 0;
  }
  
  for (;;) {
    int		read_n, lock_pid;
    
    ret = link(tempfile, path);
    if (ret == 0) {
      /*
       * NOTE: we can check to see if we did indeed get the lock by
       * re-reading the file here.  we could also sleep in the middle
       * to [maybe] assure that someone else would finish blowing our
       * lock file before checking.
       */
      final = 1;
      break;
    }
    
    /* did we get an error other than file exists? */
    if (errno != EEXIST) {
      break;
    }
    
    /* open the existing lock file */
    fd = open(path, O_RDONLY, 0);
    if (fd < 0) {
      if (errno == ENOENT) {
	/* hmm, maybe it was removed.  try link again */
	continue;
      }
      break;
    }
    
    /* read in the pid of the process holding the lock */
    read_n = read(fd, buf, sizeof(buf) - 1);
    (void)close(fd);
    
    if (read_n <= 0) {
      break;
    }
    
    buf[read_n] = '\0';
    lock_pid = strtol(buf, NULL, 10);
    
    /* what?  I guess we've locked it before */
    if (lock_pid == pid) {
      final = 1;
      break;
    }
    
    /* does the process exist? */
    if (kill(lock_pid, 0) == 0 || errno == EPERM) {
      break;
    }
    
    /*
     * WARNING: race condition here.  someone could zip in here unlink
     * and create and then we would be blowing their lock away.
     * YIKES!  Or someone could blow ours away.  Not much we can do
     * about it.
     */
    
    /* remove the stale lock [and hopefully not someone else's] */
    (void)unlink(path);
    /* don't check error since someone might have done it already */
  }
  
  (void)unlink(tempfile);
  (void)umask(mask);
  
  return final;
}

/*
 * Unlock file in PORT (either /dev/file or just file).  Returns 1 on
 * success else 0.
 */
int	uucp_unlock(const char *port)
{
  const char	*path;
  char		buf[128];
  int		pid, fd, read_n, lock_pid;
  
  path = make_lock(UUCP_LOCK_DIR, port);
  pid = getpid();
  
  /* open the existing lock file */
  fd = open(path, O_RDONLY, 0);
  if (fd < 0) {
    return 0;
  }
  
  /* read in the pid of the process holding the lock */
  read_n = read(fd, buf, sizeof(buf) - 1);
  (void)close(fd);
  
  if (read_n <= 0) {
    return 0;
  }
  
  buf[read_n] = '\0';
  lock_pid = strtol(buf, NULL, 10);
  
  /* if it is our pid and the unlink succeeds */
  if (lock_pid == pid && unlink(path) == 0) {
    return 1;
  }
  else {
    return 0;
  }
}

/*
 * Return the path to the lock file for PORT.
 */
char	*uucp_path(const char *port)
{
  return make_lock(UUCP_LOCK_DIR, port);
}
