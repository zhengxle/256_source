/*
 * local script defines
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: script_loc.h,v 1.20 2000/03/09 03:49:06 gray Exp $
 */

#ifndef __SCRIPT_LOC_H__
#define __SCRIPT_LOC_H__

#include "script_tok.h"			/* for token_t */

#define LABEL_SIZE	1024		/* size of label string */
#define PASS_SIZE	1024		/* size of pass-back string */
#define PATTERN_SIZE	1024		/* size of pattern string */
#define ERROR_SIZE	256		/* size of error string */

#define MATCH_MAX	30		/* 30 matches allowed */
#define NUM_VARIABLES	100		/* number of internal variables */

#define LINE_INCR	20		/* line allocation increment */
#define LABEL_INCR	5		/* label allocation increment */

#define NULLC_REPLACE	'\377'		/* replace nullc with \377 */
#define ACCEPT_CHARS	"\r\n"		/* accept interactive input */
#define OVERWRITE_CHAR	' '		/* overwrite in match */

#define MAGIC_BINARY	0xB101B01	/* magic long at start of bin files */
#define MAGIC_LOCKED	0xB010B10	/* magic for bin and locked files */

#define SBUF_SIZE(s)	((s)->se_end_p - (s)->se_buf)

#endif /* ! __SCRIPT_LOC_H__ */
