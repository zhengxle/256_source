/*
 * local serial defines
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: serial_loc.h,v 1.26 2000/03/09 03:49:07 gray Exp $
 */

#ifndef __SERIAL_LOC_H__
#define __SERIAL_LOC_H__

#include <stdio.h>
#include <termios.h>

#include "script_tok.h"			/* for token_t */

#define LINE_SIZE	1024		/* max size of script lines */
#define MAX_THREADS	20		/* number of open files at a time */
#define MAX_FILES	10		/* maximum number of log files */
#define FD_UNDEF	(-1)		/* fd slot is not used */

#define BUFFER_SIZE	4096		/* input buffer size */
#define BUFFER_OVERFLOW	3072		/* byte count when overflow */
#define BUFFER_WRAP	1024		/* wrap bytes when overflow */

#undef	MIN
#define MIN(a,b)	((a) < (b) ? (a) : (b))

/*
 * bitflag tools for Variable and a Flag
 */
#define BIT_FLAG(x)		(1 << (x))
#define BIT_SET(v,f)		(v) |= (f)
#define BIT_CLEAR(v,f)		(v) &= ~(f)
#define BIT_IS_SET(v,f)		((v) & (f))
#define BIT_TOGGLE(v,f)		(v) ^= (f)

/*
 * storage for a line of a script
 */
struct line_st {
  token_t		*li_token_p;	/* reserved work token pointer */
  union {
    int			va_int;		/* integer argument value */
    char		*va_char_p;	/* string argument value */
    struct line_st	*va_line_p;	/* line argument for gotos */
  } li_value;
};
typedef struct line_st	line_t;

/*
 * storage for a line of a script
 */
typedef struct {
  char		*sl_string;		/* string part of the label */
  int		sl_index;		/* line index it refers to */
} script_label_t;

typedef struct {
  int		se_flags;		/* flags for the connection */
  
  int		se_in_fd;		/* reference value and i/o desc. */
  int		se_out_fd;		/* output i/o desc. */
  char		*se_path;		/* path to device (maybe null) */
  
  struct termios se_term;		/* terminal modes */
  struct timeval se_timeout;		/* current timeout value */
  int		se_max_chars;		/* max chars to read (or -1 if max) */
  
  FILE		**se_log_input;		/* input log streams */
  FILE		**se_log_output;	/* output log streams */
  FILE		**se_log_debug;		/* debug log streams */
  
  char		*se_buf;		/* input buffer */
  char		*se_end_p;		/* end of input buffer */
  
  int		se_line_c;		/* number of script lines */
  line_t	*se_lines;		/* lines of the script */
  int		se_label_c;		/* number of script lines */
  script_label_t *se_labels;		/* labels in the script */
} serial_t;

#define TIMEOUT_P(s)	((s)->se_timeout.tv_sec < 0 ? NULL : \
			 &((s)->se_timeout))
#define DEFAULT_FLAGS	(DEBUG_ENABLED | FLUSH_MATCH)

/* flag values */
#define INPUT_ENABLED	BIT_FLAG(0)	/* input logging enabled */
#define OUTPUT_ENABLED	BIT_FLAG(1)	/* output logging enabled */
#define DEBUG_ENABLED	BIT_FLAG(2)	/* debug logging enabled (default) */
#define INTERACTIVE	BIT_FLAG(3)	/* interactive mode */
#define PASSWORD	BIT_FLAG(4)	/* password (no-echo) mode */
#define FLUSH_MATCH	BIT_FLAG(5)	/* auto-flush when match (default) */
#define FLUSH_SEARCH	BIT_FLAG(6)	/* auto-flush when search */
#define OVERWRITE_MATCH	BIT_FLAG(7)	/* overwrite bufs on match */
#define PORT_LOCKED	BIT_FLAG(8)	/* is the port locked? */
#define BINARY_INPUT	BIT_FLAG(9)	/* input was binary */
#define SCRIPT_LOCKED	BIT_FLAG(10)	/* script is locked, cant be written */

/*
 * to map error to string
 */
typedef struct {
  int		es_error;		/* error number */
  char		*es_string;		/* assocaited string */
} error_str_t;

static	error_str_t	errors[] = {
  { SERIAL_ERROR_NONE,		"no error" },
  { SERIAL_ERROR_ARG,		"improper argument to function" },
  { SERIAL_ERROR_ALLOC,		"problem allocating memory" },
  { SERIAL_ERROR_LOCKED,	"input script is locked" },
  { SERIAL_ERROR_DEVREAD,	"could not read from device" },
  { SERIAL_ERROR_DEVWRITE,	"could not write to device" },
  { SERIAL_ERROR_SCRREAD,	"could not read from script" },
  { SERIAL_ERROR_SCRWRITE,	"could not write to script" },
  { SERIAL_ERROR_TIMEOUT,	"waiting for input timed out" },
  { SERIAL_ERROR_STTY,		"improper stty token in script" },
  { SERIAL_ERROR_MODES,		"could not set new stty modes" },
  { SERIAL_ERROR_FLUSH,		"could not flush device" },
  { SERIAL_ERROR_LOGSLOT,	"no log file slots open" },
  { SERIAL_ERROR_REMOVE,	"tried to remove unknown log" },
  { SERIAL_ERROR_BINARY,	"bad token from binary script" },
  { SERIAL_ERROR_SCRIPT,	"problems with serial script" },
  { SERIAL_ERROR_REGCOMP,	"could not compie regex" },
  { SERIAL_ERROR_LABEL,		"tried to jump to unknown label" },
  { SERIAL_ERROR_LOCK,		"could not lock port" },
  { SERIAL_ERROR_UNLOCK,	"could not unlock port" },
  { 0 }
};

#define INVALID_ERROR	"invalid error code"

#endif /* ! __SERIAL_LOC_H__ */
