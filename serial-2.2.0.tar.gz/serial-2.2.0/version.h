/*
 * version string for the library
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: version.h,v 1.12 2000/03/09 03:53:12 gray Exp $
 */

/*
 * NOTE to gray: whenever this is changed, a corresponding Changlog
 * entry *must* be entered and a NEWS entry probably needs to be
 * added.
 */
static	char	*serial_version = "2.2.0";

/* Version Date: $Date: 2000/03/09 03:53:12 $ */
