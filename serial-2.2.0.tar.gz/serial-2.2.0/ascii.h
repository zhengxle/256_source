/*
 * ascii character definitions
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: ascii.h,v 1.2 2000/03/09 03:49:04 gray Exp $
 */

#ifndef __ASCII_H__
#define __ASCII_H__

#define ASCII_CONTROL_A			'\001'
#define ASCII_CONTROL_B			'\002'
#define ASCII_CONTROL_C			'\003'
#define ASCII_CONTROL_D			'\004'
#define ASCII_CONTROL_E			'\005'
#define ASCII_CONTROL_F			'\006'
#define ASCII_CONTROL_G			'\007'
#define ASCII_CONTROL_H			'\010'
#define ASCII_CONTROL_I			'\011'
#define ASCII_CONTROL_J			'\012'
#define ASCII_CONTROL_K			'\013'
#define ASCII_CONTROL_L			'\014'
#define ASCII_CONTROL_M			'\015'
#define ASCII_CONTROL_N			'\016'
#define ASCII_CONTROL_O			'\017'
#define ASCII_CONTROL_P			'\020'
#define ASCII_CONTROL_Q			'\021'
#define ASCII_CONTROL_R			'\022'
#define ASCII_CONTROL_S			'\023'
#define ASCII_CONTROL_T			'\024'
#define ASCII_CONTROL_U			'\025'
#define ASCII_CONTROL_V			'\026'
#define ASCII_CONTROL_W			'\027'
#define ASCII_CONTROL_X			'\030'
#define ASCII_CONTROL_Y			'\031'
#define ASCII_CONTROL_Z			'\032'

#define ASCII_DELETE			'\177'

#endif
