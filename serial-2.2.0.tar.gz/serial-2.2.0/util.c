/*
 * Miscellaneous library functions...
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: util.c,v 1.9 2000/03/09 03:49:09 gray Exp $
 */

/*
 * A number of string functions written to preserve the sanity of the
 * programmers that compile in BSD *and* SysV world.
 */

#include <ctype.h>
#include <stdio.h>

#include "util.h"

#if INCLUDE_RCS_IDS
LOCAL	char	*rcs_id =
  "$Id: util.c,v 1.9 2000/03/09 03:49:09 gray Exp $";
#endif

#define	MAX_STRING_LENGTH	10240	/* size of largest string */
/*
 * special \ characters to be mapped.
 * NOTE: \E is before \e so we can generate \E for termcap.
 */
#define SPECIAL_CHARS		"E\033e\033^^\"\"''\\\\n\nr\rt\tb\bf\fa\007"

/*
 * Display printable chars from BUF of SIZE, non-printables as \%03o
 */
char	*_expand_buf(const void *buf, const int size)
{
  static char	out[MAX_STRING_LENGTH];
  const char	*buf_p;
  char		*out_p;
  
  for (buf_p = buf, out_p = out; buf_p < (char *)buf + size; buf_p++) {
    char	*specp;
    
    /* handle special chars */
    if (out_p + 2 >= out + sizeof(out))
      break;
    
    /* search for special characters */
    for (specp = SPECIAL_CHARS + 1; *(specp - 1) != '\0'; specp += 2)
      if (*specp == *buf_p)
	break;
    
    /* did we find one? */
    if (*(specp - 1) != '\0') {
      if (out_p + 2 >= out + sizeof(out))
	break;
      (void)sprintf(out_p, "\\%c", *(specp - 1));
      out_p += 2;
      continue;
    }
    
    if (*(unsigned char *)buf_p < 128 && isprint(*buf_p)) {
      if (out_p + 1 >= out + sizeof(out))
	break;
      *out_p = *buf_p;
      out_p += 1;
    }
    else {
      if (out_p + 4 >= out + sizeof(out))
	break;
      (void)sprintf(out_p, "\\%03o", *(unsigned char *)buf_p);
      out_p += 4;
    }
  }
  
  *out_p = '\0';
  return out;
}

/*
 * Display printable chars from STR normally, non-printables as \%03o
 */
char	*_expand_string(const char *str)
{
  return _expand_buf(str, strlen(str));
}

/*
 * Reverse of expand_string, translates "\\003" into '\003' in string
 * STR and passes back length in LEN_P (if not null) into static 2k
 * buffer that it returns.
 */
char	*_decode_buf(const char *str, int *len_p)
{
  static char	out[MAX_STRING_LENGTH];
  unsigned char	ch;				/* needs to be this */
  const char	*str_p;
  char		*out_p, *slashs;
  int		digc;
  
  for (str_p = str, out_p = out; *str_p != '\0';) {
    
    ch = *str_p++;
    
    switch (ch) {
      
    case '\\':
      /* try and find special character in slash list */
      for (slashs = SPECIAL_CHARS; *slashs != '\0'; slashs++)
	if (*slashs++ == *str_p)
	  break;
      
      if (*slashs != '\0') {
	/* we found a special char */
	ch = *slashs;
	str_p++;
      } else if (! isdigit(*str_p)) {
	/* \c which c is not in the above list nor a digit returns c */
	ch = *str_p++;
      }
      else {
	/* try and translate an octal number */
	ch = 0;
	
	for (digc = 0; digc < 3 && isdigit(*str_p); digc++) {
	  ch *= 8;
	  ch += *str_p++ - '0';
	}
	
	/* if failure, then copy all of the processed string out */
	if (digc < 3) {
	  str_p -= digc;
	  ch = *str_p++;
	}
      }
      break;
      
    default:
      break;
    }
    
    if (out_p + 1 >= out + sizeof(out))
      break;
    *out_p++ = ch;
  }
  
  /* punch the NULL */
  *out_p = '\0';
  
  if (len_p != NULL)
    *len_p = out_p - out;
  
  return out;
}

/*
 * Reverse of expand_string, translates "\\003" into '\003' in string
 * STR into static 2k buffer that it returns.
 */
char	*_decode_string(const char *str)
{
  return _decode_buf(str, NULL);
}
