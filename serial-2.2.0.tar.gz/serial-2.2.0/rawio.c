/*
 * Collection of rawio functions...
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: rawio.c,v 1.24 2000/03/09 03:49:04 gray Exp $
 */

#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

#define SERIAL_MAIN

#include "ascii.h"
#include "rawio.h"
#include "serial.h"
#include "serial_loc.h"

#if INCLUDE_RCS_IDS
LOCAL	char	*rcs_id =
  "$Id: rawio.c,v 1.24 2000/03/09 03:49:04 gray Exp $";
#endif

#define READ_LINE_BUFSIZE	1024		/* read_line bufsize */
#define CRLF			"\r\n"		/* well, cr-lf */
#define MAX_LINES		40		/* max lines for ^l */

/*
 * Write a BUF of LEN to filedesc FD with TIMEOUT_P.  Returns
 * serial error codes.
 */
int	_rawio_write(const int fd, const void *buf, const int len,
		     struct timeval *timeout_p)
{
  fd_set	writefds;
  int		count, ret;
  void		*buf_p;
  
  buf_p = (void *)buf;
  count = len;
  
  /* write str to fd */
  FD_ZERO(&writefds);
  while (count > 0) {
    FD_SET(fd, &writefds);
    
    if (select(fd + 1, NULL, &writefds, NULL, timeout_p) <= 0) {
      return SERIAL_ERROR_DEVWRITE;
    }
    
    ret = write(fd, buf_p, count);
    if (ret < 0) {
      return SERIAL_ERROR_DEVWRITE;
    }
    
    if (ret > 0) {
      buf_p = (char *)buf_p + ret;
      count -= ret;
    }
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Read from FD into BUF_P (of MAX chars) or until we reach TIMEOUT_P.
 * Pass back the # chars read in SIZE_P (if not null).  Returns
 * serial error codes.
 */
int	_rawio_read(const int fd, struct timeval *timeout_p,
		    void *buf_p, int max, int *size_p)
{
  int		ret;
  fd_set	readfds;
  
  /* read into the buffer */
  FD_ZERO(&readfds);
  FD_SET(fd, &readfds);
  
  for (;;) {
    ret = select(fd + 1, &readfds, NULL, NULL, timeout_p);
    if (ret < 0) {
      return SERIAL_ERROR_DEVREAD;
    }
    if (ret == 0) {
      ret = 0;
      break;
    }
    
    ret = read(fd, buf_p, max);
    if (ret >= 0) {
      break;
    }
  }
  
  if (size_p != NULL) {
    *size_p = ret;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Interactively enter characters into LINE of MAX size from FDIN
 * passing back SIZE_P (if not null).  Echo chars to FDOUT if ECHO is
 * true, with IN_SECS input timeout and OUT_SECS out_put timeout.  The
 * user is finished with string when on of the ACCEPT chars is
 * pressed.  It is added to the ouput.  Handles \h, ^l, ^r, ^u, ^?.
 * Returns [NO]ERROR.
 */
int	_rawio_prompt(const int fdin, const int fdout, char *line,
		      const int max, int *size_p, struct timeval *in_p,
		      struct timeval *out_p, const char *accept,
		      const char echo)
{
  static char	input_buffer[READ_LINE_BUFSIZE];
  int		max_n, readc, ret;
  char		*buf_p, *linep = line;
  
  max_n = MIN(max, READ_LINE_BUFSIZE);
  
  for (;;) {
    ret = _rawio_read(fdin, in_p, (void *)input_buffer, max_n - (linep - line),
		      &readc);
    if (ret != SERIAL_ERROR_NONE) {
      return ret;
    }
    
    /* did the read timeout? */
    if (readc == 0) {
      line[0] = '\0';
      *size_p = 0;
      (void)_rawio_write(fdout, CRLF, sizeof(CRLF) - 1, out_p);
      return SERIAL_ERROR_NONE;
    }
    
    /* process characters in the buffer */
    for (buf_p = input_buffer; readc > 0; readc--, buf_p++) {
      
      /* handle printable characters */
      if (isprint(*buf_p)) {
	if (linep < line + max_n) {
	  *linep++ = *buf_p;
	  if (echo) {
	    ret = _rawio_write(fdout, buf_p, sizeof(char), out_p);
	    if (ret != SERIAL_ERROR_NONE) {
	      return ret;
	    }
	  }
	}
	continue;
      }
      
      /* ignore NULLs */
      if (*buf_p == '\0') {
	continue;
      }
      
      if (strchr(accept, *buf_p) != NULL) {
	*linep++ = *buf_p;
	*linep = '\0';
	
	if (size_p != NULL) {
	  *size_p = linep - line;
	}
	
	ret = _rawio_write(fdout, CRLF, sizeof(CRLF) - 1, out_p);
	return ret;
	/*NOTREACHED*/
      }
      
      switch (*buf_p) {
	
	/* erase a character if any */
      case '\b':
      case ASCII_DELETE:
	if (linep != line) {
	  linep--;
	  if (echo) {
	    ret = _rawio_write(fdout, "\b \b", 3, out_p);
	    if (ret != SERIAL_ERROR_NONE) {
	      return ret;
	    }
	  }
	}
	break;
	
	/* redraw-screen / then line */
      case ASCII_CONTROL_L:
	if (echo) {
	  int	linec;
	  
	  for (linec = 0; linec < MAX_LINES; linec++) {
	    ret = _rawio_write(fdout, CRLF, sizeof(CRLF) - 1, out_p);
	    if (ret != SERIAL_ERROR_NONE) {
	      return ret;
	    }
	  }
	  *linep = '\0';
	  ret = _rawio_write(fdout, line, linep - line, out_p);
	  if (ret != SERIAL_ERROR_NONE) {
	    return ret;
	  }
	}
	break;
	
	/* redraw-line */
      case ASCII_CONTROL_R:
	if (echo) {
	  ret = _rawio_write(fdout, CRLF, sizeof(CRLF) - 1, out_p);
	  *linep = '\0';
	  ret = _rawio_write(fdout, line, linep - line, out_p);
	  if (ret != SERIAL_ERROR_NONE) {
	    return ret;
	  }
	}
	break;
	
	/* erase line */
      case ASCII_CONTROL_U:
	/* reset pointers */
	linep = line;
	if (echo) {
	  ret = _rawio_write(fdout, CRLF, sizeof(CRLF) - 1, out_p);
	  if (ret != SERIAL_ERROR_NONE) {
	    return ret;
	  }
	}
	break;
	
	/* all other non-printables are ignored */
      default:
	break;
      }
    }
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Watch the port in FD until we see a char or timeout after SECS.
 * Returns serial error codes: SERIAL_ERROR_TIMEOUT if SECS passed or
 * SERIAL_ERROR_NONE if it read something in that time.
 */
int	_rawio_watch(const int fd, struct timeval *timeout_p)
{
  fd_set	readfds;
  int		ret;
  
  /* read into the buffer */
  FD_ZERO(&readfds);
  FD_SET(fd, &readfds);
  
  ret = select(fd + 1, &readfds, NULL, NULL, timeout_p);
  if (ret == 0) {
    return SERIAL_ERROR_TIMEOUT;
  }
  else if (ret < 0) {
    return SERIAL_ERROR_DEVREAD;
  }
  else {
    return SERIAL_ERROR_NONE;
  }
}
