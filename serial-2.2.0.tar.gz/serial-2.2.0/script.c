/*
 * script processing routines.
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: script.c,v 1.52 2000/03/09 03:49:05 gray Exp $
 */

#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <regex.h>

#define SERIAL_MAIN

#include "uucp_lock.h"

#include "rawio.h"
#include "script.h"
#include "script_loc.h"
#include "script_tok.h"
#include "serial.h"
#include "serial_loc.h"
#include "stty.h"
#include "util.h"

#if INCLUDE_RCS_IDS
static	char	*rcs_id =
  "$Id: script.c,v 1.52 2000/03/09 03:49:05 gray Exp $";
#endif

/* system routines */
extern	int		yylex(void);
extern	void		yyrestart(FILE * file_p);

/* system variables */
extern	FILE		*yyin;
extern	char		*yytext;
extern	int		yylineno;
extern	int		yylval;

/*
 * local variables
 */
static	int		script_enabled_b = 0;		/* startup flag */
static	token_t		*token_grid[TOK_MAXIMUM];	/* token x-reference */

/***************************** startup functions *****************************/

/*
 * startup the module
 */
static	void	script_startup(void)
{
  int		token;
  token_t	**grid_p, *token_p;
  
  if (script_enabled_b) {
    return;
  }
  script_enabled_b = 1;
  
  /* create the token cross reference grid */
  for (token = 0, grid_p = token_grid; token < TOK_MAXIMUM;
       token++, grid_p++) {
    for (token_p = reserved_tokens; token_p->to_string != NULL; token_p++) {
      if (token_p->to_id == token) {
	break;
      }
    }
    if (token_p->to_string == NULL) {
      *grid_p = NULL;
    }
    else {
      *grid_p = token_p;
    }
  }
}

/****************************** token functions ******************************/

/*
 * Cleanup (and free) STR after returned by lexer.  Return the length
 * in LEN_P.
 */
static	char	*fix_string(char *string, int *len_p, const serial_arg_t *args)
{
  const serial_arg_t	*arg_p;
  char			buf[1024], *buf_p;
  char			*ret, *tok_p;
  int			size;
  
  for (tok_p = string, buf_p = buf; *tok_p != '\0'; tok_p++) {
    
    /* handle not % or %% */
    if (*tok_p != '%') {
      *buf_p++ = *tok_p;
      continue;
    }
    tok_p++;
    /* ignore any %% */
    if (*tok_p == '%') {
      *buf_p++ = *tok_p;
      continue;
    }
    
    if (args != NULL) {
      for (arg_p = args;
	   arg_p->sa_token != '\0'; arg_p++) {
	if (arg_p->sa_token == *tok_p) {
	  if (arg_p->sa_value != NULL) {
	    (void)strcpy(buf_p, arg_p->sa_value);
	    buf_p += strlen(arg_p->sa_value);
	  }
	  break;
	}
      }
    }
  }
  *buf_p = '\0';
  
  ret = _decode_buf(buf, &size);
  if (len_p != NULL) {
    *len_p = size;
  }
  
  return ret;
}

/*
 * Get the next line/token from SERIAL_P in binary format while
 * applying ARGS and load it into LINE_P.  Returns serial error codes.
 */
static	int	binary_get_token(serial_t *serial_p, const serial_arg_t *args,
				 line_t *line_p, int *binary_line_p)
{
  int		tok, ret;
  token_t	*token_p;
  char		*text_p, buf[1024];
  
  /* get a token from the file */
  ret = fread(&tok, sizeof(tok), 1, yyin);
  if (ret != 1) {
    if (ret == 0 && feof(yyin)) {
      line_p->li_token_p = NULL;
      return SERIAL_ERROR_NONE;
    }
    return SERIAL_ERROR_SCRREAD;
  }
  
  /* improper token */
  if (tok < 1 || tok > TOK_MAXIMUM) {
    return SERIAL_ERROR_BINARY;
  }
  
  token_p = token_grid[tok];
  line_p->li_token_p = token_p;
  
  /* special case */
  if (tok == TOK_LABEL) {
    /* read the line number */
    ret = fread(binary_line_p, sizeof(*binary_line_p), 1, yyin);
    if (ret != 1) {
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Could not read label line found in binary file "
			"line %d: %s\n",
			token_p->to_string, yylineno, strerror(errno));
      return SERIAL_ERROR_SCRREAD;
    }
    
    /* read the label */
    for (text_p = buf;; text_p++) {
      ret = fgetc(yyin);
      if (ret == EOF) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Could not read token '%s' found in binary file "
			  "line %d: %s\n",
			  token_p->to_string, yylineno, strerror(errno));
	return SERIAL_ERROR_SCRREAD;
      }
      *text_p = ret;
      if (*text_p == '\0') {
	break;
      }
    }
    
    line_p->li_value.va_char_p = strdup(buf);
    yylineno++;
    return SERIAL_ERROR_NONE;
  }
  
  if (token_p->to_argument == TOK_NONE) {
    yylineno++;
    return SERIAL_ERROR_NONE;
  }
  
  if (token_p->to_argument == TOK_INT) {
    if (fread(&line_p->li_value.va_int, sizeof(line_p->li_value.va_int), 1,
	      yyin) != 1) {
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Could not read argument for token '%d' found "
			"in binary file line %d\n",
			tok, yylineno);
      return SERIAL_ERROR_SCRREAD;
    }
  }
  else if (token_p->to_argument == TOK_STRING
	   || token_p->to_argument == TOK_LABEL) {
    char	*str_p;
    
    for (text_p = buf;; text_p++) {
      ret = fgetc(yyin);
      if (ret == EOF) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Could not read token '%s' found in binary file "
			  "line %d: %s\n",
			  token_p->to_string, yylineno, strerror(errno));
	return SERIAL_ERROR_SCRREAD;
      }
      *text_p = ret;
      if (*text_p == '\0') {
	break;
      }
    }
    
    if (token_p->to_argument == TOK_STRING) {
      str_p = fix_string(buf, NULL, args);
    }
    else {
      str_p = buf;
    }
    
    line_p->li_value.va_char_p = strdup(str_p);
  }
  else {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Problem with token '%d' found in binary file line %d\n",
		      tok, yylineno);
    return SERIAL_ERROR_BINARY;
  }
  
  yylineno++;
  return SERIAL_ERROR_NONE;
}

/*
 * Get the next line/token from SERIAL_P in non-binary format while
 * applying ARGS and load it into LINE_P.  Returns serial error codes.
 */
static	int	script_get_token(serial_t *serial_p, const serial_arg_t *args,
				 line_t *line_p)
{
  int		tok, len;
  token_t	*token_p;
  
  /* get a token from the lexer */
  tok = yylex();
  if (tok == 0) {
    line_p->li_token_p = NULL;
    return SERIAL_ERROR_NONE;
  }
  
  /* special case -- label */
  if (tok == TOK_LABEL) {
    line_p->li_token_p = token_grid[tok];
    /* punch out the : */
    len = strlen(yytext);
    yytext[len - 1] = '\0';
    line_p->li_value.va_char_p = strdup(yytext);
    return SERIAL_ERROR_NONE;
  }
  
  if (tok != TOK_RESERVED) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Grammer error at line %d.  No reserved word '%s'\n",
		      yylineno, yytext);
    return SERIAL_ERROR_SCRIPT;
  }
  
  for (token_p = reserved_tokens; token_p->to_string != NULL; token_p++) {
    if (
#ifdef LOWERCASE_RESERVED
	strcasecmp(yytext, token_p->to_string) == 0
#else
	strcmp(yytext, token_p->to_string) == 0
#endif
	) {
      break;
    }
  }
  
  /* did we find it? */
  if (token_p->to_string == NULL) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Grammer error at line %d.  Unknown token '%s'\n",
		      yylineno, yytext);
    return SERIAL_ERROR_SCRIPT;
  }
  
  line_p->li_token_p = token_p;
  
  if (token_p->to_argument == TOK_NONE) {
    return SERIAL_ERROR_NONE;
  }
  
  /* get the argument token from the lexer */
  tok = yylex();
  
  /* we better have gotten the right argument */
  if (token_p->to_argument != tok) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Grammer error at line %d.  "
		      "Argument '%s' for '%s'.  Wrong type\n",
		      yylineno, yytext, token_p->to_string);
    return SERIAL_ERROR_SCRIPT;
  }
  
  if (tok == TOK_INT) {
    line_p->li_value.va_int = atoi(yytext);
  }
  else if (tok == TOK_STRING) {
    line_p->li_value.va_char_p = strdup(fix_string(yytext, NULL, args));
  }
  else if (tok == TOK_LABEL) {
    /* punch out the : */
    len = strlen(yytext);
    yytext[len - 1] = '\0';
    line_p->li_value.va_char_p = strdup(yytext);
  }
  else {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "Grammer error at line %d.  "
		      "Argument '%s' for '%s'.  Unknown type\n",
		      yylineno, yytext, token_p->to_string);
    return SERIAL_ERROR_SCRIPT;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Do a regex search for PATTERN in BUF of SIZE.  Passes back MATCH
 * flag and MATCHES_P regex matches.  Returns serial error codes.
 */
static	int	do_regex(const char *pat, char *buf,
			 const int size, int *match_bp,
			 regmatch_t **matches_p)
{
  static regmatch_t	matches[MATCH_MAX];
  regex_t		regex;
  char			*buf_p;
  
  *match_bp = 0;
  if (matches_p != NULL) {
    *matches_p = NULL;
  }
  
  /* compile the pattern */
  if (regcomp(&regex, pat, REG_EXTENDED) != 0) {
    return SERIAL_ERROR_REGCOMP;
  }
  
  /* '\0' -> \377 */
  for (buf_p = buf; buf_p < buf + size; buf_p++) {
    if (*buf_p == '\0') {
      *buf_p = NULLC_REPLACE;
    }
  }
  
  buf[size] = '\0';
  
  /* run the pattern */
  if (regexec(&regex, buf, MATCH_MAX, matches, 0) == 0) {
    *match_bp = 1;
    if (matches_p != NULL) {
      *matches_p = matches;
    }
  }
  
  regfree(&regex);
  
  return SERIAL_ERROR_NONE;
}

/*
 * Do a strstr search for PATTERN in BUF of SIZE.  Passes back MATCH
 * flag and the START and END offset of the match (shift = end + 1).
 */
static	void	do_strstr(const char *pat, char *buf, const int size,
			  int *match_bp, int *start, int *end)
{
  char		*buf_p;
  int		pat_len = strlen(pat);
  
  *match_bp = 0;
  
  /* '\0' -> \377 */
  for (buf_p = buf; buf_p < buf + size; buf_p++) {
    if (*buf_p == '\0') {
      *buf_p = NULLC_REPLACE;
    }
  }
  
  buf[size] = '\0';
  
  buf_p = (char *)strstr(buf, pat);
  if (buf_p == NULL) {
    *start = 0;
    if (size > pat_len) {
      *end = size - pat_len;
    }
    else {
      *end = 0;
    }
  }
  else {
    *match_bp = 1;
    *start = buf_p - buf;
    *end = *start + pat_len - 1;
  }
}

/*
 * Goto LABEL in FILE_P.  Return serial error codes.
 */
static	int	goto_label(serial_t *serial_p, const char *label,
			   line_t **line_p)
{
  script_label_t	*label_p;
  
  for (label_p = serial_p->se_labels;
       label_p < serial_p->se_labels + serial_p->se_label_c; label_p++) {
    if (strcmp(label_p->sl_string, label) == 0) {
      break;
    }
  }
  
  if (label_p < serial_p->se_labels + serial_p->se_label_c
      && label_p->sl_index < serial_p->se_line_c) {
    *line_p = serial_p->se_lines + label_p->sl_index;
    return SERIAL_ERROR_NONE;
  }
  else {
    *line_p = NULL;
    return SERIAL_ERROR_LABEL;
  }
}

/*
 * Shift the SERIAL_P bufs over by MANY.
 */
static	void	shift_buf(serial_t *serial_p, const int many)
{
  int	num, max = SBUF_SIZE(serial_p);
  
  if (many > max) {
    num = max;
  }
  else {
    num = many;
  }
  
  if (num > 0) {
    bcopy(serial_p->se_buf + num, serial_p->se_buf, max - num);
    serial_p->se_end_p -= num;
  }
}

/*
 * Read input from SERIAL_P maybe INTERACTIVE and maybe LOG_INPUT and
 * passes back the read SIZE_P chars (if not null).  If TIMEOUT_P is not
 * null then use this timeout value instead of serial_p's.  Returns
 * serial error codes.
 */
static	int	read_input(serial_t *serial_p, int *size_p,
			   struct timeval *timeout_p)
{
  struct timeval	*tv_p = NULL;
  int			ret, char_n;
  
  if (timeout_p != NULL) {
    tv_p = timeout_p;
  }
  else {
    tv_p = &serial_p->se_timeout;
  }
  
  /* do we have a hang situation */
  if (tv_p->tv_sec < 0) {
    tv_p = NULL;
  }
  
  /* if we're over the limit then shift the buffer down */
  if (SBUF_SIZE(serial_p) > BUFFER_OVERFLOW) {
    shift_buf(serial_p, BUFFER_WRAP);
  }
  
  if (BIT_IS_SET(serial_p->se_flags, INTERACTIVE)) {
    ret = _rawio_prompt(serial_p->se_in_fd, serial_p->se_out_fd,
			serial_p->se_end_p,
			BUFFER_SIZE - SBUF_SIZE(serial_p),
			&char_n, tv_p, tv_p, ACCEPT_CHARS,
			(BIT_IS_SET(serial_p->se_flags, PASSWORD) ? 0 : 1));
  }
  else {
    int		max;
    
    /* determine the max-chars to read */
    max = BUFFER_SIZE - SBUF_SIZE(serial_p);
    if (max > serial_p->se_max_chars && serial_p->se_max_chars > 0) {
      max = serial_p->se_max_chars;
    }
    ret = _rawio_read(serial_p->se_in_fd, tv_p, serial_p->se_end_p, max,
		      &char_n);
  }
  
  if (ret != SERIAL_ERROR_NONE) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "  read returned error: errno %d\n", errno);
    return ret;
  }
  
  if (char_n == 0) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  read timed-out or EOF\n");
    *size_p = 0;
    return SERIAL_ERROR_NONE;
  }
  
  if (BIT_IS_SET(serial_p->se_flags, INPUT_ENABLED) && char_n > 0) {
    serial_log_fwrite(serial_p, SERIAL_LOG_INPUT, serial_p->se_end_p,
		      sizeof(char), char_n);
  }
  
  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  read: '%s'\n",
		    _expand_buf(serial_p->se_end_p, char_n));
  
  serial_p->se_end_p += char_n;
  
  if (size_p != NULL) {
    *size_p = char_n;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Write the PASS string from the PAT via MATCHES and BUF.  Returns
 * [NO]ERROR.
 */
static	int	match_to_pass(const char *pat, char *pass, const int max,
			      const regmatch_t *matches,
			      const int max_matches, const char *buf)
{
  const char	*pat_p, *sub_p;
  char		*pass_p;
  int		arg;
  
  /* no need to do anything if we can't */
  if (pat == NULL) {
    pass[0] = '\0';
    return SERIAL_ERROR_NONE;
  }
  
  for (pat_p = pat, pass_p = pass; *pat_p != '\0' && pass_p < pass + max - 1;) {
    switch (*pat_p) {
      
      /* special character */
    case '\\':
      pat_p++;
      if (isdigit(*pat_p)) {
	arg = 0;
	
	/* get the \? number */
	while (isdigit(*pat_p)) {
	  arg = arg * 10 + (*pat_p - '0');
	  pat_p++;
	}
	
	/* can we substitute a match in here? */
	if (matches != NULL && arg < max_matches && matches[arg].rm_so != -1) {
	  for (sub_p = buf + matches[arg].rm_so;
	       sub_p < buf + matches[arg].rm_eo && pass_p < pass + max - 1;) {
	    *pass_p++ = *sub_p++;
	  }
	}
	break;
      }
      
    default:
      *pass_p++ = *pat_p++;
      break;
    }
  }
  
  *pass_p = '\0';
  
  return SERIAL_ERROR_NONE;
}

/*
 * Expect PAT to be in the input buffer from SERIAL_P.  MATCH_PAT and
 * PASS pass back values to the user.  It sets OKAY_P to true if it
 * was found.  SUB_STRING if it is a substring search and maybe
 * READ_MORE.  Returns [NO]ERROR.
 */
static	int	expect(serial_t *serial_p, const char *pat,
		       const char *match_pat, char *pass, int *okay_bp,
		       const char read_more, const int sub_string_b)
{
  regmatch_t		*matches = NULL;
  char			*match_p;
  int			ret, match_b;
  struct timeval	work, then;
  
  if (SBUF_SIZE(serial_p) > 0) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  initial buffer: '%s'\n",
		 _expand_buf(serial_p->se_buf, SBUF_SIZE(serial_p)));
  }
  
  /* punch the null */
  serial_p->se_buf[SBUF_SIZE(serial_p)] = '\0';
  
  if (serial_p->se_timeout.tv_sec < 0) {
    work = serial_p->se_timeout;
  }
  else {
    (void)gettimeofday(&work, NULL);
    then.tv_sec  = work.tv_sec  + serial_p->se_timeout.tv_sec;
    then.tv_usec = work.tv_usec + serial_p->se_timeout.tv_usec;
    
    while (then.tv_usec >= 1000000) {
      then.tv_sec++;
      then.tv_usec -= 1000000;
    }
  }
  
  for (;;) {
    int		read_n, start, end;
    
    /* do the search */
    if (sub_string_b) {
      do_strstr(pat, serial_p->se_buf, SBUF_SIZE(serial_p), &match_b,
		&start, &end);
      if (match_b) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  matched [%d,%d]\n",
		     start, end);
	if (BIT_IS_SET(serial_p->se_flags, FLUSH_MATCH)) {
	  shift_buf(serial_p, end + 1);
	}

	/* overwrite the match? */
	if (BIT_IS_SET(serial_p->se_flags, OVERWRITE_MATCH)) {
	  for (match_p = serial_p->se_buf + start;
	       match_p <= serial_p->se_buf + end; match_p++) {
	    *match_p = OVERWRITE_CHAR;
	  }
	}
      }
      else if (BIT_IS_SET(serial_p->se_flags, FLUSH_SEARCH)) {
	shift_buf(serial_p, end + 1);
      }
    }
    else {
      ret = do_regex(pat, serial_p->se_buf, SBUF_SIZE(serial_p), &match_b,
		     &matches);
      if (ret != SERIAL_ERROR_NONE) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "  regex failed for pattern string '%s'\n", pat);
	return ret;
      }
    }
    
    /* if we can't read again then done */
    if (! read_more || match_b) {
      break;
    }
    
    if (serial_p->se_timeout.tv_sec >= 0) {
      (void)gettimeofday(&work, NULL);
      
      work.tv_sec  = then.tv_sec  - work.tv_sec;
      work.tv_usec = then.tv_usec - work.tv_usec;
      while (work.tv_usec < 0) {
	work.tv_sec--;
	work.tv_usec += 1000000;
      }
    }
    
    /* read more data */
    ret = read_input(serial_p, &read_n, &work);
    if (ret != SERIAL_ERROR_NONE) {
      return ret;
    }
    
    /* did we timeout? */
    if (read_n == 0) {
      *okay_bp = 0;
      return SERIAL_ERROR_NONE;
    }
  }
  
  *okay_bp = match_b;
  
  if (! match_b || sub_string_b) {
    return SERIAL_ERROR_NONE;
  }
  
  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  matched [%d,%d]\n",
	       matches[0].rm_so, matches[0].rm_eo - 1);
  
  /* covert the pass string from the match */
  ret = match_to_pass(match_pat, pass, PASS_SIZE, matches, MATCH_MAX,
		      serial_p->se_buf);
  if (ret != SERIAL_ERROR_NONE) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		 "  match: problem making pass from match str '%s'.\n",
		 match_pat);
    return ret;
  }
  
  if (pass[0] != '\0') {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "  match pass = '%s'\n", pass);
  }
  
  /* overwrite the match? */
  if (BIT_IS_SET(serial_p->se_flags, OVERWRITE_MATCH)) {
    for (match_p = serial_p->se_buf + matches[0].rm_so;
	 match_p < serial_p->se_buf + matches[0].rm_eo; match_p++) {
      *match_p = OVERWRITE_CHAR;
    }
  }
  
  /* shift the buffer to after the match point if necessary */
  if (BIT_IS_SET(serial_p->se_flags, FLUSH_MATCH)) {
    shift_buf(serial_p, matches[0].rm_eo);
  }
  
  return SERIAL_ERROR_NONE;
}

/************************** token handling routines **************************/

/*
 * Handle a send token.
 */
static	int	tok_send(serial_t *serial_p, const line_t *line_p,
			 int *okay_bp)
{
  int	len;
  
  len = strlen(line_p->li_value.va_char_p);
  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Writing: '%s'\n",
		    _expand_buf(line_p->li_value.va_char_p, len));
  
  if (BIT_IS_SET(serial_p->se_flags, OUTPUT_ENABLED)) {
    serial_log_printf(serial_p, SERIAL_LOG_OUTPUT, "%s",
		      line_p->li_value.va_char_p);
  }
  
  /* try the write */
  if (_rawio_write(serial_p->se_out_fd, line_p->li_value.va_char_p, len,
		   TIMEOUT_P(serial_p)) != SERIAL_ERROR_NONE) {
    serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		      "  write of '%s' (len %d) failed: errno %d\n",
		      _expand_buf(line_p->li_value.va_char_p, len), len,
		      errno);
    *okay_bp = 0;
  }
  else {
    *okay_bp = 1;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Start at the current position in FILE_P in SERIAL_P and pass-bad
 * CODE_P and STR_P.  Return [NO]ERROR.
 */
static	int	execute(line_t *line_p, serial_t *serial_p, int *code_p,
			char **str_p)
{
  static char	pass[PASS_SIZE + 1];
  int		code, ret = SERIAL_ERROR_NONE;
  int		var = 0, var_grid[NUM_VARIABLES];
  char		*match_pat = NULL;
  int		okay_b = 1;
  
  /* initialize return information */
  pass[0] = '\0';
  code = -1;
  
  while (line_p != NULL && line_p < serial_p->se_lines + serial_p->se_line_c) {
    int		token = line_p->li_token_p->to_id;
    int		changed_b = 0;
    
    switch (token) {
      
      /* send characters to port */
    case TOK_SEND:
      ret = tok_send(serial_p, line_p, &okay_b);
      if (ret != SERIAL_ERROR_NONE) {
	line_p = NULL;
      }
      break;
      
      /* read in characters from port */
    case TOK_RECEIVE:
      {
	int	read_n;
	
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Receiving:\n");
	ret = read_input(serial_p, &read_n, NULL);
	if (ret != SERIAL_ERROR_NONE) {
	  line_p = NULL;
	}
	else if (read_n == 0) {
	  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  timed out.\n");
	  okay_b = 0;
	}
	else {
	  okay_b = 1;
	}
      }
      break;
      
      /* wait for input */
    case TOK_WAIT:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Waiting for input...\n");
      ret = _rawio_watch(serial_p->se_in_fd, TIMEOUT_P(serial_p));
      if (ret == SERIAL_ERROR_NONE) {
	okay_b = 1;
      }
      else if (ret == SERIAL_ERROR_TIMEOUT) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  timed out.\n");
	okay_b = 0;
	/* this is not an ``error'' */
	ret = SERIAL_ERROR_NONE;
      }
      break;
      
      /* read input until we see regex */
    case TOK_EXPECT_REG:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Expecting regex: '%s'\n",
			_expand_string(line_p->li_value.va_char_p));
      ret = expect(serial_p, line_p->li_value.va_char_p, match_pat, pass,
		   &okay_b, 1, 0);
      if (ret != SERIAL_ERROR_NONE) {
	line_p = NULL;
      }
      break;
      
      /* read input until we see sub-string */
    case TOK_EXPECT_SUB:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Expecting substring: '%s'\n",
			_expand_string(line_p->li_value.va_char_p));
      ret = expect(serial_p, line_p->li_value.va_char_p, match_pat, pass,
		   &okay_b, 1, 1);
      if (ret != SERIAL_ERROR_NONE) {
	line_p = NULL;
      }
      break;
      
      /* check search buffers for regex */
    case TOK_CHECK_REG:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Checking for regex: '%s'\n",
			_expand_string(line_p->li_value.va_char_p));
      ret = expect(serial_p, line_p->li_value.va_char_p, match_pat, pass,
		   &okay_b, 0, 0);
      if (ret != SERIAL_ERROR_NONE) {
	line_p = NULL;
      }
      break;
      
      /* check search buffers for sub-string */
    case TOK_CHECK_SUB:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Checking for substring: '%s'\n",
			_expand_string(line_p->li_value.va_char_p));
      ret = expect(serial_p, line_p->li_value.va_char_p, match_pat, pass,
		   &okay_b, 0, 1);
      if (ret != SERIAL_ERROR_NONE) {
	line_p = NULL;
      }
      break;
      
      /* flush the search buffers now */
    case TOK_FLUSH_DO:
      serial_p->se_end_p = serial_p->se_buf;
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Search buffers flushed\n");
      break;
      
      /* flush the search buffers when we matched something */
    case TOK_FLUSH_MATCH:
      BIT_SET(serial_p->se_flags, FLUSH_MATCH);
      BIT_CLEAR(serial_p->se_flags, FLUSH_SEARCH);
      BIT_CLEAR(serial_p->se_flags, OVERWRITE_MATCH);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Auto-flush - when matched\n");
      break;
      
      /* flush the search buffers when we searched the buffers */
    case TOK_FLUSH_SEARCH:
      BIT_SET(serial_p->se_flags, FLUSH_MATCH);
      BIT_SET(serial_p->se_flags, FLUSH_SEARCH);
      BIT_CLEAR(serial_p->se_flags, OVERWRITE_MATCH);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Auto-flush - when searched (and matched)\n");
      break;
      
      /* never flush -- better do it sooner or later */
    case TOK_FLUSH_NONE:
      BIT_CLEAR(serial_p->se_flags, FLUSH_MATCH);
      BIT_CLEAR(serial_p->se_flags, FLUSH_SEARCH);
      BIT_CLEAR(serial_p->se_flags, OVERWRITE_MATCH);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Auto-flush - never\n");
      break;
      
      /* overwrite the match in the search buffers */
    case TOK_OVERWRITE_MATCH:
      BIT_CLEAR(serial_p->se_flags, FLUSH_MATCH);
      BIT_CLEAR(serial_p->se_flags, FLUSH_SEARCH);
      BIT_SET(serial_p->se_flags, OVERWRITE_MATCH);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Overwrite match mode\n");
      break;
      
      /* set some stty flags -- if STTYE then reset all flags beforehand */
    case TOK_STTY:
    case TOK_STTYE:
      {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Stty%s: '%s'\n",
			  (token == TOK_STTYE ? "e" : ""),
			  line_p->li_value.va_char_p);
	if (_stty_do(serial_p->se_in_fd, line_p->li_value.va_char_p,
		     (token == TOK_STTYE ? 1 : 0),
		     &serial_p->se_term) == SERIAL_ERROR_NONE
	    && _stty_do(serial_p->se_out_fd, line_p->li_value.va_char_p,
			(token == TOK_STTYE ? 1 : 0),
			&serial_p->se_term) == SERIAL_ERROR_NONE) {
	  okay_b = 1;
	}
	else {
	  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "  stty failed.\n");
	  okay_b = 0;
	}
      }
      break;
      
      /* clear the ports I/O buffers */
    case TOK_CLEAR_IO:
      if (_stty_flush(serial_p->se_in_fd) == SERIAL_ERROR_NONE
	  && _stty_flush(serial_p->se_out_fd) == SERIAL_ERROR_NONE) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      if (okay_b) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Clearing i/o succeeded\n");
      }
      else {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Clearing i/o failed: errno %d\n", errno);
      }
      break;
      
      /* lock the port */
    case TOK_LOCK:
      if (_script_lock(serial_p) == SERIAL_ERROR_NONE) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Locking port %s\n",
			(okay_b ? "succeeded" : "failed"));
      break;
      
      /* unlock the port */
    case TOK_UNLOCK:
      if (_script_unlock(serial_p) == SERIAL_ERROR_NONE) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Un-locking port %s\n",
			(okay_b ? "succeeded" : "failed"));
      break;
      
      /* go into interactive/prompt mode */
    case TOK_INTERACTIVE:
      BIT_SET(serial_p->se_flags, INTERACTIVE);
      BIT_CLEAR(serial_p->se_flags, PASSWORD);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Interactive input\n");
      break;
      
      /* go into interactive/prompt mode -- don't echo input */
    case TOK_PASSWORD:
      BIT_SET(serial_p->se_flags, INTERACTIVE);
      BIT_SET(serial_p->se_flags, PASSWORD);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Password input\n");
      break;
      
      /* normal non-interactive mode */
    case TOK_STRAIGHT:
      BIT_CLEAR(serial_p->se_flags, INTERACTIVE);
      BIT_CLEAR(serial_p->se_flags, PASSWORD);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Straight input\n");
      break;
      
      /* test and jump or just jump to a lable */
    case TOK_IS_OKAY:
    case TOK_IS_NOT_OKAY:
    case TOK_GOTO:
      if (token == TOK_GOTO
	  || (token == TOK_IS_OKAY && okay_b)
	  || (token == TOK_IS_NOT_OKAY && ! okay_b)) {
	char	*label;
	
	changed_b = 1;
	
	label = line_p->li_value.va_char_p;
	ret = goto_label(serial_p, label, &line_p);
	if (ret == SERIAL_ERROR_NONE) {
	  serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Jump: '%s'\n", label);
	}
	else {
	  serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			    "Could not jump to label '%s'\n", label);
	  line_p = NULL;
	}
      }
      break;
      
      /*
       * utilities
       */
      
    case TOK_RETURN:
      {
	/*
	 * do not return ERROR here.  the script caller will determine
	 * which code is an error.
	 */
	code = line_p->li_value.va_int;
	ret = SERIAL_ERROR_NONE;
	line_p = NULL;
	
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Returning code %d\n", code);
      }
      break;
      
    case TOK_DELAY:
      {
	struct timeval	delay;
	
	delay.tv_sec = line_p->li_value.va_int / 1000;
	delay.tv_usec = (line_p->li_value.va_int % 1000) * 1000;
	
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Delaying: %ld sec, %ld usec\n",
			  delay.tv_sec, delay.tv_usec);
	
	if (line_p->li_value.va_int > 0) {
	  (void)select(0, NULL, NULL, NULL, &delay);
	}
      }
      break;
      
    case TOK_TIMEOUT:
      if (line_p->li_value.va_int < 0) {
	serial_p->se_timeout.tv_sec = -1;
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Timeout disabled\n");
      }
      else {
	serial_p->se_timeout.tv_sec = line_p->li_value.va_int / 1000;
	serial_p->se_timeout.tv_usec = (line_p->li_value.va_int % 1000) * 1000;
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Timeout: %ld sec, %ld usec\n",
			  serial_p->se_timeout.tv_sec,
			  serial_p->se_timeout.tv_usec);
      }
      break;
      
    case TOK_MAX_CHARS:
      serial_p->se_max_chars = line_p->li_value.va_int;
      
      if (serial_p->se_max_chars <= 0) {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Max-chars: max\n");
      }
      else {
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			  "Max-chars: %d\n", serial_p->se_max_chars);
      }
      break;
      
    case TOK_PASS:
      (void)strncpy(pass, line_p->li_value.va_char_p, PASS_SIZE);
      pass[PASS_SIZE] = '\0';
      break;
      
    case TOK_MATCH:
      if (match_pat != NULL) {
	free(match_pat);
      }
      match_pat = strdup(line_p->li_value.va_char_p);
      break;
      
      /* ignore labels */
    case TOK_LABEL:
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Label: '%s'\n",
			line_p->li_value.va_char_p);
      break;
      
      /*
       * log commands
       */
      
    case TOK_MESSAGE:
      /* send string to logs */
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"%s", line_p->li_value.va_char_p);
      break;
      
    case TOK_TIME_STAMP:
      {
	time_t	now = time(NULL);
	/* send time-stamp to logs */
	serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Time-stamp: %.24s\n",
			  ctime(&now));
      }
      break;
      
    case TOK_OPEN_INPUT:
      BIT_SET(serial_p->se_flags, INPUT_ENABLED);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Input log enabled\n");
      break;
      
    case TOK_CLOSE_INPUT:
      BIT_CLEAR(serial_p->se_flags, INPUT_ENABLED);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Input log disabled\n");
      break;
      
    case TOK_OPEN_OUTPUT:
      BIT_SET(serial_p->se_flags, OUTPUT_ENABLED);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Output log enabled\n");
      break;
      
    case TOK_CLOSE_OUTPUT:
      BIT_CLEAR(serial_p->se_flags, OUTPUT_ENABLED);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Output log disabled\n");
      break;
      
    case TOK_OPEN_DEBUG:
      BIT_SET(serial_p->se_flags, DEBUG_ENABLED);
      /* NOTE: this should be after enabling */
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Debug log enabled\n");
      break;
      
    case TOK_CLOSE_DEBUG:
      /* NOTE: this should be before disabling */
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG, "Debug log disabled\n");
      BIT_CLEAR(serial_p->se_flags, DEBUG_ENABLED);
      break;
      
    case TOK_USE:
      if (line_p->li_value.va_int >= 0
	  || line_p->li_value.va_int < NUM_VARIABLES) {
	var = line_p->li_value.va_int;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Using variable #%d\n", var);
      break;
      
    case TOK_SET:
      var_grid[var] = line_p->li_value.va_int;
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Variable #%d = %d\n", var, var_grid[var]);
      break;
      
    case TOK_STR_SET:
      var_grid[var] = atoi(line_p->li_value.va_char_p);
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Variable #%d = %d\n", var, var_grid[var]);
      break;
      
    case TOK_ADD:
      var_grid[var] += line_p->li_value.va_int;
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Variable #%d + %d = %d\n", var,
			line_p->li_value.va_int, var_grid[var]);
      break;
      
    case TOK_TEST_EQ:
      if (var_grid[var] == line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d == %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    case TOK_TEST_NE:
      if (var_grid[var] != line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d != %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    case TOK_TEST_LT:
      if (var_grid[var] < line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d < %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    case TOK_TEST_LE:
      if (var_grid[var] <= line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d <= %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    case TOK_TEST_GT:
      if (var_grid[var] > line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d > %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    case TOK_TEST_GE:
      if (var_grid[var] >= line_p->li_value.va_int) {
	okay_b = 1;
      }
      else {
	okay_b = 0;
      }
      
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Is variable #%d %d >= %d?  %s.\n",
			var, var_grid[var], line_p->li_value.va_int,
			(okay_b ? "Yes" : "No"));
      break;
      
    default:
      ret = SERIAL_ERROR_SCRIPT;
      line_p = NULL;
      serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
			"Grammer error.  Unknown token '%s'\n",
			line_p->li_value.va_char_p);
      break;
    }
    
    if (line_p != NULL && (! changed_b)) {
      line_p++;
    }
  }
  
  serial_log_printf(serial_p, SERIAL_LOG_DEBUG,
		    "Final code = %d, pass = '%s'\n", code, pass);
  
  if (code_p != NULL) {
    *code_p = code;
  }
  if (str_p != NULL) {
    *str_p = pass;
  }
  
  if (match_pat != NULL) {
    free(match_pat);
  }
  
  return ret;
}

/*
 * Write STR out to OUTFILE.  Converts % to %% and \ to \\ along the
 * way.
 */
static	void	write_string(FILE *outfile, const char *str)
{
  const char	*str_p;
  
  for (str_p = str; *str_p != '\0'; str_p++) {
    if (*str_p == '%')
      (void)fputc('%', outfile);
    if (*str_p == '\\')
      (void)fputc('\\', outfile);
    (void)fputc(*str_p, outfile);
  }
}

/***************************** exported routined *****************************/

/*
 * Free the lines and any line allocations from SERIAL_P.
 */
void   _script_free_lines(serial_t *serial_p)
{
  line_t	*line_p;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  for (line_p = serial_p->se_lines;
       line_p < serial_p->se_lines + serial_p->se_line_c; line_p++)
    if (line_p->li_token_p->to_argument == TOK_STRING
	|| line_p->li_token_p->to_argument == TOK_LABEL)
      free(line_p->li_value.va_char_p);
  
  free(serial_p->se_lines);
  serial_p->se_lines = NULL;
  serial_p->se_line_c = 0;
}

/*
 * Free the lines and any line allocations from SERIAL_P.
 */
void   _script_free_labels(serial_t *serial_p)
{
  script_label_t	*label_p;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  for (label_p = serial_p->se_labels;
       label_p < serial_p->se_labels + serial_p->se_label_c; label_p++) {
    free(label_p->sl_string);
  }
  
  free(serial_p->se_labels);
  serial_p->se_labels = NULL;
  serial_p->se_label_c = 0;
}

/*
 * Load a script in FILE_P, into SERIAL_P buffers while applying ARGS.
 * Returns serial error codes.
 */
int	_script_load(serial_t *serial_p, FILE *file_p,
		     const serial_arg_t *args)
{
  static int	loaded_b = 0;
  int		line_free_c, label_free_c;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  yyin = file_p;
  if (loaded_b) {
    yylineno = 1;
    yyrestart(file_p);
  }
  loaded_b = 1;
  
  if (serial_p->se_lines != NULL)
    _script_free_lines(serial_p);
  
  serial_p->se_line_c = 0;
  serial_p->se_lines = (line_t *)malloc(sizeof(line_t) * LINE_INCR);
  if (serial_p->se_lines == NULL)
    return SERIAL_ERROR_ALLOC;
  
  line_free_c = LINE_INCR;
  
  serial_p->se_label_c = 0;
  serial_p->se_labels = (script_label_t *)malloc(sizeof(script_label_t) *
						 LABEL_INCR);
  if (serial_p->se_labels == NULL)
    return SERIAL_ERROR_ALLOC;

  label_free_c = LABEL_INCR;
  
  /* process magic value */
  {
    long	magic;
    if (fread(&magic, sizeof(magic), 1, file_p) != 1)
      return SERIAL_ERROR_SCRREAD;
    if (magic == MAGIC_BINARY)
      BIT_SET(serial_p->se_flags, BINARY_INPUT);
    else if (magic == MAGIC_LOCKED) {
      BIT_SET(serial_p->se_flags, BINARY_INPUT);
      BIT_SET(serial_p->se_flags, SCRIPT_LOCKED);
    }
    else {
      (void)fseek(file_p, 0, SEEK_SET);
    }
  }
  
  for (;;) {
    line_t	line;
    int		ret, binary_line;
    
    if (BIT_IS_SET(serial_p->se_flags, BINARY_INPUT))
      ret = binary_get_token(serial_p, args, &line, &binary_line);
    else {
      ret = script_get_token(serial_p, args, &line);
    }
    
    if (ret != SERIAL_ERROR_NONE) {
      _script_free_lines(serial_p);
      return ret;
    }
    
    /* eof? */
    if (line.li_token_p == NULL)
      break;
    
    if (line.li_token_p->to_id == TOK_LABEL) {
      if (label_free_c == 0) {
	serial_p->se_labels =
	  (script_label_t *)realloc(serial_p->se_labels,
				    sizeof(script_label_t)
				    * (serial_p->se_label_c + LABEL_INCR));
	if (serial_p->se_labels == NULL)
	  return SERIAL_ERROR_ALLOC;
	label_free_c = LABEL_INCR;
      }
      
      serial_p->se_labels[serial_p->se_label_c].sl_string =
	line.li_value.va_char_p;  
      if (BIT_IS_SET(serial_p->se_flags, BINARY_INPUT))
	serial_p->se_labels[serial_p->se_label_c].sl_index = binary_line;
      else {
	serial_p->se_labels[serial_p->se_label_c].sl_index =
	  serial_p->se_line_c;
      }
      serial_p->se_label_c++;
      label_free_c--;
      continue;
    }
    
    if (line_free_c == 0) {
      serial_p->se_lines =
	(line_t *)realloc(serial_p->se_lines,
			  sizeof(line_t) * (serial_p->se_line_c + LINE_INCR));
      if (serial_p->se_lines == NULL)
	return SERIAL_ERROR_ALLOC;
      line_free_c = LINE_INCR;
    }
    
    serial_p->se_lines[serial_p->se_line_c] = line;
    serial_p->se_line_c++;
    line_free_c--;
  }
  
  if (serial_p->se_line_c == 0) {
    free(serial_p->se_lines);
    serial_p->se_lines = NULL;
  }
  else {
    serial_p->se_lines =
      (line_t *)realloc(serial_p->se_lines,
			sizeof(line_t) * serial_p->se_line_c);
    if (serial_p->se_lines == NULL)
      return SERIAL_ERROR_ALLOC;
  }
  
  if (serial_p->se_label_c == 0) {
    free(serial_p->se_labels);
    serial_p->se_labels = NULL;
  }
  else {
    serial_p->se_labels =
      (script_label_t *)realloc(serial_p->se_labels,
				sizeof(script_label_t) * serial_p->se_label_c);
    if (serial_p->se_labels == NULL)
      return SERIAL_ERROR_ALLOC;
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Write a script in SERIAL_P to OUTFILE in possible BINARY format.
 * Returns serial error codes.
 */
int	_script_write(serial_t *serial_p, FILE *outfile, const int type)
{
  script_label_t	*label_p;
  line_t		*line_p;
  long			magic;
  int			binary_b = 0;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  if (type == SERIAL_WRITE_BINARY) {
    magic = MAGIC_BINARY;
    (void)fwrite(&magic, sizeof(magic), 1, outfile);
    binary_b = 1;
  }
  else if (type == SERIAL_WRITE_LOCKED) {
    magic = MAGIC_LOCKED;
    (void)fwrite(&magic, sizeof(magic), 1, outfile);
    binary_b = 1;
  }
  
  /* write all the lines out */
  for (line_p = serial_p->se_lines;
       line_p < serial_p->se_lines + serial_p->se_line_c; line_p++) {
    
    if (binary_b) {
      (void)fwrite(&line_p->li_token_p->to_id,
		   sizeof(line_p->li_token_p->to_id), 1, outfile);
    }
    else {
      /* do we need a label here? */
      /* NOTE: this is pretty slow!! */
      for (label_p = serial_p->se_labels;
	   label_p < serial_p->se_labels + serial_p->se_label_c; label_p++) {
	if (label_p->sl_index == line_p - serial_p->se_lines) {
	  (void)fprintf(outfile, "%s:\n", label_p->sl_string);
	  break;
	}
      }
    
      (void)fputc('\t', outfile);
      
      /* write the token */
      (void)fprintf(outfile, "%s", line_p->li_token_p->to_string);
    }
    
    if (line_p->li_token_p->to_argument == TOK_INT) {
      if (binary_b) {
	(void)fwrite(&line_p->li_value.va_int, sizeof(line_p->li_value.va_int),
		     1, outfile);
      }
      else {
	(void)fprintf(outfile, " %d", line_p->li_value.va_int);
      }
    }
    else if (line_p->li_token_p->to_argument == TOK_STRING) {
      if (binary_b) {
	write_string(outfile, line_p->li_value.va_char_p);
	(void)fputc('\0', outfile);
      }      
      else {
	(void)fputc(' ', outfile);
	(void)fputc('\'', outfile);
	write_string(outfile, line_p->li_value.va_char_p);
	(void)fputc('\'', outfile);
      }
    }
    else if (line_p->li_token_p->to_argument == TOK_LABEL
	     || line_p->li_token_p->to_argument == TOK_STRING) {
      if (binary_b) {
	write_string(outfile, line_p->li_value.va_char_p);
	(void)fputc('\0', outfile);
      }
      else {
	(void)fputc(' ', outfile);
	write_string(outfile, line_p->li_value.va_char_p);
	(void)fputc(':', outfile);
      }
    }
    
    if (! binary_b)
      (void)fputc('\n', outfile);
  }

  if (binary_b) {
    /* write out the binary labels */
    for (label_p = serial_p->se_labels;
	 label_p < serial_p->se_labels + serial_p->se_label_c; label_p++) {
      int	tok = TOK_LABEL;
    
      /* write token, line, label + '\0' */
      (void)fwrite(&tok, sizeof(tok), 1, outfile);
      (void)fwrite(&label_p->sl_index, sizeof(label_p->sl_index), 1, outfile);
      (void)fwrite(label_p->sl_string, sizeof(char),
		   strlen(label_p->sl_string), outfile);
      (void)fputc('\0', outfile);
    }
  }
  
  return SERIAL_ERROR_NONE;
}

/*
 * Run script in SERIAL_P starting at LABEL (if null then the top of
 * file).  This passes back an error CODE_P and a pass-back STR_P (if
 * either not NULL).  Returns serial error codes.
 */
int	_script_run(serial_t *serial_p, const char *label,
		    int *code_p, char **str_p)
{
  int		ret;
  line_t	*line_p;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  if (label == NULL) {
    line_p = serial_p->se_lines;
  }
  else {
    ret = goto_label(serial_p, label, &line_p);
    if (ret != SERIAL_ERROR_NONE) {
      if (str_p != NULL)
	*str_p = "Could not run script from label.";
      return ret;
    }
  }
  
  ret = execute(line_p, serial_p, code_p, str_p);
  return ret;
}

/*
 * Lock the port in SERIAL_P. Returns serial error codes.
 */
int	_script_lock(serial_t *serial_p)
{
  int	ret;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  if (serial_p->se_path == NULL) {
    return SERIAL_ERROR_ARG;
  }
  
  ret = uucp_lock(serial_p->se_path);
  if (ret) {
    BIT_SET(serial_p->se_flags, PORT_LOCKED);
    return SERIAL_ERROR_NONE;
  }
  else {
    BIT_CLEAR(serial_p->se_flags, PORT_LOCKED);
    return SERIAL_ERROR_LOCK;
  }
}

/*
 * Unlock the port in SERIAL_P.  Returns serial error codes.
 */
int	_script_unlock(serial_t *serial_p)
{
  int	ret;
  
  if (! script_enabled_b) {
    script_startup();
  }
  
  if (serial_p->se_path == NULL) {
    return SERIAL_ERROR_ARG;
  }
  
  ret = uucp_unlock(serial_p->se_path);
  BIT_CLEAR(serial_p->se_flags, PORT_LOCKED);
  
  if (ret) {
    return SERIAL_ERROR_NONE;
  }
  else {
    return SERIAL_ERROR_LOCK;
  }
}
