/*
 * stty local defines
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the serial-util package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 *
 * $Id: stty_loc.h,v 1.11 2000/03/09 03:49:08 gray Exp $
 */

#ifndef __STTY_LOC_H__
#define __STTY_LOC_H__

#include <termios.h>

/* actions */
#define ACTION_CLEAR		1		/* clear the flag */
#define ACTION_SET		2		/* set the flag */
#define ACTION_BAUD		3		/* baud-rate */
#define ACTION_CHAR		4		/* char for c_cc */
#define ACTION_VALUE		5		/* either min or time value */

/* termio structure elements for clear/set */
#define FLAG_C			1		/* c_cflag */
#define FLAG_I			2		/* c_iflag */
#define FLAG_O			3		/* c_oflag */
#define FLAG_L			4		/* c_lflag */
#define FLAG_NONE		5		/* not needed */

/* map from label to flag */
typedef struct {
  char		*sm_label;			/* label that maps to flag */
  int		sm_value;			/* the flag to set */
  int		sm_action;			/* what to do with value */
  int		sm_flag;			/* which flag to apply to */
} stty_map_t;

/* stty maping values */
static	stty_map_t	stty_maps[] = {
  
  /*
   * control modes:
   */
  
#ifdef CS5
  { "cs5",		CS5,		ACTION_SET,	FLAG_C },
#endif
#ifdef CS6
  { "cs6",		CS6,		ACTION_SET,	FLAG_C },
#endif
#ifdef CS7
  { "cs7",		CS7,		ACTION_SET,	FLAG_C },
#endif
#ifdef CS8
  { "cs8",		CS8,		ACTION_SET,	FLAG_C },
#endif
#ifdef PARENB
  { "parenb",		PARENB,		ACTION_SET,	FLAG_C },
  { "-parenb",		PARENB,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef PARODD
  { "parodd",		PARODD,		ACTION_SET,	FLAG_C },
  { "-parodd",		PARODD,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef HUPCL
  { "hupcl",		HUPCL,		ACTION_SET,	FLAG_C },
  { "-hupcl",		HUPCL,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CSTOPB
  { "cstopb",		CSTOPB,		ACTION_SET,	FLAG_C },
  { "-cstopb",		CSTOPB,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CREAD
  { "cread",		CREAD,		ACTION_SET,	FLAG_C },
  { "-cread",		CREAD,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CLOCAL
  { "clocal",		CLOCAL,		ACTION_SET,	FLAG_C },
  { "-clocal",		CLOCAL,		ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CRTSCTS
  { "crtscts",		CRTSCTS,	ACTION_SET,	FLAG_C },
  { "-crtscts",		CRTSCTS,	ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CCTS_OFLOW
  { "cts_oflow",	CCTS_OFLOW,	ACTION_SET,	FLAG_C },
  { "-cts_oflow",	CCTS_OFLOW,	ACTION_CLEAR,	FLAG_C },
#endif
#ifdef CCTS_IFLOW
  { "cts_iflow",	CRTS_IFLOW,	ACTION_SET,	FLAG_C },
  { "-cts_iflow",	CRTS_IFLOW,	ACTION_CLEAR,	FLAG_C },
#endif
#ifdef MDMBUF
  { "mdmbuf",		MDMBUF,		ACTION_SET,	FLAG_C },
  { "-mdmbuf",		MDMBUF,		ACTION_CLEAR,	FLAG_C },
#endif
  
  /* baud rates */
  
#ifdef B50
  { "50",		B50,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B75
  { "75",		B75,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B110
  { "110",		B110,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B134
  { "134",		B134,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B150
  { "150",		B150,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B200
  { "200",		B200,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B300
  { "300",		B300,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B600
  { "600",		B600,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B1200
  { "1200",		B1200,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B1800
  { "1800",		B1800,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B2400
  { "2400",		B2400,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B4800
  { "4800",		B4800,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B7200
  { "7200",		B7200,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B9600
  { "9600",		B9600,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B14400
  { "14400",		B14400,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B19200
  { "19200",		B19200,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B28800
  { "28800",		B28800,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B38400
  { "38400",		B38400,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B57600
  { "57600",		B57600,		ACTION_BAUD,	FLAG_NONE },
#endif
#ifdef B76800
  { "76800",		B76800,		ACTION_BAUD,	FLAG_NONE },
#endif
  
  /*
   * input modes:
   */
  
#ifdef IGNBRK
  { "ignbrk",		IGNBRK,		ACTION_SET,	FLAG_I },
  { "-ignbrk",		IGNBRK,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef BRKINT
  { "brkint",		BRKINT,		ACTION_SET,	FLAG_I },
  { "-brkint",		BRKINT,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IGNPAR
  { "ignpar",		IGNPAR,		ACTION_SET,	FLAG_I },
  { "-ignpar",		IGNPAR,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef PARMRK
  { "parmrk",		PARMRK,		ACTION_SET,	FLAG_I },
  { "-parmrk",		PARMRK,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef INPCK
  { "inpck",		INPCK,		ACTION_SET,	FLAG_I },
  { "-inpck",		INPCK,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef ISTRIP
  { "istrip",		ISTRIP,		ACTION_SET,	FLAG_I },
  { "-istrip",		ISTRIP,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef INLCR
  { "inlcr",		INLCR,		ACTION_SET,	FLAG_I },
  { "-inlcr",		INLCR,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IGNCR
  { "igncr",		IGNCR,		ACTION_SET,	FLAG_I },
  { "-igncr",		IGNCR,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef ICRNL
  { "icrnl",		ICRNL,		ACTION_SET,	FLAG_I },
  { "-icrnl",		ICRNL,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IUCLC
  { "iuclc",		IUCLC,		ACTION_SET,	FLAG_I },
  { "-iuclc",		IUCLC,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IXON
  { "ixon",		IXON,		ACTION_SET,	FLAG_I },
  { "-ixon",		IXON,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IXOFF
  { "ixoff",		IXOFF,		ACTION_SET,	FLAG_I },
  { "-ixoff",		IXOFF,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IXANY
  { "ixany",		IXANY,		ACTION_SET,	FLAG_I },
  { "-ixany",		IXANY,		ACTION_CLEAR,	FLAG_I },
#endif
#ifdef IMAXBEL
  { "imaxbel",		IMAXBEL,	ACTION_SET,	FLAG_I },
  { "-imaxbel",		IMAXBEL,	ACTION_CLEAR,	FLAG_I },
#endif
  
  /*
   * output modes:
   */
  
#ifdef OPOST
  { "opost",		OPOST,		ACTION_SET,	FLAG_O },
  { "-opost",		OPOST,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef ONLCR
  { "onlcr",		ONLCR,		ACTION_SET,	FLAG_O },
  { "-onlcr",		ONLCR,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef OXTABS
  { "oxtabs",		OXTABS,		ACTION_SET,	FLAG_O },
  { "-oxtabs",		OXTABS,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef ONOEOT
  { "onoeot",		ONOEOT,		ACTION_SET,	FLAG_O },
  { "-onoeot",		ONOEOT,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef OLCUC
  { "olcuc",		OLCUC,		ACTION_SET,	FLAG_O },
  { "-olcuc",		OLCUC,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef OCRNL
  { "ocrnl",		OCRNL,		ACTION_SET,	FLAG_O },
  { "-ocrnl",		OCRNL,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef ONOCR
  { "onocr",		ONOCR,		ACTION_SET,	FLAG_O },
  { "-onocr",		ONOCR,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef ONLRET
  { "onlret",		ONLRET,		ACTION_SET,	FLAG_O },
  { "-onlret",		ONLRET,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef OFILL
  { "ofill",		OFILL,		ACTION_SET,	FLAG_O },
  { "-ofill",		OFILL,		ACTION_CLEAR,	FLAG_O },
#endif
#ifdef OFDEL
  { "ofdel",		OFDEL,		ACTION_SET,	FLAG_O },
  { "-ofdel",		OFDEL,		ACTION_CLEAR,	FLAG_O },
#endif
  
  /*
   * local modes:
   */
  
#ifdef ISIG
  { "isig",		ISIG,		ACTION_SET,	FLAG_L },
  { "-isig",		ISIG,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ICANON
  { "icanon",		ICANON,		ACTION_SET,	FLAG_L },
  { "-icanon",		ICANON,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef XCASE
  { "xcase",		XCASE,		ACTION_SET,	FLAG_L },
  { "-xcase",		XCASE,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHO
  { "echo",		ECHO,		ACTION_SET,	FLAG_L },
  { "-echo",		ECHO,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHOE
  { "echoe",		ECHOE,		ACTION_SET,	FLAG_L },
  { "-echoe",		ECHOE,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHOK
  { "echok",		ECHOK,		ACTION_SET,	FLAG_L },
  { "-echok",		ECHOK,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHONL
  { "echonl",		ECHONL,		ACTION_SET,	FLAG_L },
  { "-echonl",		ECHONL,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef NOFLSH
  { "noflsh",		NOFLSH,		ACTION_SET,	FLAG_L },
  { "-noflsh",		NOFLSH,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef TOSTOP
  { "tostop",		TOSTOP,		ACTION_SET,	FLAG_L },
  { "-tostop",		TOSTOP,		ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHOCTL
  { "echoctl",		ECHOCTL,	ACTION_SET,	FLAG_L },
  { "-echoctl",		ECHOCTL,	ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHOPRT
  { "echoprt",		ECHOPRT,	ACTION_SET,	FLAG_L },
  { "-echoprt",		ECHOPRT,	ACTION_CLEAR,	FLAG_L },
#endif
#ifdef ECHOKE
  { "echoke",		ECHOKE,		ACTION_SET,	FLAG_L },
  { "-echoke",		ECHOKE,		ACTION_CLEAR,	FLAG_L },
#endif
  
  /* control chars: */
  
  /*
   * NOTE: eof, eol, and eol2 are the same as VMIN and VTIME and are
   * not included in the list.
   */
#ifdef VEOF
  { "eof",		VEOF,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VEOL
  { "eol",		VEOL,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VERASE
  { "erase",		VERASE,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VDISCARD
  { "discard",		VDISCARD,	ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VINTR
  { "intr",		VINTR,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VKILL
  { "kill",		VKILL,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VLNEXT
  { "lnext",		VLNEXT,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VQUIT
  { "quit",		VQUIT,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VREPRINT
  { "rprnt",		VREPRINT,	ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VSTART
  { "start",		VSTART,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VSTOP
  { "stop",		VSTOP,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VSUSP
  { "susp",		VSUSP,		ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VWERASE
  { "werase",		VWERASE,	ACTION_CHAR,	FLAG_NONE },
#endif
#ifdef VSTATUS
  { "status",		VSTATUS,	ACTION_CHAR,	FLAG_NONE },
#endif
  
  /* special values: */
  
#ifdef VMIN
  { "min",		VMIN,		ACTION_VALUE,	FLAG_NONE },
#endif
#ifdef VTIME
  { "time",		VTIME,		ACTION_VALUE,	FLAG_NONE },
#endif
  
  { NULL }
};

#endif /* ! __STTY_LOC_H__ */
