/*
 * Runtime Configuration...
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the rc package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted via http://256.com/gray/
 *
 * $Id: rc.c,v 1.14 2000/03/09 04:00:41 gray Exp $
 */

/*
 * Process a parameter file for the user program.  With the help of a
 * parameter structure, will set a number of variables with values
 * interpretted from the parameter file.
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef DMALLOC
#include "dmalloc.h"
#endif

#if defined(WIN32)
#define strncasecmp _strnicmp
#endif

#include "rc.h"
#include "rc_loc.h"

static	char	*rcs_id =
  "$Id: rc.c,v 1.14 2000/03/09 04:00:41 gray Exp $";

/*
 * Version id for the library.  You also need to add an entry to the
 * NEWS and ChangeLog files.
 */
static char *version_id = "$RCVersion: 2.1.0 March 9, 2000 $";

/****************************** string routines ******************************/

/*
 * Convert STR to integer translation depending on BASE.
 */
static	long	base_to_long(const char *str, const int base)
{
  long	val = 0;
  
  /* strip off spaces */
  for (; *str == ' ' || *str == '\t'; str++) {
  }
  
  for (; *str >= '0' && *str < '0' + base; str++) {
    val *= base;
    val += *str - '0';
  }
  
  return val;
}

/*
 * Hexadecimal STR to integer translation.
 */
static	long	hex_to_long(const char *str)
{
  long	val = 0;
  
  /* strip off spaces */
  for (; *str == ' ' || *str == '\t'; str++) {
  }
  
  /* skip a leading 0[xX] */
  if (*str == '0' && (*(str + 1) == 'x' || *(str + 1) == 'X')) {
    str += 2;
  }
  
  for (; isdigit(*str)
       || (*str >= 'a' && *str <= 'f') || (*str >= 'A' && *str <= 'F');
       str++) {
    val *= 16;
    if (*str >= 'a' && *str <= 'f') {
      val += *str - 'a' + 10;
    }
    else if (*str >= 'A' && *str <= 'F') {
      val += *str - 'A' + 10;
    }
    else {
      val += *str - '0';
    }
  }
  
  return val;
}

/*
 * Syslog FACILITY to integer translation.  Returns -1 if not found.
 */
static	int	facility_toi(const char *facility)
{
#if defined(unix)
  fac_map_t	*fac_p;
  
  for (fac_p = facilities; fac_p->fm_facility != NULL; fac_p++) {
    if (strcasecmp(facility, fac_p->fm_facility) == 0) {
      return fac_p->fm_value;
    }
  }
#endif  
  return -1;
}

/*
 * Syslog integer FACILITY to string translation.  Returns null if not
 * found.
 */
static	const char	*itofacility(const int value)
{
#if defined(unix)
  fac_map_t	*fac_p;
  
  for (fac_p = facilities; fac_p->fm_facility != NULL; fac_p++) {
    if (fac_p->fm_value == value) {
      return fac_p->fm_facility;
    }
  }
#endif  
  return NULL;
}

/*
 * Reverse of expand_string.  Translates "\\003" into '\003' in string
 * STR and passes back length in LEN_P (if not null).
 */
static	void	decode_string(char *str, int *len_p)
{
  unsigned char	ch;				/* needs to be this */
  const char	*str_p;
  char		*out_p, *slashs;
  int		dig_c;
  
  for (str_p = str, out_p = str; *str_p != '\0';) {
    
    ch = *str_p++;
    
    switch (ch) {
      
    case '\\':
      /* try and find special character in slash list */
      for (slashs = SPECIAL_CHARS; *slashs != '\0'; slashs++) {
	if (*slashs++ == *str_p) {
	  break;
	}
      }
      
      if (*slashs != '\0') {
	/* we found a special char */
	ch = *slashs;
	str_p++;
      } else if (! isdigit(*str_p)) {
	/* \c which c is not in the above list nor a digit returns c */
	ch = *str_p++;
      }
      else {
	/* try and translate an octal number */
	ch = 0;
	
	for (dig_c = 0; dig_c < 3 && isdigit(*str_p); dig_c++) {
	  ch *= 8;
	  ch += *str_p++ - '0';
	}
	
	/* if failure, then copy all of the processed string out */
	if (dig_c < 3) {
	  str_p -= dig_c;
	  ch = *str_p++;
	}
      }
      break;
      
    default:
      break;
    }
    
    *out_p++ = ch;
  }
  
  /* punch the NULL */
  *out_p = '\0';
  
  if (len_p != NULL) {
    *len_p = out_p - str;
  }
}

/*
 * Translates a buffer BUF of BUF_SIZE into OUT of max size OUT_SIZE.
 * If BUF_SIZE < 0 then it will stop when it reaches a \0 character.
 * It handles both printable characters as well as non-printables --
 * printing them out as \%03o.  NOTE: it does _not_ add a \0 at the
 * end of OUT.  The routine returns the length of the buffer.
 */
static	int	expand_buf(const void *buf, const int buf_size,
			   char *out, const int out_size)
{
  int			buf_c;
  const unsigned char	*buf_p, *spec_p;
  char	 		*max_p, *out_p = out;
  
  /* setup our max pointer */
  max_p = out + out_size;
  
  /* run through the input buffer, counting the characters as we go */
  for (buf_c = 0, buf_p = (const unsigned char *)buf;; buf_c++, buf_p++) {
    
    /* did we reach the end of the buffer? */
    if (buf_size < 0) {
      if (*buf_p == '\0') {
	break;
      }
    }
    else {
      if (buf_c >= buf_size) {
	break;
      }
    }
    
    /* search for special characters */
    for (spec_p = (unsigned char *)SPECIAL_CHARS + 1;
	 *(spec_p - 1) != '\0';
	 spec_p += 2) {
      if (*spec_p == *buf_p) {
	break;
      }
    }
    
    /* did we find one? */
    if (*(spec_p - 1) != '\0') {
      if (out_p + 2 >= max_p) {
	break;
      }
      (void)sprintf(out_p, "\\%c", *(spec_p - 1));
      out_p += 2;
      continue;
    }
    
    /* print out any 7-bit printable characters */
    if (*buf_p < 128 && isprint(*buf_p)) {
      if (out_p + 1 >= max_p) {
	break;
      }
      *out_p = *(char *)buf_p;
      out_p += 1;
    }
    else {
      if (out_p + 4 >= max_p) {
	break;
      }
      (void)sprintf(out_p, "\\%03o", *buf_p);
      out_p += 4;
    }
  }
  
  return out_p - out;
}

/******************************* type routines *******************************/

/*
 * Translate DATA of TYPE and passes back its VAR value.  It also
 * passed back in ALLOCED (if its not null) whether VAR was alloced.
 * Returns rc error codes.
 */
static	int	type_translate(const int type, const char *data, void *var,
			       int *alloced_bp)
{
  if (alloced_bp != NULL) {
    *alloced_bp = 0;
  }
  
  switch (RC_TYPE(type)) {
    
  case RC_BOOL:
    if (strncasecmp(data, "on", 2) == 0
	|| strncasecmp(data, "true", 4) == 0
	|| strncasecmp(data, "1", 1) == 0
	|| strncasecmp(data, "yes", 3) == 0) {
      *(char *)var = 1;
    }
    else {
      *(char *)var = 0;
    }
    break;
    
  case RC_CHAR:
  case RC_CHAR_P:
    {
      int	len = strlen(data);
      
      if (*data == '\"' || *data == '\'') {
	data++;
	len--;
	/* closing quote without a '\'? */
	if (len > 0
	    && (data[len - 1] == '\"' || data[len - 1] == '\'')
	    && (len == 1 || data[len - 2] != '\\')) {
	  len--;
	}
      }
      
      if (RC_TYPE(type) == RC_CHAR) {
	*(char *)var = *data;
      }
      else {
	/* simulate a STRDUP with a length */
	*(char **)var = malloc(len + 1);
	if (*(char **)var == NULL) {
	  return RC_ERROR_ALLOC;
	}
	
	memcpy(*(char **)var, data, len);
	*(*(char **)var + len) = '\0';
	
	if (alloced_bp != NULL) {
	  *alloced_bp = 1;
	}
      }
    }
    break;
    
  case RC_SHORT:
    *(short *)var = (short)atoi((char *)data);
    break;
    
  case RC_U_SHORT:
    *(unsigned short *)var = (unsigned short)atoi((char *)data);
    break;
    
  case RC_INT:
    *(int *)var = atoi((char *)data);
    break;
    
  case RC_U_INT:
    *(unsigned int *)var = (unsigned int)atoi((char *)data);
    break;
    
  case RC_LONG:
    *(long *)var = atol((char *)data);
    break;
    
  case RC_U_LONG:
    *(unsigned long *)var = (unsigned long)atol((char *)data);
    break;
    
  case RC_FLOAT:
    (void)sscanf(data, "%f", (float *)var);
    break;
    
  case RC_DOUBLE:
    (void)sscanf(data, "%lf", (double *)var);
    break;
    
  case RC_BIN:
    *(int *)var = (int)base_to_long(data, 2);
    break;
    
  case RC_OCT:
    *(int *)var = (int)base_to_long(data, 8);
    break;
    
  case RC_HEX:
    *(int *)var = (int)hex_to_long(data);
    break;
    
  case RC_SIZE:
    {
      const char	*data_p;
      long		val;
      
      /* take initial integer point */
      val = atol(data);
      for (data_p = data;
	   *data_p == ' ' || *data_p == '-' || *data_p == '+'
	     || (*data_p >= '0' && *data_p <= '9');
	   data_p++) {
      }
      if (*data_p == 'b' || *data_p == 'B') {
	val *= 1;
      }
      else if (*data_p == 'k' || *data_p == 'k') {
	val *= 1024;
      }
      else if (*data_p == 'm' || *data_p == 'M') {
	val *= 1024 * 1024;
      }
      else if (*data_p == 'g' || *data_p == 'G') {
	val *= 1024 * 1024 * 1024;
      }
      *(long *)var = val;
    }
    break;
    
  case RC_U_SIZE:
    {
      const char	*data_p;
      unsigned long	val;
      
      /* take initial integer point */
      val = (unsigned long)atol(data);
      for (data_p = data;
	   *data_p == ' ' || *data_p == '-' || *data_p == '+'
	     || (*data_p >= '0' && *data_p <= '9');
	   data_p++) {
      }
      if (*data_p == 'b' || *data_p == 'B') {
	val *= 1;
      }
      else if (*data_p == 'k' || *data_p == 'K') {
	val *= 1024;
      }
      else if (*data_p == 'm' || *data_p == 'M') {
	val *= 1024 * 1024;
      }
      else if (*data_p == 'g' || *data_p == 'G') {
	val *= 1024 * 1024 * 1024;
      }
      *(unsigned long *)var = val;
    }
    break;
    
  case RC_SYSLOG:
    *(int *)var = facility_toi(data);
    if (*(int *)var < 0) {
      return RC_ERROR_FACILITY;
    }
    break;
    
  case RC_ADDRESS:
    *(void **)var = (void *)hex_to_long(data);
    break;
    
  case RC_BOOL_INT:
    if (strncasecmp(data, "on", 2) == 0
	|| strncasecmp(data, "true", 4) == 0
	|| strncasecmp(data, "1", 1) == 0
	|| strncasecmp(data, "yes", 3) == 0) {
      *(int *)var = 1;
    }
    else {
      *(int *)var = 0;
    }
    break;
    
  default:
    return RC_ERROR_TYPE;
    /* NOTREACHED */
    break;
  }
  
  return RC_ERROR_NONE;
}

/*
 * Free a VAR of TYPE if necessary.  Returns rc error codes.
 */
static	int	type_free(const int type, void *var)
{
  switch (RC_TYPE(type)) {
    
  case RC_BOOL:
  case RC_CHAR:
    /* RC_CHAR_P is special below */
  case RC_SHORT:
  case RC_U_SHORT:
  case RC_INT:
  case RC_U_INT:
  case RC_LONG:
  case RC_U_LONG:
  case RC_FLOAT:
  case RC_DOUBLE:
  case RC_BIN:
  case RC_OCT:
  case RC_HEX:
  case RC_SIZE:
  case RC_U_SIZE:
  case RC_SYSLOG:
  case RC_ADDRESS:
  case RC_BOOL_INT:
    break;
    
  case RC_CHAR_P:
    if (*(char **)var != NULL) {
      free(*(char **)var);
      *(char **)var = NULL;
    }
    break;
    
  default:
    return RC_ERROR_TYPE;
    /* NOTREACHED */
    break;
  }
  
  return RC_ERROR_NONE;
}

/******************************* load routines *******************************/

/*
 * Get the line, strip empties and comments.
 */
static	char	*read_line(FILE *file_p, int *line_cp,
			   char *read_buf, const int read_size)
{
  char	*line_p, *ch_p;
  char	*offset = read_buf, in_string_b;
  
  for (;;) {
    if (fgets(offset, read_size - (offset - read_buf), file_p) == NULL) {
      /* if we have a line continuation here then return the partial line */
      if (offset != read_buf) {
	*offset = '\0';
	break;
      }
      return NULL;
    }
    
    if (line_cp != NULL) {
      (*line_cp)++;
    }
    
    /* remove any lead spaces */
    for (line_p = offset; *line_p == ' ' || *line_p == '\t'; line_p++) {
    }
    
    /* if we got a comment or an empty line, then skip it */
    if (*line_p == '#' || *line_p == '\n' || *line_p == '\r') {
      /* if we have a line continuation here then return the line */
      if (offset != read_buf) {
	*offset = '\0';
	break;
      }
      continue;
    }
    
    /*
     * Find the end or start of inline comment.  Strip it, the ending
     * \n's, and strip non-excaped spaces.
     */
    in_string_b = 0;
    for (ch_p = line_p;
	 *ch_p != '\0' && *ch_p != '\n' && *ch_p != '\r';
	 ch_p++) {
      /* watch strings to make sure we don't have "#" which is not a comment */
      if ((*ch_p == '\'' || *ch_p == '"')
	  && (ch_p == line_p || *(ch_p - 1) != '\\')) {
	if (in_string_b) {
	  in_string_b = 0;
	}
	else {
	  in_string_b = 1;
	}
      }
      else if ((! in_string_b) && *ch_p == '#' &&
	       (ch_p == line_p || *(ch_p - 1) != '\\')) {
	break;
      }
    }
    if (ch_p > line_p) {
      ch_p--;
    }
    
    /*
     * Work back striped end whitespace.  NOTE: the 1st char we have
     * already verified above is not a ' ' or '\t'.
     */
    for (; ch_p > line_p
	   && (*ch_p == ' ' || *ch_p == '\t')
	   && *(ch_p - 1) != '\\';
	 ch_p--) {
    }
    
    /* shift the line back to the start of the buffer */
    if (line_p > offset) {
      memmove(offset, line_p, (ch_p + 1) - line_p);
      ch_p -= line_p - offset;
      line_p = offset;
    }
    
    /* do we have a line continuation? */
    if (*ch_p == '\\' && (ch_p == offset || *(ch_p - 1) != '\\')) {
      offset = ch_p;
      continue;
    }
    
    *(ch_p + 1) = '\0';
    break;
  }
  
  /* translate \ stuff like c-strings */
  decode_string(read_buf, NULL);
  
  return read_buf;
}

/***************************** exported routines *****************************/

/*
 * const char *rc_type_string
 *
 * DESCRIPTION:
 *
 * Function to return the string representation of the type of an RC list
 * entry.
 *
 * RETURNS:
 *
 * Constant string type name or NULL on error.
 *
 * ARGUMENTS:
 *
 * rc_entry_p - pointer to an entry in a RC list.
 *
 * error_p - passes back the RC error number.
 */
const char	*rc_type_string(const rc_t *rc_entry_p, int *error_p)
{
  const char	*str;
  
  switch (RC_TYPE(rc_entry_p->rc_type)) {
    
  case RC_BOOL:
    str = "character boolean";
    break;
    
  case RC_CHAR:
    str = "character";
    break;
    
  case RC_CHAR_P:
    str = "character string";
    break;
    
  case RC_SHORT:
    str = "short integer";
    break;
    
  case RC_U_SHORT:
    str = "unsigned short integer";
    break;
    
  case RC_INT:
    str = "integer";
    break;
    
  case RC_U_INT:
    str = "unsigned integer";
    break;
    
  case RC_LONG:
    str = "long integer";
    break;
    
  case RC_U_LONG:
    str = "unsigned long integer";
    break;
    
  case RC_FLOAT:
    str = "floating point";
    break;
    
  case RC_DOUBLE:
    str = "double floating point";
    break;
    
  case RC_BIN:
    str = "integer binary value";
    break;
    
  case RC_OCT:
    str = "integer octal value";
    break;
    
  case RC_HEX:
    str = "integer hexadecimal value";
    break;
    
  case RC_SIZE:
    str = "long size";
    break;
    
  case RC_U_SIZE:
    str = "unsigned long size";
    break;
    
  case RC_SYSLOG:
    str = "integer syslog facility";
    break;
    
  case RC_ADDRESS:
    str = "long hexadecimal address";
    break;
    
  case RC_BOOL_INT:
    str = "integer boolean";
    break;
    
  default:
    if (error_p != NULL) {
      *error_p = RC_ERROR_TYPE;
    }
    return NULL;
    break;
  }
  
  if (error_p != NULL) {
    *error_p = RC_ERROR_NONE;
  }
  return str;
}

/*
 * int rc_value_string
 *
 * DESCRIPTION:
 *
 * Convert the value of a RC entry to its string equivalent in the buffer
 * provided.
 *
 * RETURNS:
 *
 * Returns RC error codes.
 *
 * ARGUMENTS:
 *
 * rc_entry_p - pointer to an entry in a RC list.
 *
 * buf - buffer to convert the value into.
 *
 * buf_size - size of the buffer.
 *
 * len_p - passes back the length of bytes copied into the buffer.
 */
int	rc_value_string(const rc_t *rc_entry_p, char *buf,
			const int buf_size, int *len_p)
{
  char	*buf_p = buf, *max_p, *str, exp[1024], *exp_p = exp, in_exp_b = 0;
  void	*var;
  int	len;
  
  /* note the variable for code simplification */
  var = rc_entry_p->rc_variable;
  
  if (var == NULL) {
    exp_p = "(null)";
    in_exp_b = 1;
  }
  else {
    switch (RC_TYPE(rc_entry_p->rc_type)) {
      
    case RC_BOOL:
      if (*(char *)var == 0) {
	exp_p = "false";
      }
      else {
	exp_p = "true";
      }
      in_exp_b = 1;
      break;
      
    case RC_CHAR:
      max_p = buf + buf_size;
      if (buf_p + 1 < max_p) {
	*buf_p++ = '\'';
      }
      /* now expand the possibly binary character */
      len = expand_buf((char *)var, 1, exp, sizeof(exp));
      if (buf_p + len < max_p) {
	memcpy(buf_p, exp, len);
	buf_p += len;
      }
      if (buf_p + 1 < max_p) {
	*buf_p++ = '\'';
      }
      if (len_p != NULL) {
	*len_p = buf_p - buf;
      }
      break;
      
    case RC_CHAR_P:
      str = *(char **)var;
      if (str == NULL) {
	exp_p = "(null)";
	in_exp_b = 1;
      }
      else {
	max_p = buf + buf_size;
	if (buf_p + 1 < max_p) {
	  *buf_p++ = '\"';
	}
	/* now expand the possibly binary string */
	len = expand_buf(*(char **)var, -1, exp, sizeof(exp));
	if (buf_p + len < max_p) {
	  memcpy(buf_p, exp, len);
	  buf_p += len;
	}
	if (buf_p + 1 < max_p) {
	  *buf_p++ = '\"';
	}
	if (len_p != NULL) {
	  *len_p = buf_p - buf;
	}
      }
      break;
      
    case RC_SHORT:
      (void)sprintf(exp, "%d", (int)*(short *)var);
      in_exp_b = 1;
      break;
      
    case RC_U_SHORT:
      (void)sprintf(exp, "%d", (int)*(unsigned short *)var);
      in_exp_b = 1;
      break;
      
    case RC_INT:
      (void)sprintf(exp, "%d", *(int *)var);
      in_exp_b = 1;
      break;
      
    case RC_U_INT:
      (void)sprintf(exp, "%d", *(unsigned int *)var);
      in_exp_b = 1;
      break;
      
    case RC_LONG:
      (void)sprintf(exp, "%ld", *(long *)var);
      in_exp_b = 1;
      break;
      
    case RC_U_LONG:
      (void)sprintf(exp, "%ld", *(unsigned long *)var);
      in_exp_b = 1;
      break;
      
    case RC_FLOAT:
      if (*(float *)var == 0.0) {
	exp_p = "0.0";
      }
      else {
	(void)sprintf(exp, "%f", *(float *)var);
      }
      in_exp_b = 1;
      break;
      
    case RC_DOUBLE:
      if (*(double *)var == 0.0) {
	exp_p = "0.0";
      }
      else {
	(void)sprintf(exp, "%f", *(double *)var);
      }
      in_exp_b = 1;
      break;
      
    case RC_BIN:
      {
	int	bitc;
	char	zero_b = 1;
      
	max_p = buf + buf_size;
      
	if (buf_p + 2 < max_p) {
	  *buf_p++ = '0';
	  *buf_p++ = 'b';
	}
      
	for (bitc = BITS(int) - 1; bitc >= 0; bitc--) {
	  if (buf_p + 1 >= max_p) {
	    break;
	  }
	  if ((1 << bitc) & *(int *)var) {
	    *buf_p++ = '1';
	    zero_b = 0;
	  }
	  else if (! zero_b) {
	    *buf_p++ = '0';
	  }
	}
      
	if (zero_b && buf_p + 1 < max_p) {
	  *buf_p++ = '0';
	}
	if (len_p != NULL) {
	  *len_p = buf_p - buf;
	}
      }
    break;
    
    case RC_OCT:
      (void)sprintf(exp, "%#o", *(int *)var);
      in_exp_b = 1;
      break;
      
    case RC_HEX:
      (void)sprintf(exp, "%#x", *(int *)var);
      in_exp_b = 1;
      break;
      
    case RC_SIZE:
      {
	long	morf, val = *(long *)var;
      
	if (val == 0) {
	  exp_p = "0b";
	}
	else if (val > 0 && val % (1024 * 1024 * 1024) == 0) {
	  morf = val / (1024 * 1024 * 1024);
	  (void)sprintf(exp, "%ldg (%ld)", morf, val);
	}
	else if (val > 0 && val % (1024 * 1024) == 0) {
	  morf = val / (1024 * 1024);
	  (void)sprintf(exp, "%ldm (%ld)", morf, val);
	}
	else if (val > 0 && val % 1024 == 0) {
	  morf = val / 1024;
	  (void)sprintf(exp, "%ldk (%ld)", morf, val);
	}
	else {
	  (void)sprintf(exp, "%ldb", val);
	}
	in_exp_b = 1;
      }
    break;
    
    case RC_U_SIZE:
      {
	unsigned long	morf, val = *(unsigned long *)var;
      
	if (val == 0) {
	  exp_p = "0b";
	}
	else if (val % (1024 * 1024 * 1024) == 0) {
	  morf = val / (1024 * 1024 * 1024);
	  (void)sprintf(exp, "%ldg (%ld)", morf, val);
	}
	else if (val % (1024 * 1024) == 0) {
	  morf = val / (1024 * 1024);
	  (void)sprintf(exp, "%ldm (%ld)", morf, val);
	}
	else if (val % 1024 == 0) {
	  morf = val / 1024;
	  (void)sprintf(exp, "%ldk (%ld)", morf, val);
	}
	else {
	  (void)sprintf(exp, "%ldb", val);
	}
	in_exp_b = 1;
      }
    break;
    
    case RC_SYSLOG:
      buf_p = (char *)itofacility(*(int *)var);
      if (buf_p == NULL) {
				(void)sprintf(exp, "invalid facility (%d)", *(int *)var);
				in_exp_b = 1;
      }
      else {
				len = strlen(buf_p);
				if (len > buf_size) {
					len = buf_size;
				}
				memcpy(buf, buf_p, len);
				if (len_p != NULL) {
					*len_p = len;
				}
      }
      break;
      
    case RC_ADDRESS:
      (void)sprintf(exp, "%#lx", (long)*(void **)var);
      in_exp_b = 1;
      break;
      
    case RC_BOOL_INT:
      if (*(int *)var == 0) {
	exp_p = "false";
      }
      else {
	exp_p = "true";
      }
      in_exp_b = 1;
      break;
      
    default:
      return RC_ERROR_TYPE;
      /* NOTREACHED */
      break;
    }
  }
  
  /* if we put the result into our local buf then copy it into the buffer */
  if (in_exp_b) {
    len = strlen(exp_p);
    if (len > buf_size) {
      len = buf_size;
    }
    memcpy(buf, exp_p, len);
    if (len_p != NULL) {
      *len_p = len;
    }
  }
  
  return RC_ERROR_NONE;
}

/*
 * int rc_process
 *
 * DESCRIPTION:
 *
 * Process a RC file and convert the strings into the RC list provided.
 * The RC list should then be passed to rc_cleanup so that allocations
 * can be frees.
 *
 * RETURNS:
 *
 * Returns RC error codes.
 *
 * ARGUMENTS:
 *
 * file - path of the RC file to be read and processed.
 *
 * rc_list - RC array to fill with the values from the file.  The rc_type
 * field of each entry will be altered to flag entries with memory
 * allocation.
 *
 * rc_err - function which will called to report each processing error
 * found in the RC file.
 */
int	rc_process(const char *file, rc_t *rc_list, const rc_err_t rc_err)
{
  char		*line, *line_p = NULL;
  char		buf[1024], read_buf[MAX_LINE_SIZE];
  FILE		*infile;
  int		ret, line_c = 0, mand_c, alloced_b;
  rc_t		*rc_p;
  
  /* open the RC file */
  infile = fopen(file, "r");
  if (infile == NULL) {
    return RC_ERROR_FILE;
  }
  
  /* mark the list as processed */
  if (rc_list->rc_label != RC_LAST) {
    BIT_SET(rc_list->rc_type, RC_PROCESSED);
  }
  
  /* read each line and look for a match */
  for (;;) {
    line = read_line(infile, &line_c, read_buf, sizeof(read_buf));
    if (line == NULL) {
      break;
    }
    
    /* look for the label */
    for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
      int	len;
      
      len = strlen(rc_p->rc_label);
      if (strncmp(rc_p->rc_label, line, len) == 0
	  && (*(line + len) == ' '
	      || *(line + len) == '\t'
	      || *(line + len) == RC_ASSIGN_CHAR)) {
	line_p = line + len;
	break;
      }
    }
    
    /* did we not find it? */
    if (rc_p->rc_label == NULL) {
      if (rc_err != NULL) {
	rc_err(file, line_c, RC_ERROR_UNKNOWN, line);
      }
      continue;
    }
    
    /* ignore duplicates */
    if (BIT_IS_SET(rc_p->rc_type, RC_USED)) {
      if (rc_err != NULL) {
	rc_err(file, line_c, RC_ERROR_DUPLICATE, line);
      }
      continue;
    }
    
    for (; *line_p == ' ' || *line_p == '\t'; line_p++) {
    }
    if (RC_ASSIGN_CHAR == *line_p) {
      for (line_p++ ; *line_p == ' ' || *line_p == '\t'; line_p++) {
      }
    }
    
    /* is it already alloced?  then free the last one */
    if (BIT_IS_SET(rc_p->rc_type, RC_ALLOCED)) {
      (void)type_free(rc_p->rc_type, rc_p->rc_variable);
      BIT_CLEAR(rc_p->rc_type, RC_ALLOCED);
    }
    
    /* now translate the type */
    ret = type_translate(rc_p->rc_type, line_p, rc_p->rc_variable, &alloced_b);
    if (ret != RC_ERROR_NONE) {
      if (rc_err != NULL) {
	rc_err(file, line_c, ret, buf);
      }
      continue;
    }
    
    /* handle the allocation */
    if (alloced_b) {
      BIT_SET(rc_p->rc_type, RC_ALLOCED);
    }
    BIT_SET(rc_p->rc_type, RC_USED);
  }
  
  (void)fclose(infile);
  
  /* see if there are any mandatory rcs left */
  mand_c = 0;
  for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
    if ((rc_p->rc_type & RC_MAND) && (! (rc_p->rc_type & RC_USED))) {
      const char	*type_str;
      
      type_str = rc_type_string(rc_p, NULL);
      if (type_str == NULL) {
	type_str = "type-error";
      }
      (void)sprintf(buf, "label '%s' of type '%s'", rc_p->rc_label, type_str);
      if (rc_err != NULL) {
	rc_err(file, line_c, RC_ERROR_MAND, buf);
      }
      mand_c++;
    }
  }
  
  if (mand_c > 0) {
    return RC_ERROR_MAND;
  }
  else {
    return RC_ERROR_NONE;
  }
}

/*
 * int rc_compare
 *
 * DESCRIPTION:
 *
 * Calls the error function for each lines that is in the RC file and not
 * in the RC list and vice versa.
 *
 * RETURNS:
 *
 * Returns RC error codes.
 *
 * ARGUMENTS:
 *
 * file - path of the RC file to be read and processed.
 *
 * rc_list - RC array to fill with the values from the file.  The rc_type
 * field of each entry will be altered to flag used entries.
 *
 * rc_err - function which will called to report each processing error
 * found in the RC file and for each RC list entry not listed in the
 * file.
 */
int	rc_compare(const char *file, rc_t *rc_list, const rc_err_t rc_err)
{
  char		*line, read_buf[MAX_LINE_SIZE];
  rc_t		*rc_p;
  FILE		*infile;
  
  /* open the RC file */
  infile = fopen(file, "r");
  if (infile == NULL) {
    return RC_ERROR_FILE;
  }
  
  /* clear the used flags */
  for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
    BIT_CLEAR(rc_p->rc_type, RC_USED);
  }
  
  /* read each line and look for a match */
  for (;;) {
    line = read_line(infile, NULL, read_buf, sizeof(read_buf));
    if (line == NULL) {
      break;
    }
    
    /* look for the label */
    for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
      int	len;
      
      len = strlen(rc_p->rc_label);
      if (strncmp(rc_p->rc_label, line, len) == 0
	  && (*(line + len) == ' ' || *(line + len) == '\t'
	      || RC_ASSIGN_CHAR == *(line + len))) {
	line += len;
	break;
      }
    }
    
    /* we couldn't find the label, try next line */
    if (rc_p->rc_label == NULL) {
      if (rc_err != NULL) {
	rc_err(file, 0, RC_ERROR_LABEL, line);
      }
      continue;
    }
    
    for (; *line == ' ' || *line == '\t'; line++) {
    }
    if (RC_ASSIGN_CHAR == *line) {
      for (line++ ; *line == ' ' || *line == '\t'; line++) {
      }
    }
    
    BIT_SET(rc_p->rc_type, RC_USED);
  }
  
  /* look for any unsatisfied rc_list entries */
  for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
    if (BIT_IS_SET(rc_p->rc_type, RC_USED)) {
      BIT_CLEAR(rc_p->rc_type, RC_USED);
    }
    else {
      if (rc_err != NULL) {
	rc_err("none", 0, RC_ERROR_MISSING, rc_p->rc_label);
      }
    }
  }
  
  (void)fclose(infile);
  
  return RC_ERROR_NONE;
}

/*
 * int rc_display
 *
 * DESCRIPTION:
 *
 * Prints the value of each of the entries in the RC_LIST to the standard
 * out stream.
 *
 * RETURNS:
 *
 * Returns RC error codes.
 *
 * ARGUMENTS:
 *
 * rc_list - RC array whose values we are to dump to stdout.
 */
int	rc_display(const rc_t *rc_list)
{
  const rc_t	*rc_p;
  const char	*type_str;
  char		buf[1024];
  int		ret, len, final = RC_ERROR_NONE;
  
  /* look for the label */
  for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
    
    /* get the type of the entry */
    type_str = rc_type_string(rc_p, &ret);
    if (type_str == NULL) {
      (void)printf("type conversion for '%s' failed: %s\n",
		   rc_p->rc_label, rc_strerror(ret));
      /* NOTE: keep going though */
      continue;
    }
    
    (void)printf("Var '%s', type '%s' = ", rc_p->rc_label, type_str);
    if (RC_TYPE(rc_p->rc_type) == RC_CHAR_P) {
      (void)printf("\n   ");
    }
    
    ret = rc_value_string(rc_p, buf, sizeof(buf), &len);
    if (ret != RC_ERROR_NONE) {
      final = ret;
      (void)printf("untranslate error: %s\n", rc_strerror(ret));
      /* NOTE: keep going though */
      continue;
    }
    
    (void)printf("%.*s\n", len, buf);
  }
  
  return final;
}

/*
 * int rc_cleanup
 *
 * DESCRIPTION:
 *
 * Remove any allocations from the RC list after a rc_process was called.
 *
 * RETURNS:
 *
 * Returns RC error codes.
 *
 * ARGUMENTS:
 *
 * rc_list - RC array whose entries will be freed.  The rc_type field of
 * each entry will be altered to clear flags marking the memory
 * allocations and loaded status.
 */
int	rc_cleanup(rc_t *rc_list)
{
  rc_t	*rc_p;
  
  for (rc_p = rc_list; rc_p->rc_label != RC_LAST; rc_p++) {
    if (BIT_IS_SET(rc_p->rc_type, RC_ALLOCED)) {
      BIT_CLEAR(rc_p->rc_type, RC_ALLOCED);
      (void)type_free(rc_p->rc_type, rc_p->rc_variable);
    }
    BIT_CLEAR(rc_p->rc_type, RC_USED);
  }
  BIT_CLEAR(rc_list->rc_type, RC_PROCESSED);
  
  return RC_ERROR_NONE;
}

/*
 * int rc_was_processed
 *
 * DESCRIPTION:
 *
 * Used to test whether a RC list has already been processed or not.
 *
 * RETURNS:
 *
 * Return 1 if the RC list has been processed already else 0.
 *
 * ARGUMENTS:
 *
 * rc_list - RC array to test.
 */
int	rc_was_processed(rc_t *rc_list)
{
  /* mark the list as processed */
  if (rc_list->rc_label != RC_LAST
      && BIT_IS_SET(rc_list->rc_type, RC_PROCESSED)) {
    return 1;
  }
  else {
    return 0;
  }
}

/*
 * int rc_entry_was_loaded
 *
 * DESCRIPTION:
 *
 * Used to test whether a RC list entry was loaded from the RC file
 * during a previous call to rc_process.
 *
 * RETURNS:
 *
 * Return 1 if the RC list entry was loaded already else 0.
 *
 * ARGUMENTS:
 *
 * rc_entry_ - pointer to a RC list entry to test.
 */
int	rc_entry_was_loaded(const rc_t *rc_entry_p)
{
  if (rc_entry_p->rc_label != RC_LAST
      && BIT_IS_SET(rc_entry_p->rc_type, RC_USED)) {
    return 1;
  }
  else {
    return 0;
  }
}

/*
 * int rc_entry_is_allocated
 *
 * DESCRIPTION:
 *
 * Used to test whether memory was allocated for a RC list entry during a
 * previous call to rc_process.
 *
 * RETURNS:
 *
 * Return 1 if the RC list entry has allocated memory else 0.
 *
 * ARGUMENTS:
 *
 * rc_entry_ - pointer to a RC list entry to test.
 */
int	rc_entry_is_allocated(const rc_t *rc_entry_p)
{
  if (rc_entry_p->rc_label != RC_LAST
      && BIT_IS_SET(rc_entry_p->rc_type, RC_ALLOCED)) {
    return 1;
  }
  else {
    return 0;
  }
}

/*
 * const char *rc_strerror
 *
 * DESCRIPTION:
 *
 * Used to pretty-print RC error codes.
 *
 * RETURNS:
 *
 * Returns the string equivalent of the error.
 *
 * ARGUMENTS:
 *
 * error - the error value to lookup.
 */
const char	*rc_strerror(const int error)
{
  error_str_t	*err_p;
  
  for (err_p = errors; err_p->es_error != 0; err_p++) {
    if (err_p->es_error == error) {
      return err_p->es_string;
    }
  }
  
  return INVALID_ERROR;
}
