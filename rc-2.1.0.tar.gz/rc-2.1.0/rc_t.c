/*
 * Runtime Configuration test routines...
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the rc package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted via http://256.com/gray/
 *
 * $Id: rc_t.c,v 1.12 2000/03/09 04:00:42 gray Exp $
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(unix)
#include <unistd.h>
#endif

#include "rc.h"

static	char	*rcs_id =
  "$Id: rc_t.c,v 1.12 2000/03/09 04:00:42 gray Exp $";

#define TEST_FILE	"rc_test"

/* local variables */
static	int	err_c = 0;		/* number of errors found in file */
static	int	err_last_line = 0;	/* last line number of error */
static	int	err_last_err = 0;	/* last rc error number of error */
static	int	verbose_b = 0;		/* verbose messages */

/*
 * static void rc_err
 *
 * DESCRIPTION:
 *
 * Record an error that was detected in the rc-file.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * path - Path to the rc-file.
 *
 * line_n - Line number in the file that had the error.
 *
 * err - RC error number of the error.
 *
 * data - Any associated additional data.
 */
static void rc_err(const char *path, const int line_n,
		   const int err, const char *data)
{
  err_c++;
  err_last_line = line_n;
  err_last_err = err;
}

/*
 * static void write_file
 *
 * DESCRIPTION:
 *
 * Write our test RC file with line.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * contents - What to write into the file.
 */
static	void	write_file(const char *contents)
{
  FILE	*outfile;
  
  /* open our test program */
  outfile = fopen(TEST_FILE, "w");
  if (outfile == NULL) {
    perror(TEST_FILE);
    exit(1);
  }
  (void)fputs(contents, outfile);
  (void)fclose(outfile);
}

/*
 * static void read_file
 *
 * DESCRIPTION:
 *
 * Read in a RC file and verify that we got the same error count, error
 * line, error value, etc.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * contents - What was written into the file.
 *
 * rc_list - List of rc structures that we will pass to rc_process.
 *
 * proper_rc_ret - Expected return value from rc process.
 *
 * proper_err_n - Expected number of errors.
 *
 * proper_err_last_line - Expected last error line number.
 *
 * proper_err_last_err - Expected last error value.
 */
static	void	read_file(const char *contents, rc_t *rc_list,
			  const int proper_rc_ret,
			  const int proper_err_n,
			  const int proper_err_last_line,
			  const int proper_err_last_err)
{
  int	ret;
  
  /* reset global error counter */
  err_c = 0;
  err_last_line = 0;
  err_last_err = 0;
  
  /* process the rc file */
  ret = rc_process(TEST_FILE, rc_list, rc_err);
  if (ret != proper_rc_ret) {
    (void)printf("rc_process returned '%s' (%d) instead of '%s' (%d) \n",
		 rc_strerror(ret), ret,
		 rc_strerror(proper_rc_ret), proper_rc_ret);
    if (contents != NULL) {
      (void)printf("File contents:\n%s\n", contents);
    }
    exit(1);
  }
  
  if (err_c != proper_err_n) {
    (void)printf("%d errors found in file not %d.\n",
		 err_c, proper_err_n);
    (void)printf("Last error on line %d: %s (%d)\n",
		 err_last_line, rc_strerror(err_last_err), err_last_err);
    (void)printf("File contents:\n%s\n", contents);
    exit(1);
  }
  
  if (proper_err_last_line != err_last_line) {
    (void)printf("Error last line %d is not %d.\n",
		 proper_err_last_line, err_last_line);
    (void)printf("File contents:\n%s\n", contents);
    exit(1);
  }
  
  if (proper_err_last_err != err_last_err) {
    (void)printf("Error last error value '%s' (%d) is not '%s' (%d).\n",
		 rc_strerror(proper_err_last_err), proper_err_last_err,
		 rc_strerror(err_last_err), err_last_err);
    (void)printf("File contents:\n%s\n", contents);
    exit(1);
  }
}

/*
 * static void value_check
 *
 * DESCRIPTION:
 *
 * Check to make sure that a variables value is the same.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * contents - What was written into the file.
 *
 * rc_list - List of rc structures we are cleaning up.
 *
 * var_p - Pointer to variable.
 *
 * var_alloced_b - Whether the variable will be assigned a pointer to value.
 *
 * var_size - Size of the variable.  < 0 if strlen is necessary.
 *
 * first_b - Is the first run so should we store the value?
 */
static	void	value_check(const char *contents, rc_t *rc_list,
			    const void *var_p, const int var_alloced_b,
			    const int var_size, const int first_b)

{
  static int	is_null_b = 0;
  static char	value[1024];
  int		ret;
  char		*value_p;
  
  /* it should have been processed */
  if (! rc_was_processed(rc_list)) {
    (void)printf("Rc list should say it was processed\n");
    if (contents != NULL) {
      (void)printf("File contents:\n%s\n", contents);
    }
    exit(1);
  }
  
  /* was the 1st entry loaded */
  if (! rc_entry_was_loaded(rc_list)) {
    (void)printf("1st rc-entry should say it's been loaded\n");
    if (contents != NULL) {
      (void)printf("File contents:\n%s\n", contents);
    }
    exit(1);
  }
  
  /* if allocated, the 1st entry should say so */
  if (var_alloced_b && (! rc_entry_is_allocated(rc_list))) {
    (void)printf("1st rc-entry should say it's been allocated\n");
    if (contents != NULL) {
      (void)printf("File contents:\n%s\n", contents);
    }
    exit(1);
  }
  
  /* if _not_ allocated, the 1st entry should agree */
  if ((! var_alloced_b) && rc_entry_is_allocated(rc_list)) {
    (void)printf("1st rc-entry should say it's _not_ been allocated\n");
    if (contents != NULL) {
      (void)printf("File contents:\n%s\n", contents);
    }
    exit(1);
  }
  
  if (var_alloced_b) {
    value_p = *(char **)var_p;
  }
  else {
    value_p = (char *)var_p;
  }
  
  if (first_b) {
    if (value_p == NULL) {
      is_null_b = 1;
    }
    else {
      is_null_b = 0;
      if (var_size < 0) {
	strcpy(value, value_p);
      }
      else {
	memcpy(value, value_p, var_size);
      }
    }
  }
  else {
    if (is_null_b && value_p != NULL) {
      (void)printf("Values do not match.  Previous were NULL now not.\n");
      if (contents != NULL) {
	(void)printf("File contents:\n%s\n", contents);
      }
      exit(1);
    }
    
    if ((! is_null_b) && value_p == NULL) {
      (void)printf("Values do not match.  Previous value wasn't NULL.\n");
      if (contents != NULL) {
	(void)printf("File contents:\n%s\n", contents);
      }
      exit(1);
    }
    
    if (var_size < 0) {
      ret = strcmp(value, value_p);
    }
    else {
      ret = memcmp(value, value_p, var_size);
    }
    
    if (ret != 0) {
      (void)printf("Values do not match.  Previous value differs.\n");
      if (contents != NULL) {
	(void)printf("File contents:\n%s\n", contents);
      }
      exit(1);
    }
  }
}

/*
 * static void cleanup
 *
 * DESCRIPTION:
 *
 * Cleanup our rc list with error checking.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * rc_list - List of rc structures we are cleaning up.
 */
static	void	cleanup(rc_t *rc_list)
{
  int	ret;
  
  ret = rc_cleanup(rc_list);
  if (ret != RC_ERROR_NONE) {
    (void)printf("rc_cleanup failed: %s (%d)\n",
		 rc_strerror(ret), ret);
    exit(1);
  }
}

/*
 * static void process_file
 *
 * DESCRIPTION:
 *
 * Take a specified value and write it into a test file in a number of
 * different ways and make sure that we get it back the same.  The
 * user can then test the value to make sure it matches.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * value - The value string to write into the test file.
 *
 * rc_list - List of rc structures that we will pass to rc_process.
 *
 * var_p - Pointer to variable that should get the same value.
 *
 * var_alloced_b - Whether the variable will be assigned a pointer to value.
 *
 * var_size - Size of the variable.  < 0 if strlen is necessary.
 */
static	void	process_file(const char *value, rc_t *rc_list,
			     const void *var_p, const int var_alloced_b,
			     const int var_size)
{
  char	line[2048];
  
  /* write the first value */
  (void)sprintf(line, "x=%s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 1);
  cleanup(rc_list);
  
  /* starting spaces */
  (void)sprintf(line, " x=%s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* spaces around = */
  (void)sprintf(line, "  x =%s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  (void)sprintf(line, "  x = %s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* extra spaces at end */
  (void)sprintf(line, "  x  =  %s \n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* handling of \t */
  (void)sprintf(line, "\t  x\t  =\t  %s \t\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* no \n */
  (void)sprintf(line, " x\t  =\t  %s", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* handling of \r */
  (void)sprintf(line, " x\t  =\t  %s\r", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* \r\n */
  (void)sprintf(line, " x\t  =\t  %s\r\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* blank lines */
  (void)sprintf(line, "\nx = %s\n\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* comments */
  (void)sprintf(line, "# this is a comment\nx = %s\n# x = foo\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* comments @ end of line */
  (void)sprintf(line, "x = %s # comment here\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* line wrap */
  (void)sprintf(line, "x = \\\n%s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* line wrap */
  (void)sprintf(line, "x = \\\n  %s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* line wrap */
  (void)sprintf(line, "x = \\\n \t %s\n", value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 0, 0, 0);
  value_check(line, rc_list, var_p, var_alloced_b, var_size, 0);
  cleanup(rc_list);
  
  /* 
   * Testing some error codes
   */
  
  /* no file */
  (void)unlink(TEST_FILE);
  read_file("", rc_list, RC_ERROR_FILE, 0, 0, 0);
  
  /* unknown field */
  (void)sprintf(line, "x = %s\ny = foo\n", value);
  write_file(line);
  read_file("", rc_list, RC_ERROR_NONE, 1, 2, RC_ERROR_UNKNOWN);
  cleanup(rc_list);
  
  /* no usage -- default is mandatory */
  (void)sprintf(line, "\n");
  write_file(line);
  read_file(line, rc_list, RC_ERROR_MAND, 1, 1, RC_ERROR_MAND);
  cleanup(rc_list);
  
  /* multiple usage */
  (void)sprintf(line, "x = %s\nx = %s\n", value, value);
  write_file(line);
  read_file(line, rc_list, RC_ERROR_NONE, 1, 2, RC_ERROR_DUPLICATE);
  
  /* NOTE: we do not cleanup the last one */
  
  /* lastly, we remove the file */
  (void)unlink(TEST_FILE);
}

/*
 * static void test_bool
 *
 * DESCRIPTION:
 *
 * Test boolean values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_bool(void)
{
  char	var_bool_b;
  rc_t	rc_list[] = {{ "x", RC_BOOL | RC_MAND, &var_bool_b }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing boolean type.\n");
  }
  
  process_file("1", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (! var_bool_b) {
    (void)printf("Boolean value should be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("on", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (! var_bool_b) {
    (void)printf("Boolean value should be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("Yes", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (! var_bool_b) {
    (void)printf("Boolean value should be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("true", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (! var_bool_b) {
    (void)printf("Boolean value should be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("0", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (var_bool_b) {
    (void)printf("Boolean should not be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("OFF", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (var_bool_b) {
    (void)printf("Boolean should not be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("no", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (var_bool_b) {
    (void)printf("Boolean should not be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("false", rc_list, &var_bool_b, 0, sizeof(var_bool_b));
  if (var_bool_b) {
    (void)printf("Boolean should not be enabled\n");
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void test_char
 *
 * DESCRIPTION:
 *
 * Test character values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_char(void)
{
  char	var_char;
  rc_t	rc_list[] = {{ "x", RC_CHAR | RC_MAND, &var_char }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing character type.\n");
  }
  
  process_file("1", rc_list, &var_char, 0, sizeof(var_char));
  if (var_char != '1') {
    (void)printf("Char is '%c' not '1'\n", var_char);
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("'1'", rc_list, &var_char, 0, sizeof(var_char));
  if (var_char != '1') {
    (void)printf("Char is '%c' not '1'\n", var_char);
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("' '", rc_list, &var_char, 0, sizeof(var_char));
  if (var_char != ' ') {
    (void)printf("Char is '%c' not ' '\n", var_char);
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("\001", rc_list, &var_char, 0, sizeof(var_char));
  if (var_char != '\001') {
    (void)printf("Char is '%c' not '\\001'\n", var_char);
    exit(1);
  }
  cleanup(rc_list);
  
  process_file("'\123'", rc_list, &var_char, 0, sizeof(var_char));
  if (var_char != '\123') {
    (void)printf("Char is '%c' not '\\123'\n", var_char);
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void test_char_p
 *
 * DESCRIPTION:
 *
 * Test character-pointer values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_char_p(void)
{
  char	*var_char_p, *val_p;
  rc_t	rc_list[] = {{ "x", RC_CHAR_P | RC_MAND, &var_char_p }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing character-pointer type.\n");
  }
  
  val_p = "hello";
  process_file(val_p, rc_list, &var_char_p, 1, -1);
  if (strcmp(var_char_p, val_p) != 0) {
    (void)printf("Char_p is '%s' not '%s'\n", var_char_p, val_p);
    exit(1);
  }
  cleanup(rc_list);
  
  val_p = "";
  process_file(val_p, rc_list, &var_char_p, 1, -1);
  if (strcmp(var_char_p, val_p) != 0) {
    (void)printf("Char_p is '%s' not '%s'\n", var_char_p, val_p);
    exit(1);
  }
  cleanup(rc_list);
  
  val_p = "\123";
  process_file(val_p, rc_list, &var_char_p, 1, -1);
  if (strcmp(var_char_p, val_p) != 0) {
    (void)printf("Char_p is '%s' not '%s'\n", var_char_p, val_p);
    exit(1);
  }
  cleanup(rc_list);
  
  val_p = "hello";
  process_file("\"hello\"", rc_list, &var_char_p, 1, -1);
  if (strcmp(var_char_p, val_p) != 0) {
    (void)printf("Char_p is '%s' not '%s'\n", var_char_p, val_p);
    exit(1);
  }
  cleanup(rc_list);
  
  val_p = "hello";
  process_file("'hello'", rc_list, &var_char_p, 1, -1);
  if (strcmp(var_char_p, val_p) != 0) {
    (void)printf("Char_p is '%s' not '%s'\n", var_char_p, val_p);
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void test_short
 *
 * DESCRIPTION:
 *
 * Test short integer values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_short(void)
{
  short	var_short, val;
  char	val_str[64];
  rc_t	rc_list[] = {{ "x", RC_SHORT | RC_MAND, &var_short }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing short-integer type.\n");
  }
  
  val = 0;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 2;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -1;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1024;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 32767;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -32768;
  (void)sprintf(val_str, "%hd", val);
  process_file(val_str, rc_list, &var_short, 0, sizeof(var_short));
  if (var_short != val) {
    (void)printf("Short is %hd not %hd\n", var_short, val);
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void test_int
 *
 * DESCRIPTION:
 *
 * Test integer values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_int(void)
{
  int	var_int, val;
  char	val_str[64];
  rc_t	rc_list[] = {{ "x", RC_INT | RC_MAND, &var_int }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing integer type.\n");
  }
  
  val = 0;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 2;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -1;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1024;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 2147483647;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -2147483648U;
  (void)sprintf(val_str, "%d", val);
  process_file(val_str, rc_list, &var_int, 0, sizeof(var_int));
  if (var_int != val) {
    (void)printf("Int is %d not %d\n", var_int, val);
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void test_long
 *
 * DESCRIPTION:
 *
 * Test long-integer values.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * None.
 */
static	void	test_long(void)
{
  long	var_long, val;
  char	val_str[64];
  rc_t	rc_list[] = {{ "x", RC_LONG | RC_MAND, &var_long }, { NULL }};
  
  if (verbose_b) {
    (void)printf("Testing long-integer type.\n");
  }
  
  val = 0;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 2;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -1;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 1024;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = 2147483647;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
  
  val = -2147483648U;
  (void)sprintf(val_str, "%ld", val);
  process_file(val_str, rc_list, &var_long, 0, sizeof(var_long));
  if (var_long != val) {
    (void)printf("Int is %ld not %ld\n", var_long, val);
    exit(1);
  }
  cleanup(rc_list);
}

/*
 * static void usage
 *
 * DESCRIPTION:
 *
 * Print usage message.
 *
 * RETURNS:
 * 
 * None.
 *
 * ARGUMENTS:
 *
 * program - Name of the program from argv[0]
 */
static	void	usage(const char *program)
{
  (void)printf("Usage: %s [-v\n", program);
  (void)printf("   -v         - verbose messages\n");
  exit(1);
}

int main(int argc, char **argv)
{
  char	*program;
  
  program = *argv;
  argc--, argv++;
  
  for (; argc > 0 && **argv == '-'; argc--, argv++) {
    if (*(*argv + 1) == '\0') {
      break;
    }
    else if (*(*argv + 1) == 'v') {
      verbose_b = 1;
    }
    else {
      usage(program);
    }
  }
  
  if (argc > 0) {
    usage(program);
  }
  
  test_bool();
  test_char();
  test_char_p();
  test_short();
  test_int();
  test_long();
  
  exit(0);
	return 0;
}
