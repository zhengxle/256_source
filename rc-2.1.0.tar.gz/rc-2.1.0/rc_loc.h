/*
 * Runtime config local definitions...
 *
 * Copyright 2000 by Gray Watson
 *
 * This file is part of the rc package.
 *
 * Permission to use, copy, modify, and distribute this software for
 * any purpose and without fee is hereby granted, provided that the
 * above copyright notice and this permission notice appear in all
 * copies, and that the name of Gray Watson not be used in advertising
 * or publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted via http://256.com/gray/
 *
 * $Id: rc_loc.h,v 1.8 2000/03/09 04:00:42 gray Exp $
 */

#ifndef __RC_LOC_H__
#define __RC_LOC_H__

#if defined(unix)
#include <syslog.h>			/* for syslog defines below */
#endif

/*
 * generic constants
 */

/*
 * bitflag tools for Variable and a Flag
 */
#define BIT_FLAG(x)		(1 << (x))
#define BIT_SET(v,f)		(v) |= (f)
#define BIT_CLEAR(v,f)		(v) &= ~(f)
#define BIT_IS_SET(v,f)		((v) & (f))
#define BIT_TOGGLE(v,f)		(v) ^= (f)

#define BITS_IN_BYTE		8
#define BITS(type)		(sizeof(type) * BITS_IN_BYTE)

/*
 * local defines
 */

/* this needs to be above any type.h types */
/* #define RC_MAND 0x1000 */
#define RC_ALLOCED	0x2000		/* space was allocated for variable */
#define RC_USED		0x4000		/* the rc entry was used */
#define RC_PROCESSED	0x8000		/* mark the rc-list as processed */

#define RC_TYPE(type)		((type) & 0x0FFF)
#define MAX_LINE_SIZE		2048
#define RC_ASSIGN_CHAR		'='			/* assign char */

/* translate pair: "\1" -> '2' */
#define SPECIAL_CHARS		"e\033^^\"\"''\\\\n\nr\rt\tb\bf\fa\007"

/*
 * to map syslog facility to integer
 */
typedef struct {
  char		*fm_facility;		/* assocaited string */
  int		fm_value;		/* value number */
} fac_map_t;

#if defined(unix)
static	fac_map_t	facilities[] = {
  { "kern",		LOG_KERN },
  { "user",		LOG_USER },
  { "mail",		LOG_MAIL },
  { "daemon",		LOG_DAEMON },
  { "auth",		LOG_AUTH },
  { "lpr",		LOG_LPR },
  { "news",		LOG_NEWS },
  { "uucp",		LOG_UUCP },
  { "cron",		LOG_CRON },
  { "local0",		LOG_LOCAL0 },
  { "local1",		LOG_LOCAL1 },
  { "local2",		LOG_LOCAL2 },
  { "local3",		LOG_LOCAL3 },
  { "local4",		LOG_LOCAL4 },
  { "local5",		LOG_LOCAL5 },
  { "local6",		LOG_LOCAL6 },
  { "local7",		LOG_LOCAL7 },
  { NULL }
};
#endif

/*
 * to map error to string
 */
typedef struct {
  int		es_error;		/* error number */
  char		*es_string;		/* assocaited string */
} error_str_t;

static	error_str_t	errors[] = {
  { RC_ERROR_NONE,		"no error" },
  { RC_ERROR_FILE,		"could not open file" },
  { RC_ERROR_ALLOC,		"error allocating memory" },
  { RC_ERROR_MAND,		"mandatory rc field not specified" },
  { RC_ERROR_UNKNOWN,		"unknown line in rc file" },
  { RC_ERROR_TYPE,		"unknown rc type in structure" },
  { RC_ERROR_LABEL,		"cannot find match label in rc list" },
  { RC_ERROR_MISSING,		"label in rc list was not referenced" },
  { RC_ERROR_DUPLICATE,		"rc field referenced more than once" },
  { RC_ERROR_FACILITY,		"unknown syslog facility" },
  { 0 }
};

#define INVALID_ERROR	"invalid error code"

#endif /* ! __RC_LOC_H__ */
