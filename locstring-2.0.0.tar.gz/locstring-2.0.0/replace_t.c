/*
 * Token replacement routine.
 *
 * Copyright 1999 by Gray Watson
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and that the name of Gray Watson not be used in advertising or
 * publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 */

#include <stdio.h>

#include "replace.h"

#define MAX_REPLACEMENTS	64

#ifdef __GNUC__
#ident "$Id: replace_t.c,v 1.3 2000/03/07 21:49:40 gray Exp $";
#else
static char *rcs_id =
"$Id: replace_t.c,v 1.3 2000/03/07 21:49:40 gray Exp $";
#endif

int	main(int argc, char **argv)
{
  char		*program, *tok_p, *format, output[1024];
  replace_t	replacements[MAX_REPLACEMENTS + 1], *replace_p;
  int		len;
  
  program = *argv;
  argc--, argv++;
  
  if (argc == 0) {
    (void)fprintf(stderr,
		  "Usage: %s format [token1=value1] [token2=value2] [...]\n",
		  program);
    exit(1);
  }
  
  format = *argv;
  argc--, argv++;
  
  replace_p = replacements;
  while (argc > 0) {
    if (replace_p >= replacements + MAX_REPLACEMENTS) {
      (void)fprintf(stderr, "%s: too many token=value pairs specified\n",
		    program);
      exit(1);
    }
    
    replace_p->re_token = *argv;
    
    for (tok_p = *argv; *tok_p != '\0' && *tok_p != '='; tok_p++) {
    }
    if (*tok_p == '\0') {
      (void)fprintf(stderr,
		    "%s: no = specified in the token=value argument: %s\n",
		    program, replace_p->re_token);
      exit(1);
    }
    
    *tok_p++ = '\0';
    replace_p->re_value = tok_p;
    replace_p++;
    
    argc--, argv++;
  }
  
  /* add in the terminating NULL */
  replace_p->re_token = NULL;
  
  len = replace_tokens(format, -1, replacements, output, sizeof(output));
  
  (void)printf("Replace_format outputed:\n");
  (void)printf("%.*s\n", len, output);
  
  exit(0);
}
