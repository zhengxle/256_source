/*
 * Token replacement routine.
 *
 * Copyright 1999 by Gray Watson
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and that the name of Gray Watson not be used in advertising or
 * publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 */

#ifdef __GNUC__
#ident "$Id: replace.c,v 1.4 2000/03/07 21:49:40 gray Exp $";
#else
static char *rcs_id =
"$Id: replace.c,v 1.4 2000/03/07 21:49:40 gray Exp $";
#endif

static	char	*replace_version = "$Replace Version: 2.0.0 March-7-2000 $";

#include <stdio.h>			/* for vsnprintf */
#include <stdlib.h>			/* for abort in some va_start()s */

#ifdef unix
#include <string.h>
#endif

#include "replace.h"

/*
 * Grid used by the token match routines to identify the valid token
 * characters.
 */
static	int	token_grid[256] = {
  /* 0 -> 15 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 16 -> 31 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 32 ' ' -> 47 '/' */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 48 '0' -> 63 '/' */
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
  /* 64 '@' -> 79 'O' */
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 80 'P' -> 95 '_' */
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1,
  /* 96 '\`' -> 111 'o' */
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 112 'p' -> 127 */
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  /* 128 -> 143 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 144 -> 159 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 160 -> 175 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 176 -> 191 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 192 -> 207 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 208 -> 223 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 224 -> 239 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  /* 240 -> 255 */
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

/*
 * int replace_tokens
 *
 * DESCRIPTION:
 *
 * Take a input format with $token type tokens and a list of "token",
 * "value" pairs and insert the values where the tokens are in the
 * output buffer.
 *
 * For instance, if we have a format string: "ssh -l $user $host" and
 * a replacement array with { "user", "gray" }, { "host",
 * "gate.foo.com" } then the output buffer (if long enough) will
 * contain "ssh -l gray gate.foo.com".  The token name starts after $
 * and ends with a character not in the set "[a-zA-Z0-9_]".  You can
 * also use parentheses around the token if it does not end with a
 * space or tab.  For instance: "ssh -l $user $(host)00.$(domain)".
 * If "user" was "gray", "host" was server, and "domain" was "foo.com"
 * then the output buffer will contain "ssh -l gray server00.foo.com".
 * For this reason, parentheses cannot be contained in the token name
 * in the replacements array.  However, any characters including
 * parens can be in the replacement array values.
 *
 * NOTE: the output buffer will be \0 terminated only if there is
 * enough room for the \0 character.
 *
 * NOTE: if a token is in the format and not in the replacements
 * array, it will replaced with the empty string "".
 *
 * RETURNS:
 *
 * Number of characters added to the output buffer.
 *
 * ARGUMENTS:
 *
 * format -> Format with $tokens which describe what gets written into
 * the output buffer.  To specify a $ character which you want to make
 * it into the output buffer, you need to specify $$ like printf.
 *
 * format_len -> Length of the format string or -1 if it ends with a
 * \0.
 *
 * replacements -> Array of replace_t structures which list the tokens
 * and their associated values.  The array is terminated with an entry
 * where the token is a NULL pointer.
 *
 * output_buf <- Output buffer provided by the caller which will be
 * filled with characters from the format and the replacement values.
 *
 * output_buf_size -> Size of the output buffer.
 */
int	replace_tokens(const char *format, const int format_len,
		       const replace_t *replacements, char *output_buf,
		       const int output_buf_size)
{
  const char		*format_p, *end_p, *format_bounds_p;
  char			*out_p, *out_bounds_p, *val_p;
  const replace_t	*replace_p;
  int			paren_b = 0, len;
  
  if (format_len >= 0) {
    format_bounds_p = format + format_len;
  }
  else {
    for (format_bounds_p = format;
	 *format_bounds_p != '\0';
	 format_bounds_p++) {
    }
  }
  
  out_p = output_buf;
  out_bounds_p = output_buf + output_buf_size;
  
  for (format_p = format; format_p < format_bounds_p;) {
    
    /* just copy it to the output buffer if it isn't a $ */
    if (*format_p != '$') {
      if (out_p >= out_bounds_p) {
	break;
      }
      *out_p++ = *format_p++;
      continue;
    }
    format_p++;
    
    /* do we have a $$ string */
    if (*format_p == '$') {
      if (out_p >= out_bounds_p) {
	break;
      }
      *out_p++ = '$';
      format_p++;
      continue;
    }
    
    /* are we looking for the end of the format */
    if (*format_p == '(') {
      format_p++;
      for (end_p = format_p;
	   end_p < format_bounds_p && *end_p != ')';
	   end_p++) {
      }
      paren_b = 1;
    }
    else {
      for (end_p = format_p;
	   end_p < format_bounds_p && token_grid[(unsigned char)*end_p];
	   end_p++) {
      }
      paren_b = 0;
    }
    
    /* NOTE: end_p can be at the end of the buffer */
    if (end_p > format_bounds_p) {
      break;
    }
    
    /* find a match to our token */
    len = end_p - format_p;
    for (replace_p = replacements; replace_p->re_token != NULL; replace_p++) {
      /* do we have a token match? */
      if (strncmp(format_p, replace_p->re_token, len) == 0
	  && replace_p->re_token[len] == '\0') {
	/* copy the value into the output buffer */
	val_p = replace_p->re_value;
	while (out_p < out_bounds_p && *val_p != '\0') {
	  *out_p++ = *val_p++;
	}
	break;
      }
    }
    
    if (paren_b) {
      format_p = end_p + 1;
    }
    else {
      format_p = end_p;
    }
  }
  
  if (out_p < out_bounds_p) {
    *out_p = '\0';
  }
  
  return out_p - output_buf;
}
