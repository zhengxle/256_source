/*
 * Buffer addition routines.
 *
 * Copyright 1998 by Gray Watson
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and that the name of Gray Watson not be used in advertising or
 * publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 */

#include <stdio.h>			/* for vsnprintf */
#include <stdarg.h>			/* for ... */
#include <stdlib.h>			/* for abort in some va_start()s */

#ifdef __GNUC__
#ident "$Id: addbuf.c,v 1.9 2000/03/07 21:50:44 gray Exp $";
#else
static char *rcs_id =
"$Id: addbuf.c,v 1.9 2000/03/07 21:50:44 gray Exp $";
#endif

static	char	*addbuf_version = "$Addbuf Version: 2.0.0 March-7-2000 $";

/*
 * int addbuf_put
 *
 * DESCRIPTION:
 *
 * Add to a buffer a list of (const void *data, const int data_size)
 * pairs, advancing the buffer pointer so it is always at the end of
 * the data.  The list of items are terminated if the data pointer is
 * 0L.  If the length is < 0 it will add a string _including_ the '\0'
 * to the buffer.  Data items of length 0 are ignored.
 *
 * NOTE: this routine is exactly the same as addbuf_put except the \0 is
 * included if the length is < 0.
 *
 * RETURNS:
 *
 * Success - Number of characters added to the string buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to a buffer pointer.  We will be adding the data
 * items to this location and then advancing the pointer past the new
 * data.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will add
 * the data items to the buffer until it reaches this pointer.  If it
 * goes to write to this address it will return -1.
 *
 * ... - Variable arguments list of (const void *data, const int
 * data_size) pairs.  If the data_size is < 0 it will add a string
 * _including_ the '\0' to the buffer.
 */
int	addbuf_put(void **buf_pp, const void *bounds_p, ...)
{
  unsigned char	*buf_p = *buf_pp;
  void		*data, *start_p = *buf_pp;
  va_list	ap;
  int		len;
  
  va_start(ap, bounds_p);
  while (1) {
    /* get the pointer off the arg list */
    data = va_arg(ap, void *);
    if (data == 0L) {
      break;
    }
    
    /* get its length (or -1) off the arg list */
    len = (int)va_arg(ap, const int);
    if (len < 0) {
      len = strlen((char *)data) + 1;
    }
    if (len == 0) {
      /* ignore length of 0 items */
      continue;
    }
    
    /* are we about to overflow the buffer? */
    if (buf_p + len > (unsigned char *)bounds_p) {
      return -1;
    }
    
    /* we use memcpy instead of a loop because it _is_ faster - tested 12/96 */
    memcpy(buf_p, data, len);
    buf_p += len;
  }
  va_end(ap);
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  return buf_p - (unsigned char *)start_p;
}

/*
 * int addbuf_put_str
 *
 * DESCRIPTION:
 *
 * Add to a buffer a list of (const char *string, const int string_len)
 * pairs, advancing the buffer pointer so it is always at the end of
 * the data.  The list of items are terminated if the string pointer
 * is 0L.  If the string_len is < 0 it will add a string _not_
 * including the '\0' to the buffer.  Strings of length 0 are ignored.
 *
 * NOTE: this routine is exactly the same as addbuf_put except the \0 is
 * not included if the length is < 0.
 *
 * RETURNS:
 *
 * Success - Number of characters added to the string buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to a buffer pointer.  We will be adding the data
 * items to this location and then advancing the pointer past the new
 * data.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will add
 * the data items to the buffer until it reaches this pointer.  If it
 * goes to write to this address it will return -1.
 *
 * ... - Variable arguments list of (const char *string, const int
 * string_len) pairs.  If the string_len is < 0 it will add a string
 * _not_ including the '\0' to the buffer.  Strings of length 0 are
 * ignored.
 */
int	addbuf_put_str(void **buf_pp, const void *bounds_p, ...)
{
  unsigned char	*buf_p = *buf_pp;
  void		*str, *start_p = *buf_pp;
  va_list	ap;
  int		len;
  
  va_start(ap, bounds_p);
  while (1) {
    /* get the pointer off the arg list */
    str = va_arg(ap, char *);
    if (str == 0L) {
      break;
    }
    
    /* get its length (or -1) off the arg list */
    len = (int)va_arg(ap, const int);
    if (len < 0) {
      len = strlen(str);
    }
    if (len == 0) {
      /* ignore length of 0 items */
      continue;
    }
    
    /* are we about to overflow the buffer? */
    if (buf_p + len > (unsigned char *)bounds_p) {
      return -1;
    }
    
    /* we use memcpy instead of a loop because it _is_ faster - tested 12/96 */
    memcpy(buf_p, str, len);
    buf_p += len;
  }
  va_end(ap);
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  return buf_p - (unsigned char *)start_p;
}

#ifndef NO_VSNPRINTF
/*
 * int addbuf_snprintf
 *
 * DESCRIPTION:
 *
 * Add to a buffer a printf-like format and a variable number of
 * arguments.
 *
 * RETURNS:
 *
 * Success - Number of characters added to the string buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to a buffer pointer.  We will be adding the data
 * items to this location and then advancing the pointer past the new
 * data.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will add
 * the data items to the buffer until it reaches this pointer.  If it
 * goes to write to this address it will return -1.
 *
 * format - Printf-style format.
 *
 * ... - Arguments associated to the format.
 */
int	addbuf_snprintf(void **buf_pp, const void *bounds_p,
			const char *format, ...)
{
  va_list	ap;
  char		*buf_p = *buf_pp;
  int		len;
  
  len = (char *)bounds_p - buf_p;
  
  va_start(ap, format);
  (void)vsnprintf(buf_p, len, format, ap);
  va_end(ap);
  
  /*
   * Since on some operating systens, snprintf does not return the
   * number of characters it wrote into the buffer, we walk forward
   * looking for the \0.
   */
  len = 0;
  while (*buf_p != '\0' && buf_p < (char *)bounds_p) {
    len++;
    buf_p++;
  }
  
  /* advance our string pointer */
  *buf_pp = buf_p;
  
  return len;
}
#endif

/*
 * int addbuf_get
 *
 * DESCRIPTION:
 *
 * Get from a buffer a data which is unpacked into (void *data, const int
 * data_size) pairs, advancing the buffer pointer so it is always at
 * the end of the data.  The list of items are terminated if the data
 * pointer is 0L.  If the length is < 0 it will get a string including
 * its 0L to the buffer.
 *
 * RETURNS:
 *
 * Success - Number of characters added to the buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to our buffer which we will be adding information to
 * and advancing.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will get
 * the data items from the buffer until it reaches this pointer.  If
 * it goes to access this pointer, it will return -1.
 *
 * ... - Variable arguments list of (void *data, const int data_size)
 * pairs.
 */
int	addbuf_get(void **buf_pp, const void *bounds_p, ...)
{
  unsigned char	*data_p, *buf_p = *buf_pp;
  void		*data, *start_p = *buf_pp;
  va_list	ap;
  int		len;
  
  va_start(ap, bounds_p);
  while (1) {
    /* get the buffer pointer from the list */
    data = (void *)va_arg(ap, const void *);
    if (data == 0L) {
      break;
    }
    
    /* get the length */
    len = (int)va_arg(ap, const int);
    if (len == 0) {
      continue;
    }
    
    if (len > 0) {
      /* are we about to overflow the buffer? */
      if (buf_p + len > (unsigned char *)bounds_p) {
	return -1;
      }
      
      /* we use memcpy because it _is_ faster - tested 12/96 */
      memcpy(data, buf_p, len);
      buf_p += len;
    }
    else {
      /* don't know how long the string is so copy in 1 char at a time */
      data_p = data;
      while (buf_p < (unsigned char *)bounds_p) {
	*data_p++ = *buf_p;
	if (*buf_p == '\0') {
	  break;
	}
	buf_p++;
      }
      /* did we overflow the buffer? */
      if (buf_p >= (unsigned char *)bounds_p) {
	return -1;
      }
    }
  }
  va_end(ap);
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  return buf_p - (unsigned char *)start_p;
}

/*
 * int addbuf_put_uint
 *
 * DESCRIPTION:
 *
 * Add to a buffer a packed decimal value, advancing the buffer pointer
 * so it is always at the end of the data.  It will pack the decimal
 * into as few bytes as possible so addbuf_get_uint must be used on
 * the other side to unpack.
 *
 * RETURNS:
 *
 * Success - Number of characters added to the string buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to our buffer which we will be adding information to
 * and advancing.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will add
 * the data items to the buffer until it reaches this pointer.  If it
 * goes to write to this address it will return -1.
 *
 * val - Unsigned integer value that we are packing into the buffer.
 */
int	addbuf_put_uint(void **buf_pp, const void *bounds_p,
			const unsigned int val)
{
  unsigned int	work = val;
  unsigned char	ch, *buf_p = *buf_pp;
  unsigned int	ch_c;
  
  for (ch_c = 1;; ch_c++) {
    ch = work & 0177;
    work >>= 7;
    
    /* turn on high bit if there is more */
    if (work > 0) {
      ch |= 0200;
    }
    
    if (buf_p >= (unsigned char *)bounds_p) {
      return -1;
    }
    
    *buf_p++ = ch;
    
    /* we break here because we want 0 to be reflected by '\0' */
    if (work == 0) {
      break;
    }
  }
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  return ch_c;
}

/*
 * int addbuf_get_uint
 *
 * DESCRIPTION:
 *
 * Get from the buffer a packed decimal value, advancing the buffer
 * pointer so it is always at the end of the data.  The value must
 * have been stored with the addbuf_put_uint.
 *
 * WARNING: this does not check the size of unsigned int and makes no
 * attempt to protect against overflow.
 *
 * RETURNS:
 *
 * Success - Number of characters taken from the buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to our buffer which we will be unpacking the value
 * from and advancing.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will get
 * the data items from the buffer until it reaches this pointer.  If
 * it goes to access this pointer, it will return -1.
 *
 * val_p - Pointer to an unsigned integer which will be assigned the
 * unpacked value.
 */
int	addbuf_get_uint(void **buf_pp, const void *bounds_p,
			unsigned int *val_p)
{
  unsigned int	answer = 0, work = 0, shift = 0;
  unsigned char	ch, *buf_p = *buf_pp;
  unsigned int	ch_c;
  
  for (ch_c = 1;; ch_c++) {
    if (buf_p >= (unsigned char *)bounds_p) {
      return -1;
    }
    ch = *buf_p++;
    work = ch & 0177;
    
    answer |= (work << shift);
    shift += 7;
    
    /* do we have the continuation bit on? */
    if ((ch & 0200) == 0) {
      break;
    }
  }
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  if (val_p != 0L) {
    *val_p = answer;
  }
  return ch_c;
}

/*
 * int addbuf_put_ulong
 *
 * DESCRIPTION:
 *
 * Add to a buffer a packed decimal value, advancing the buffer pointer
 * so it is always at the end of the data.  It will pack the decimal
 * into as few bytes as possible so addbuf_get_ulong must be used on
 * the other side to unpack.  This routine works up to values in
 * excess of (2^29-1).
 *
 * RETURNS:
 *
 * Success - Number of characters added to the string buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to our buffer which we will be adding information to
 * and advancing.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will add
 * the data items to the buffer until it reaches this pointer.  If it
 * goes to write to this address it will return -1.
 *
 * val - Unsigned long integer value that we are packing into the buffer.
 */
int	addbuf_put_ulong(void **buf_pp, const void *bounds_p,
			 const unsigned long val)
{
  unsigned long	work = val;
  unsigned char	ch, *buf_p = *buf_pp;
  unsigned int	ch_c;
  
  for (ch_c = 1;; ch_c++) {
    ch = work & 0177;
    work >>= 7;
    
    /* turn on high bit if there is more */
    if (work > 0) {
      ch |= 0200;
    }
    
    if (buf_p >= (unsigned char *)bounds_p) {
      return -1;
    }
    
    *buf_p++ = ch;
    
    /* we break here because we want 0 to be reflected by '\0' */
    if (work == 0) {
      break;
    }
  }
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  return ch_c;
}

/*
 * int addbuf_get_ulong
 *
 * DESCRIPTION:
 *
 * Get from the buffer a packed decimal value, advancing the buffer
 * pointer so it is always at the end of the data.  The value must
 * have been stored with the addbuf_put_ulong.
 *
 * WARNING: this does not check the size of unsigned long and makes no
 * attempt to protect against overflow.
 *
 * RETURNS:
 *
 * Success - Number of characters taken from the buffer.
 *
 * Failure - -1 if the maximum buffer pointer was reached.
 *
 * ARGUMENTS:
 *
 * buf_pp - Pointer to our buffer which we will be unpacking the value
 * from and advancing.
 *
 * bounds_p - Boundary location past the end of the buffer.  It will get
 * the data items from the buffer until it reaches this pointer.  If
 * it goes to access this pointer, it will return -1.
 *
 * val_p - Pointer to an unsigned long integer which will be assigned the
 * unpacked value.
 */
int	addbuf_get_ulong(void **buf_pp, const void *bounds_p,
			 unsigned long *val_p)
{
  unsigned long	answer = 0, work = 0, shift = 0;
  unsigned char	ch, *buf_p = *buf_pp;
  unsigned int	ch_c;
  
  for (ch_c = 1;; ch_c++) {
    if (buf_p >= (unsigned char *)bounds_p) {
      return -1;
    }
    ch = *buf_p;
    buf_p++;
    work = ch & 0177;
    
    answer |= (work << shift);
    shift += 7;
    
    /* do we have the continuation bit on? */
    if ((ch & 0200) == 0) {
      break;
    }
  }
  
  /* advance our pointer */
  *buf_pp = buf_p;
  
  if (val_p != 0L) {
    *val_p = answer;
  }
  return ch_c;
}
