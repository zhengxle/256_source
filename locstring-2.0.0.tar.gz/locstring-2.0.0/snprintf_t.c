/*
 * Snprintf testing routines.
 *
 * Copyright 2000 by Gray Watson
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose and without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies,
 * and that the name of Gray Watson not be used in advertising or
 * publicity pertaining to distribution of the document or software
 * without specific, written prior permission.
 *
 * Gray Watson makes no representations about the suitability of the
 * software described herein for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 * The author may be contacted at http://256.com/gray/
 */

#include <stdio.h>

#include "snprintf.h"			/* needed for snprintf_tf */

#ifdef __GNUC__
#ident "$Id: snprintf_t.c,v 1.2 2000/03/07 21:49:41 gray Exp $";
#else
static char *rcs_id =
"$Id: snprintf_t.c,v 1.2 2000/03/07 21:49:41 gray Exp $";
#endif

/*
 * Test format structure.  The arguments to snprintf are constant and
 * are "foo", 1, 1024, 1.234, 123456.7, 'c'
 */
typedef struct {
  char		*tf_format;		/* string we are trying to match */ 
  int		tf_buf_len;		/* buffer length we restrict to */
  char		*tf_result;		/* result we should get back */ 
  int		tf_result_len;		/* length of result we should get */
  int		tf_trunc_b;		/* flag if the result was truncated */
} test_format_t;

/* static list of test patterns */
static	test_format_t	tests[] = {
  { "hello", 100, "hello", 5, 0 },
  { "hello", 1024, "hello", 5, 0 },
  { "hello", 6, "hello", 5, 0 },
  { "hello", 5, "hell", 4, 1 },		  /* sizes don't include the \0 */
  
  { "hello %s", 100, "hello foo", 9, 0 },
  { "hello %s", 6, "hello", 5, 1 },	  /* sizes don't include the \0 */
  { "hello %.10s", 100, "hello foo", 9, 0 },
  { "hello %.3s", 100, "hello foo", 9, 0 },
  { "hello %.2s", 100, "hello fo", 8, 0 },
  { "hello %10s", 100, "hello        foo", 16, 0 },
  { "hello %10.10s", 100, "hello        foo", 16, 0 },
  { "hello %-10s", 100, "hello foo       ", 16, 0 },
  { "hello %-10.10s", 100, "hello foo       ", 16, 0 },
  
  { "hello %s %d", 100, "hello foo 1", 11, 0 },
  { "hello %s %d", 11, "hello foo ", 10, 1 },
  { "hello %s %2d", 100, "hello foo  1", 12, 0 },
  { "hello %s %2d", 12, "hello foo  1", 11, 1 },
  { "hello %s %02d", 100, "hello foo 01", 12, 0 },
  
  { "hello %s %d %d", 100, "hello foo 1 1024", 16, 0 },
  { "hello %s %d %3d", 100, "hello foo 1 1024", 16, 0 },
  
  { "hello %s %d %d %f", 100, "hello foo 1 1024 1.234000", 25, 0 },
  { "hello %s %d %d %.1f", 100, "hello foo 1 1024 1.2", 20, 0 },
  { "hello %s %d %d %.2f", 100, "hello foo 1 1024 1.23", 21, 0 },
  
  { "hello %s %d %d %f %f", 100,
    "hello foo 1 1024 1.234000 123456.700000", 39, 0 },
  
  { "hello %s %d %d %f %f %c", 100,
    "hello foo 1 1024 1.234000 123456.700000 c", 41, 0 },
  
  { NULL }
};
  
/*
 * static void run_tests
 *
 * DESCRIPTION:
 *
 * Run the set of internal pattern tests.
 *
 * RETURNS:
 *
 * None.
 *
 * ARGUMENTS:
 *
 * case_insens_b - Case insensitive flag.
 *
 * verbose_b - Verbose flag.
 */
static	void	run_tests(const int verbose_b)
{
  test_format_t	*test_p;
  char		buf[1024];
  int		len, trunc_b;
  
  if (! verbose_b) {
    (void)printf("Checking internal tests.  Use -v for verbose output.\n");
  }
  
  for (test_p = tests; test_p->tf_format != NULL; test_p++) {
    
    if (test_p->tf_buf_len > sizeof(buf)) {
      (void)fprintf(stderr,
		    "%2d FAILED: requested buf size %d > internal size %d\n",
		    test_p - tests, test_p->tf_buf_len, sizeof(buf));
      continue;
    }
    
    /* try the test */
    len = snprintf_tf(buf, test_p->tf_buf_len, &trunc_b, test_p->tf_format,
		      "foo", 1, 1024, 1.234, 123456.7, 'c');
    if (len != test_p->tf_result_len) {
      (void)printf("%2d FAILED: got result '%s' length %d, expected %d\n",
		   test_p - tests, buf, len, test_p->tf_result_len);
      continue;
    }
    if (trunc_b != test_p->tf_trunc_b) {
      (void)printf("%2d FAILED: got result '%s' truncation %s, expected %s\n",
		   test_p - tests, buf, (trunc_b ? "on" : "off"),
		   (test_p->tf_trunc_b ? "on" : "off"));
      continue;
    }
    if (memcmp(buf, test_p->tf_result, len) != 0) {
      (void)printf("%2d FAILED: got result '%s', expected '%s' (%d)\n",
		   test_p - tests, buf, test_p->tf_result, len);
      continue;
    }
    
#ifndef HAS_SNPRINTF
    /* next try the NULL buffer */
    len = snprintf(NULL, test_p->tf_buf_len, test_p->tf_format,
		   "foo", 1, 1024, 1.234, 123456.7, 'c');
    if (len != test_p->tf_result_len) {
      (void)printf("%2d FAILED: NULL buf got result '%s' length %d, "
		   "expected %d\n",
		   test_p - tests, buf, len, test_p->tf_result_len);
      continue;
    }
#endif
    
    if (verbose_b) {
      (void)printf("%2d passed: got result '%s' (%d)%s\n",
		   test_p - tests, buf, len,
		   (trunc_b ? " truncated" : ""));
    }
  }
}

/*
 * static void usage
 *
 * DESCRIPTION:
 *
 * Print usage message.
 *
 * RETURNS:
 * 
 * None.
 *
 * ARGUMENTS:
 *
 * program - Name of the program from argv[0]
 */
static	void	usage(const char *program)
{
  (void)fprintf(stderr, "Usage: %s [-v]\n", program);
  (void)fprintf(stderr, "   -v         - verbose messages\n");
  exit(1);
}

int	main(int argc, char **argv)
{
  char	*program;
  int	verbose_b = 0;
  
  program = *argv;
  argc--, argv++;
  
  for (; argc > 0 && **argv == '-'; argc--, argv++) {
    if (*(*argv + 1) == 'v') {
      verbose_b = 1;
    }
    else {
      usage(program);
    }
  }
  
  run_tests(verbose_b);
  
  exit(0);
}
